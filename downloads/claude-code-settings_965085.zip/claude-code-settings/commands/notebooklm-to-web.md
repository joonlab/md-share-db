---
description: NotebookLM PDF 로고 제거 후 웹 슬라이드 뷰어로 변환 및 GitHub Pages 배포
argument-hint: <pdf_path>
---

다음 작업을 순서대로 수행해줘:

1. **notebooklm-logo-remover** skill로 "$ARGUMENTS"에서 NotebookLM 로고 제거
2. 로고 제거된 PDF (`*_로고X.pdf`)를 **pdf-slide-viewer** skill로 웹 슬라이드 뷰어로 변환
   - 로컬 브라우저에서 열기
   - GitHub Pages (`joonlab.github.io/pdf-slide-viewer/<project-name>/`)에 배포
   - 배포 URL 안내 (1-2분 후 반영)
