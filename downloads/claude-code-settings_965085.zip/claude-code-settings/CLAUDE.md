## PKM (Personal Knowledge Management) 시스템

나는 `~/PKM` 폴더에 지식 관리 시스템을 사용합니다.
**작업 전에 관련 폴더의 llms.txt를 확인하고, 작업 후 저장 가치가 있으면 제안해주세요.**

### 폴더 구조
```
~/PKM/
├── 11_Modules/        # 재사용 코드 모듈
├── 12_Research/       # 조사/학습 기록
├── 13_Troubleshooting/ # 에러 해결 기록
└── 14_Specs/          # 구현 명세서
```

### AI 행동 규칙

#### 🔍 작업 시작 전
1. **코드 작성 요청** → `~/PKM/11_Modules/llms.txt` 확인 후 재사용 가능한 모듈 있는지 체크
2. **기술 질문/조사** → `~/PKM/12_Research/llms.txt` 확인 후 기존 조사 결과 있는지 체크
3. **에러 발생** → `~/PKM/13_Troubleshooting/llms.txt` 확인 후 유사 해결 기록 있는지 체크
4. **프로젝트 구조 참고** → `~/PKM/14_Specs/llms.txt` 확인 후 참고할 명세 있는지 체크

#### 💾 작업 완료 후
저장 가치가 있다고 판단되면:
- "이 [코드/조사/해결법/명세]를 PKM에 저장할까요?" 라고 물어보기
- 저장 시 해당 폴더의 llms.txt 규칙에 따라 파일 생성
- llms.txt의 목록 테이블 업데이트

### 빠른 참조
| 상황 | 확인할 폴더 |
|------|------------|
| 코드 재사용하고 싶을 때 | 11_Modules |
| 기술 조사/비교할 때 | 12_Research |
| 에러 만났을 때 | 13_Troubleshooting |
| 프로젝트 구조 잡을 때 | 14_Specs |

---

## 시스템 동기화

사용자가 **"디렉토리 체계 정리"** 또는 **"시스템 동기화"**라고 하면:

```bash
python3 ~/.claude/sync-all.py
```

### 옵션
| 명령어 | 설명 |
|--------|------|
| `python3 ~/.claude/sync-all.py` | 디렉토리 + 히스토리 전체 동기화 |
| `python3 ~/.claude/sync-all.py --serve` | 동기화 후 뷰어 서버 시작 |
| `python3 ~/.claude/sync-all.py --json` | JSON 출력 (파싱용) |

### 파일 위치
- 통합 스크립트: `~/.claude/sync-all.py`
- 디렉토리 상태: `~/joon-directory-system.json`
- 히스토리 인덱스: `~/.claude/sessions-index.json`
- 히스토리 뷰어: `http://localhost:8080/history-viewer.html`

### 세션 경로 마이그레이션 (폴더 이동 시)
폴더를 이동한 경우, moves.csv 작성 후 migrate 스크립트 실행:
```bash
python3 ~/.claude/migrate-claude-project-paths.py --moves "<moves.csv 경로>" --apply
python3 ~/.claude/sync-all.py
```

---

## 파일 정리 규칙

### 1. 🚫 삭제 금지
- **rm 직접 삭제 절대 금지**
- 예외A: **중복 파일** = 파일크기 동일 + SHA-256 동일로 100% 확인된 것만 → "휴지통으로 이동"
- 예외B: 내가 지정한 경로의 **"빈 폴더"**만 삭제 (휴지통 이동 또는 rmdir)

### 2. 📝 이동/rename/삭제 로그 필수
**이동, rename 뿐만 아니라 삭제(휴지통 이동)도 반드시 로그 작성**

로그 폴더 생성:
```
/Users/joon/Desktop/99_보관/_정리로그/<YYYY-MM-DD_HHMMSS>_<작업명>/
```

필수 파일:
- `moves.csv` - 형식: `src,dst,kind,reason` (kind는 dir/file)
  - 삭제의 경우 dst는 `~/.Trash/<파일명>`
- `summary.md` - "원래 위치 → 새 위치" 요약 + 분류 기준 설명

**작업 종료 보고에 절대경로 필수:**
- moves.csv: `/Users/joon/Desktop/99_보관/_정리로그/<...>/moves.csv`
- moves_corrections.csv: `/Users/joon/Desktop/99_보관/_정리로그/<...>/moves_corrections.csv` (있으면)

### 3. 👁️ 숨김 포함 이동
- 폴더 이동 시 `.git`, `.claude`, `.env` 등 숨김 폴더/파일도 누락 없이 같이 이동
- **⚠️ 단, 홈 폴더의 `~/.claude`는 절대 변경/이동/삭제 금지**

### 4. 🔄 정리 완료 후 실행 (Claude resume 유지용)
```bash
python3 ~/.claude/migrate-claude-project-paths.py --moves "<moves.csv 절대경로>" --corrections "<moves_corrections.csv 절대경로(있으면)>" --apply
python3 ~/.claude/update-index.py
```

### 5. 📋 최종 보고 필수 항목
- [ ] 로그 폴더 절대경로
- [ ] moves.csv 절대경로 (+ moves_corrections.csv 있으면 포함)
- [ ] 휴지통으로 이동한 항목 / 휴지통 폴더 경로
- [ ] migrate/update-index 실행 결과 요약
- [ ] "No conversation found…" 미발생 검증 결과

---

## 경로 변경 알림 처리

사용자가 **"A에서 B로 경로 업데이트 됨"** 형태로 알려주는 경우:
- 파일/폴더 이동은 사용자가 이미 완료한 상태
- AI는 **로그 기록 + migrate 스크립트 실행**만 수행

### 처리 절차
1. 로그 폴더 생성 및 moves.csv, summary.md 작성
2. migrate 스크립트 실행
3. update-index 실행
4. **검증** (아래 참조)

### ⚠️ macOS 한글 폴더명 주의사항

macOS에서 한글 폴더명은 **유니코드 정규화** 이슈가 있음:
- 화면에 보이는 것: NFC (조합형, 예: `테스트` = 3글자)
- 실제 물리 경로: NFD (분해형, 예: `ㅌㅔㅅㅡㅌ` = 6개 문자 형태)

Claude Code는 물리 경로를 `[^a-zA-Z0-9] → -`로 인코딩해서 프로젝트 폴더를 찾음:
- NFC 기준: `-Users-joon-Desktop-----test` (대시 5개)
- NFD 기준: `-Users-joon-Desktop--------test` (대시 8개)

**migrate 스크립트가 `physical_dir_path()`로 실제 물리 경로를 가져와서 처리함.**

### 검증 방법

migrate 실행 후 반드시 확인:
```bash
# 1. 프로젝트 폴더 존재 확인
cd "<새 경로>" && node -p "
const fs=require('fs'), p=require('path');
const eu=s=>s.replace(/[^a-zA-Z0-9]/g,'-');
const dir=p.join(process.env.HOME,'.claude/projects',eu(process.cwd()));
console.log('project dir:', dir);
console.log('exists:', fs.existsSync(dir));
"

# 2. 세션 파일 확인 (세션 ID가 있는 경우)
ls ~/.claude/projects/<인코딩된폴더명>/

# 3. 실제 resume 테스트 (가장 확실)
cd "<새 경로>" && claude -r <세션ID> --dangerously-skip-permissions --print "ping"
```

"No conversation found…" 발생 시:
- migrate 스크립트가 NFD 물리 경로로 올바르게 폴더를 생성했는지 확인
- `~/.claude/projects/` 에서 해당 폴더명 검색

---

## GitHub 작업

### 인증 정보
- **계정**: `joonlab`
- **CLI**: `gh` (GitHub CLI) 사용
- **권한**: `repo`, `workflow`, `gist`, `read:org` (private repo 포함 전체 접근 가능)

### 주요 작업별 명령어

#### 1. Repo 생성
```bash
# Private repo 생성
gh repo create <repo-name> --private --description "설명"

# Public repo 생성
gh repo create <repo-name> --public --description "설명"

# 현재 폴더를 새 repo로 생성 (로컬 프로젝트 → GitHub)
gh repo create <repo-name> --private --source=. --push
```

#### 2. 코드 업로드 (새 프로젝트)
```bash
cd /path/to/project
git init
git add .
git commit -m "Initial commit"
gh repo create <repo-name> --private --source=. --push
```

#### 3. 코드 업로드 (기존 repo에 push)
```bash
git add .
git commit -m "커밋 메시지"
git push origin main
```

#### 4. Repo 클론
```bash
gh repo clone joonlab/<repo-name>
```

#### 5. PR/Issue 관리
```bash
# PR 생성
gh pr create --title "제목" --body "설명"

# Issue 생성
gh issue create --title "제목" --body "설명"

# PR/Issue 목록
gh pr list
gh issue list
```

### AI 행동 규칙

#### Repo 생성 요청 시
1. `gh auth status`로 인증 상태 확인 (필요시)
2. repo 이름, public/private 여부 확인
3. `gh repo create` 실행

#### 코드 업로드 요청 시
1. 대상 폴더에 `.git` 존재 여부 확인
2. 없으면 `git init` 후 `gh repo create --source=. --push`
3. 있으면 remote 확인 후 `git push`

#### 기존 repo 수정 요청 시
1. `gh repo clone`으로 클론
2. 수정 작업 수행
3. commit & push
4. 필요시 PR 생성

### MCP 도구 (읽기 전용)
- `github-fetcher/fetch-file`: 특정 파일 내용 가져오기
- `github-fetcher/fetch-subdir-tree`: 디렉토리 구조 가져오기
