---
name: deepseek-ocr
description: Extract text from images and PDFs using DeepSeek-OCR model with MLX. This skill should be used ONLY when the user explicitly mentions "딥식", "Deepseek", "DeepSeek", or similar variations (딥시크, 딥씨크, deepseek, etc.) in their OCR request. Do NOT use this skill for general OCR requests. Supports PNG, JPG, WEBP, BMP, GIF, TIFF, and PDF files. For PDFs, extracts all pages and saves as one TXT file with page markers. Automatically saves results to Downloads folder.
---

# DeepSeek OCR

## Overview

Extract text from images and PDFs using the DeepSeek-OCR-8bit model optimized for Apple Silicon. Process single or multiple files at once, with results automatically saved to the Downloads folder as `{filename}_OCR.txt`.

**Supported formats**: PNG, JPG, WEBP, BMP, GIF, TIFF, PDF

## When to Use This Skill

Use this skill **ONLY** when the user explicitly mentions DeepSeek in their request:
- "딥식 OCR 해줘"
- "Deepseek으로 이미지 읽어줘"
- "DeepSeek OCR 돌려줘"
- "딥시크로 텍스트 추출해줘"
- "이 이미지 딥식으로 OCR"

**DO NOT use this skill** for general OCR requests like:
- ❌ "Extract text from this image"
- ❌ "Run OCR on these images"
- ❌ "Read the text from this PNG"
- ❌ "이미지 텍스트 추출해줘"

The user must specifically request DeepSeek/딥식 for this skill to activate.

## Quick Start

### Command Line Usage

Run the OCR processor directly from the terminal:

```bash
~/.claude/skills/deepseek-ocr/scripts/run_ocr.sh
```

The script will prompt for image paths. Paste one or more paths (separated by newlines or spaces), then press Enter twice to start processing.

### Python Usage

Run the Python script directly:

```bash
python3 ~/.claude/skills/deepseek-ocr/scripts/ocr_images.py
```

## How It Works

1. **Input**: User provides one or more image/PDF file paths
2. **Validation**: Checks that files exist and are valid formats
3. **Processing**:
   - **Images**: Direct OCR on the image
   - **PDFs**: Converts each page to image, then runs OCR on all pages
4. **Output**:
   - **Images**: One TXT file per image
   - **PDFs**: One TXT file with all pages (marked as [Page 1], [Page 2], etc.)

### Supported Formats

**Images:**
- PNG, JPG/JPEG, WEBP, BMP, GIF, TIFF

**Documents:**
- PDF (all pages processed automatically)

## Usage Examples

### Example 1: Single Image

User provides:
```
/Users/joon/Desktop/document.png
```

Result:
- File saved: `~/Downloads/document_OCR.txt`

### Example 2: Multiple Images (Newline Separated)

User provides:
```
/Users/joon/Desktop/page1.png
/Users/joon/Desktop/page2.png
/Users/joon/Desktop/page3.png
```

Results:
- `~/Downloads/page1_OCR.txt`
- `~/Downloads/page2_OCR.txt`
- `~/Downloads/page3_OCR.txt`

### Example 2b: Multiple Images (Space Separated with Quotes)

User can paste multiple paths on one line (Finder's "Copy as Pathname" format):
```
'/Users/joon/Desktop/photo 1.jpg' '/Users/joon/Desktop/photo 2.jpg' '/Users/joon/Desktop/photo 3.jpg'
```

Results:
- `~/Downloads/photo 1_OCR.txt`
- `~/Downloads/photo 2_OCR.txt`
- `~/Downloads/photo 3_OCR.txt`

### Example 3: Paths with Special Characters

The script handles paths with:
- Spaces in filenames
- Special characters (brackets, parentheses, etc.)
- Non-ASCII characters (Korean, Japanese, etc.)

Example:
```
/Users/joon/Downloads/이미지/[완료] TOPIK 2 읽기_슬라이드 문제풀이_1-12_우즈벡어_최종_250817 (1).png
```

Result:
- `~/Downloads/[완료] TOPIK 2 읽기_슬라이드 문제풀이_1-12_우즈벡어_최종_250817 (1)_OCR.txt`

### Example 4: PDF Files

User provides PDF file:
```
/Users/joon/Documents/report.pdf
```

The script will:
1. Convert each page to an image
2. Run OCR on all pages
3. Save results in one file with page markers

Result file (`~/Downloads/report_OCR.txt`):
```
File: /Users/joon/Documents/report.pdf
Type: PDF
Model: mlx-community/DeepSeek-OCR-8bit
================================================================================

[Page 1]
Text from first page...

[Page 2]
Text from second page...

[Page 3]
Text from third page...
```

### Example 5: Mixed Images and PDFs

User can process both types together:
```
'/Users/joon/Desktop/photo.jpg' '/Users/joon/Documents/document.pdf'
```

Results:
- `~/Downloads/photo_OCR.txt` (single image)
- `~/Downloads/document_OCR.txt` (all PDF pages with markers)

## Technical Details

### Model Information

- **Model**: mlx-community/DeepSeek-OCR-8bit
- **Framework**: MLX (Apple Silicon optimized)
- **Size**: ~1.9GB (downloaded on first run)
- **Cache**: Models cached in `~/.cache/huggingface/hub/`

### Performance Optimization

**Parallel Processing:**
- System auto-detects: 16 cores, 64GB RAM
- **Multiple images**: Processed with ThreadPoolExecutor (max 6 workers)
  - Image loading and preprocessing: parallel
  - OCR inference: synchronized (Metal GPU thread-safety)
- **PDF pages**: Each page processed in parallel (max 6 workers)
  - Significantly faster for multi-page PDFs
- **Mixed files**: Images processed in parallel, then PDFs

**Speed Improvements:**
- Single image: ~2 seconds
- Multiple images: Preprocessing parallelized, inference sequential
- PDF (10 pages): ~6x faster vs sequential (pages processed in parallel)

### First Run

The first time the skill is used, it will:
1. Download the DeepSeek-OCR-8bit model (~1.9GB)
2. Cache it for future use
3. This may take several minutes depending on internet speed

Subsequent runs will use the cached model and start immediately.

### Output Format

Each output file contains:
```
Image: /path/to/original/image.png
Model: mlx-community/DeepSeek-OCR-8bit
================================================================================

[Extracted text appears here]
```

## Claude Usage

When a user requests DeepSeek OCR:

1. **Verify trigger**: Confirm the user mentioned "딥식", "Deepseek", "DeepSeek" or similar variations
   - ✅ "딥식 OCR 해줘" → Use this skill
   - ✅ "Deepseek으로 읽어줘" → Use this skill
   - ❌ "OCR 해줘" → Do NOT use this skill

2. **Get image paths**: Ask user for image paths if not provided

3. **Run the script**: Execute the OCR processor
   ```bash
   ~/.claude/skills/deepseek-ocr/scripts/run_ocr.sh
   ```

4. **Provide paths**: When prompted, input the image paths provided by the user

5. **Report results**: Inform user of the output file locations in Downloads folder

### Alternative: Direct Python Execution

For programmatic use or when integrating into workflows:

```python
from pathlib import Path
import subprocess

script_path = Path.home() / ".claude/skills/deepseek-ocr/scripts/ocr_images.py"

# Prepare input (image paths separated by newlines)
image_paths = "\n".join([
    "/path/to/image1.png",
    "/path/to/image2.jpg"
])

# Run with input
process = subprocess.Popen(
    ["python3", str(script_path)],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True
)

stdout, stderr = process.communicate(input=image_paths + "\n\n")
print(stdout)
```

## Troubleshooting

### Model Not Loading

If the model fails to load:
- Check internet connection (required for first download)
- Ensure sufficient disk space (~2GB for model cache)
- Verify mlx-vlm is installed: `pip list | grep mlx-vlm`

### Dependencies

Required Python packages:
- `mlx-vlm` - MLX-based vision-language model
- `pillow` - Image processing
- `pymupdf` (fitz) - PDF processing
- `transformers` - Model loading
- `mlx` - Apple Silicon optimization

Install if missing:
```bash
pip install mlx-vlm pillow pymupdf
```

### Path Issues

If paths aren't recognized:
- Use absolute paths (not relative)
- Ensure file paths are correct and files exist
- Check file permissions (readable)

## Resources

### scripts/

- `ocr_images.py`: Main OCR processing script
  - Handles multiple image inputs
  - Validates image paths and formats
  - Processes images using DeepSeek-OCR model
  - Saves results to Downloads folder
  - Provides progress feedback and error handling

- `run_ocr.sh`: Shell launcher script
  - Quick terminal execution
  - Automatically locates and runs ocr_images.py
  - Simple entry point for command-line usage
