#!/usr/bin/env python3
"""
DeepSeek OCR Image Processor
Processes one or more images and PDFs using mlx-vlm DeepSeek-OCR model
Optimized with parallel processing for multiple files
"""

import io
import os
import shlex
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from PIL import Image
import fitz  # PyMuPDF
from mlx_vlm import load, generate
from mlx_vlm.prompt_utils import apply_chat_template
from mlx_vlm.utils import load_config

# Configuration
MODEL_PATH = "mlx-community/DeepSeek-OCR-8bit"
DEFAULT_PROMPT = "Read all the text in this image."
MAX_TOKENS = 1024
TEMPERATURE = 0.0
OUTPUT_DIR = Path.home() / "Downloads"

# Parallel processing configuration
# System: 16 cores, 64GB RAM
# MLX uses Metal GPU - limit workers to avoid GPU memory issues
MAX_WORKERS = 6  # Optimal for GPU memory balance

# Global model cache
_model_cache = None
_processor_cache = None
_config_cache = None

# Thread lock for MLX model inference (Metal GPU is not thread-safe)
_inference_lock = threading.Lock()


def load_model():
    """Load model once and cache it"""
    global _model_cache, _processor_cache, _config_cache

    if _model_cache is None:
        print(f"Loading model: {MODEL_PATH}")
        print("This may take a while on first run...\n")
        _model_cache, _processor_cache = load(MODEL_PATH, trust_remote_code=True)
        _config_cache = load_config(MODEL_PATH)
        print("Model loaded successfully!\n")

    return _model_cache, _processor_cache, _config_cache


def pdf_to_images(pdf_path: str, dpi: int = 150) -> list[Image.Image]:
    """
    Convert PDF pages to list of PIL Images

    Args:
        pdf_path: Path to PDF file
        dpi: Resolution for rendering (default: 150)

    Returns:
        List of PIL Images, one per page
    """
    images = []
    pdf_document = fitz.open(pdf_path)
    total_pages = len(pdf_document)

    for page_idx in range(total_pages):
        page = pdf_document.load_page(page_idx)
        mat = fitz.Matrix(dpi / 72, dpi / 72)
        pix = page.get_pixmap(matrix=mat)
        img_data = pix.tobytes("png")
        image = Image.open(io.BytesIO(img_data))

        # Convert to RGB to ensure 3 channels
        if image.mode != "RGB":
            image = image.convert("RGB")
        images.append(image)

    pdf_document.close()
    return images


def process_image(image_path: str, prompt: str = DEFAULT_PROMPT) -> str:
    """
    Process a single image with OCR

    Args:
        image_path: Path to the image file
        prompt: OCR prompt to use

    Returns:
        OCR result text
    """
    model, processor, config = load_model()

    # Load image
    image = Image.open(image_path)

    # Convert to RGB if needed
    if image.mode != "RGB":
        image = image.convert("RGB")

    # Format prompt
    formatted_prompt = apply_chat_template(processor, config, prompt, num_images=1)

    # Run OCR with lock (Metal GPU is not thread-safe)
    with _inference_lock:
        output = generate(
            model,
            processor,
            formatted_prompt,
            image=[image],
            max_tokens=MAX_TOKENS,
            temperature=TEMPERATURE,
            verbose=False,
        )

    # Extract text
    if hasattr(output, "text"):
        return output.text
    elif hasattr(output, "__str__"):
        return str(output)
    else:
        return output


def save_result(file_path: str, result: str, file_type: str = "image") -> str:
    """
    Save OCR result to text file

    Args:
        file_path: Original file path
        result: OCR result text
        file_type: "image" or "pdf"

    Returns:
        Path to saved result file
    """
    # Generate output filename
    file_name = Path(file_path).stem
    output_filename = f"{file_name}_OCR.txt"
    output_path = OUTPUT_DIR / output_filename

    # Save result
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(f"File: {file_path}\n")
        f.write(f"Type: {file_type.upper()}\n")
        f.write(f"Model: {MODEL_PATH}\n")
        f.write("=" * 80 + "\n\n")
        f.write(result)

    return str(output_path)


def process_single_page(page_data: tuple) -> tuple[int, str]:
    """
    Process a single page/image with OCR

    Args:
        page_data: Tuple of (page_number, image, prompt)

    Returns:
        Tuple of (page_number, ocr_result)
    """
    page_num, image, prompt = page_data
    model, processor, config = load_model()

    # Format prompt
    formatted_prompt = apply_chat_template(processor, config, prompt, num_images=1)

    # Run OCR with lock (Metal GPU is not thread-safe)
    with _inference_lock:
        output = generate(
            model,
            processor,
            formatted_prompt,
            image=[image],
            max_tokens=MAX_TOKENS,
            temperature=TEMPERATURE,
            verbose=False,
        )

    # Extract text
    if hasattr(output, "text"):
        result = output.text
    elif hasattr(output, "__str__"):
        result = str(output)
    else:
        result = output

    return page_num, result


def process_pdf(pdf_path: str, prompt: str = DEFAULT_PROMPT) -> str:
    """
    Process a PDF file with OCR on all pages (parallel processing)

    Args:
        pdf_path: Path to the PDF file
        prompt: OCR prompt to use

    Returns:
        Combined OCR result text with page markers
    """
    # Load model first (shared across threads)
    load_model()

    # Convert PDF to images
    print(f"  Converting PDF to images...")
    images = pdf_to_images(pdf_path)
    total_pages = len(images)
    print(f"  Found {total_pages} page(s)")

    # Prepare page data for parallel processing
    page_data_list = [(i + 1, img, prompt) for i, img in enumerate(images)]

    # Process pages in parallel
    print(f"  Processing pages in parallel (max {MAX_WORKERS} workers)...")
    results_dict = {}

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # Submit all pages
        future_to_page = {
            executor.submit(process_single_page, page_data): page_data[0]
            for page_data in page_data_list
        }

        # Collect results as they complete
        completed = 0
        for future in as_completed(future_to_page):
            page_num = future_to_page[future]
            try:
                page_num, result = future.result()
                results_dict[page_num] = result
                completed += 1
                print(f"  ✓ Page {page_num}/{total_pages} completed ({completed}/{total_pages})")
            except Exception as e:
                print(f"  ✗ Page {page_num} failed: {str(e)}")
                results_dict[page_num] = f"[Error processing page: {str(e)}]"

    # Combine results in correct page order
    combined_result = ""
    for page_num in sorted(results_dict.keys()):
        combined_result += f"[Page {page_num}]\n"
        combined_result += results_dict[page_num].strip()
        combined_result += "\n\n"

    return combined_result.strip()


def parse_image_paths(input_text: str) -> list[str]:
    """
    Parse image paths from user input
    Handles multiple paths separated by newlines or spaces (with proper quote handling)

    Args:
        input_text: Raw input text containing one or more paths

    Returns:
        List of cleaned image paths
    """
    paths = []
    for line in input_text.strip().split('\n'):
        line = line.strip()
        if not line:
            continue

        # Try to parse as shell-style quoted strings first
        try:
            # shlex.split handles quoted strings properly
            parsed_paths = shlex.split(line)
            paths.extend(parsed_paths)
        except ValueError:
            # If shlex fails (unmatched quotes), fall back to simple parsing
            # Remove quotes and treat as single path
            path = line.strip("'\"")
            if path:
                paths.append(path)

    return paths


def validate_file_path(path: str) -> tuple[bool, str]:
    """
    Validate if path exists and is an image or PDF file

    Args:
        path: Path to validate

    Returns:
        Tuple of (is_valid, file_type) where file_type is "image", "pdf", or ""
    """
    if not os.path.exists(path):
        print(f"❌ File not found: {path}")
        return False, ""

    suffix = Path(path).suffix.lower()
    image_extensions = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif', '.tiff'}
    pdf_extensions = {'.pdf'}

    if suffix in image_extensions:
        return True, "image"
    elif suffix in pdf_extensions:
        return True, "pdf"
    else:
        print(f"❌ Not a valid image or PDF file: {path}")
        return False, ""


def main():
    """Main entry point"""
    print("=" * 80)
    print("DeepSeek OCR Processor (Images & PDFs)")
    print("=" * 80)
    print()

    # Get file paths from user
    print("Paste one or more image/PDF paths (press Enter twice when done):")
    print("You can paste multiple paths at once, separated by newlines or spaces")
    print("Supported: PNG, JPG, WEBP, BMP, GIF, TIFF, PDF")
    print()

    # Read multiple lines
    lines = []
    try:
        while True:
            line = input()
            if not line.strip():
                if lines:  # If we have at least one line, break
                    break
            else:
                lines.append(line)
    except EOFError:
        pass

    if not lines:
        print("\n❌ No input provided. Exiting.")
        sys.exit(1)

    # Parse paths
    input_text = '\n'.join(lines)
    file_paths = parse_image_paths(input_text)

    if not file_paths:
        print("\n❌ No valid paths found. Exiting.")
        sys.exit(1)

    # Validate paths and categorize by type
    valid_files = []
    for path in file_paths:
        is_valid, file_type = validate_file_path(path)
        if is_valid:
            valid_files.append((path, file_type))

    if not valid_files:
        print("\n❌ No valid image or PDF files found. Exiting.")
        sys.exit(1)

    # Count by type
    image_count = sum(1 for _, ftype in valid_files if ftype == "image")
    pdf_count = sum(1 for _, ftype in valid_files if ftype == "pdf")

    print(f"\n✅ Found {len(valid_files)} valid file(s): {image_count} image(s), {pdf_count} PDF(s)")

    # Load model once before processing (shared across threads)
    if len(valid_files) > 1:
        print(f"⚡ Parallel processing enabled (max {MAX_WORKERS} workers)")
    print()

    # Separate images and PDFs for optimized processing
    image_files = [(path, ftype) for path, ftype in valid_files if ftype == "image"]
    pdf_files = [(path, ftype) for path, ftype in valid_files if ftype == "pdf"]

    results = []

    # Process images in parallel (if multiple)
    if image_files:
        if len(image_files) == 1:
            # Single image - process directly
            file_path, file_type = image_files[0]
            print(f"[1/1] Processing image: {Path(file_path).name}")
            try:
                print(f"  Image size: {Image.open(file_path).size}")
                result = process_image(file_path)
                output_path = save_result(file_path, result, file_type="image")
                results.append((file_path, output_path, True))
                print(f"  ✅ Saved to: {output_path}\n")
            except Exception as e:
                print(f"  ❌ Error: {str(e)}\n")
                results.append((file_path, None, False))
        else:
            # Multiple images - process in parallel
            print(f"Processing {len(image_files)} images in parallel...")
            load_model()  # Pre-load model

            def process_image_file(file_data):
                file_path, file_type = file_data
                try:
                    result = process_image(file_path)
                    output_path = save_result(file_path, result, file_type="image")
                    return (file_path, output_path, True)
                except Exception as e:
                    print(f"  ❌ {Path(file_path).name}: {str(e)}")
                    return (file_path, None, False)

            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_file = {
                    executor.submit(process_image_file, file_data): file_data[0]
                    for file_data in image_files
                }

                completed = 0
                for future in as_completed(future_to_file):
                    file_path = future_to_file[future]
                    try:
                        result = future.result()
                        results.append(result)
                        completed += 1
                        if result[2]:  # Success
                            print(f"  ✓ [{completed}/{len(image_files)}] {Path(file_path).name}")
                    except Exception as e:
                        print(f"  ✗ {Path(file_path).name}: {str(e)}")
                        results.append((file_path, None, False))

            print()

    # Process PDFs sequentially (each PDF uses parallel processing internally)
    if pdf_files:
        for idx, (file_path, file_type) in enumerate(pdf_files, 1):
            print(f"[{idx}/{len(pdf_files)}] Processing PDF: {Path(file_path).name}")
            try:
                result = process_pdf(file_path)
                output_path = save_result(file_path, result, file_type="pdf")
                results.append((file_path, output_path, True))
                print(f"  ✅ Saved to: {output_path}\n")
            except Exception as e:
                print(f"  ❌ Error: {str(e)}\n")
                import traceback
                traceback.print_exc()
                results.append((file_path, None, False))

    # Summary
    print("=" * 80)
    print("Summary")
    print("=" * 80)
    successful = sum(1 for _, _, success in results if success)
    print(f"Total: {len(results)} | Successful: {successful} | Failed: {len(results) - successful}")
    print()

    if successful > 0:
        print(f"Results saved to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
