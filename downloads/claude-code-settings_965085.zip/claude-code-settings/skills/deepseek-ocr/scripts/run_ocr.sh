#!/bin/bash
#
# DeepSeek OCR Runner
# Quick launcher for OCR processing
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="$SCRIPT_DIR/ocr_images.py"

# Make sure the Python script exists
if [ ! -f "$PYTHON_SCRIPT" ]; then
    echo "Error: ocr_images.py not found at $PYTHON_SCRIPT"
    exit 1
fi

# Run the OCR script
python3 "$PYTHON_SCRIPT"
