#!/usr/bin/env python3
"""
NotebookLM Logo Remover

Removes NotebookLM watermark/logo from PDF files.
Uses template matching with SVG logo to locate and remove the logo from each page.
Supports both light and dark backgrounds with adaptive template matching.

Usage:
    python remove_logo.py <input_pdf> [--output <output_pdf>]

If output is not specified, saves to the same folder as input with "_로고X" suffix.
"""

import argparse
import sys
from pathlib import Path


def remove_logo(input_pdf: str, output_pdf: str = None) -> Path:
    """
    Remove NotebookLM logo from a PDF file.

    Args:
        input_pdf: Path to the input PDF file
        output_pdf: Path to the output PDF file (optional)

    Returns:
        Path to the output PDF file
    """
    try:
        import cv2
        import numpy as np
        from pdf2image import convert_from_path
        from PIL import Image
        import cairosvg
        import io
    except ImportError as e:
        print(f"Error: Missing required package - {e}")
        print("\nInstall required packages:")
        print("  pip install opencv-python pdf2image pillow cairosvg numpy")
        sys.exit(1)

    input_path = Path(input_pdf).resolve()
    if not input_path.exists():
        raise FileNotFoundError(f"Input PDF not found: {input_path}")

    # Output path: same folder, "_로고X" suffix
    if output_pdf:
        output_path = Path(output_pdf).resolve()
    else:
        output_path = input_path.parent / f"{input_path.stem}_로고X{input_path.suffix}"

    # SVG logo path (in assets folder)
    script_dir = Path(__file__).parent
    svg_path = script_dir.parent / "assets" / "NotebookLM_logo.svg"

    if not svg_path.exists():
        raise FileNotFoundError(f"Logo SVG not found: {svg_path}")

    print(f"Input:  {input_path}")
    print(f"Output: {output_path}")
    print()

    # Convert PDF to images
    print("Converting PDF pages to images...")
    pages = convert_from_path(str(input_path), dpi=200)
    print(f"Total pages: {len(pages)}")

    def get_background_color(image, x, y, w, h, is_dark_bg):
        """Extract background color from area left of the logo."""
        sample_x1 = max(0, x - 60)
        sample_x2 = max(0, x - 20)

        if sample_x2 > sample_x1:
            region = image[y:y+h, sample_x1:sample_x2]
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)

            if is_dark_bg:
                # For dark backgrounds, sample dark pixels
                dark_mask = gray < 80
                if np.any(dark_mask):
                    return np.median(region[dark_mask], axis=0).astype(np.uint8)
            else:
                # For light backgrounds, sample bright pixels
                bright_mask = gray > 200
                if np.any(bright_mask):
                    return np.median(region[bright_mask], axis=0).astype(np.uint8)

            # Fallback: use median of entire region
            return np.median(region, axis=(0, 1)).astype(np.uint8)

        # Default fallback colors
        if is_dark_bg:
            return np.array([20, 20, 30], dtype=np.uint8)
        else:
            return np.array([230, 235, 240], dtype=np.uint8)

    def find_logo(page_gray, svg_path_str, search_y, search_x):
        """
        Find logo position using template matching.
        Tries both light background (dark logo) and dark background (bright logo) templates.
        Returns the best match regardless of background type.
        """
        search_region = page_gray[search_y:, search_x:]

        # Determine if the search region is dark or light
        region_brightness = np.mean(search_region)

        best_match = None
        best_val = 0
        is_dark_background = False

        for svg_scale in np.linspace(0.30, 0.45, 30):
            png_data = cairosvg.svg2png(url=svg_path_str, scale=svg_scale)
            logo_pil = Image.open(io.BytesIO(png_data)).convert('RGBA')
            logo_np = np.array(logo_pil)

            alpha = logo_np[:, :, 3]
            h, w = alpha.shape

            if h >= search_region.shape[0] or w >= search_region.shape[1]:
                continue

            # Template for light background (dark logo on white)
            logo_gray_light = np.ones((h, w), dtype=np.uint8) * 255
            logo_gray_light[alpha > 30] = 50

            # Template for dark background (bright logo on black)
            logo_gray_dark = np.zeros((h, w), dtype=np.uint8)
            logo_gray_dark[alpha > 30] = 255

            # Try light background template
            result_light = cv2.matchTemplate(search_region, logo_gray_light, cv2.TM_CCOEFF_NORMED)
            _, max_val_light, _, max_loc_light = cv2.minMaxLoc(result_light)

            # Try dark background template
            result_dark = cv2.matchTemplate(search_region, logo_gray_dark, cv2.TM_CCOEFF_NORMED)
            _, max_val_dark, _, max_loc_dark = cv2.minMaxLoc(result_dark)

            # Use whichever template gives better match
            if max_val_light > max_val_dark:
                if max_val_light > best_val:
                    best_val = max_val_light
                    best_match = (search_x + max_loc_light[0], search_y + max_loc_light[1], w, h, max_val_light)
                    is_dark_background = False
            else:
                if max_val_dark > best_val:
                    best_val = max_val_dark
                    best_match = (search_x + max_loc_dark[0], search_y + max_loc_dark[1], w, h, max_val_dark)
                    is_dark_background = True

        # Lower threshold for dark backgrounds since they can be trickier
        threshold = 0.4 if is_dark_background else 0.5

        if best_match and best_val > threshold:
            return (*best_match, is_dark_background)
        return None

    def remove_logo_from_page(page_bgr, x, y, w, h, is_dark_bg):
        """Remove logo by filling the area with background color."""
        result = page_bgr.copy()
        page_h, page_w = page_bgr.shape[:2]

        bg_color = get_background_color(page_bgr, x, y, w, h, is_dark_bg)

        # Padding to cover anti-aliased edges
        pad = 8

        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(page_w, x + w + pad)
        y2 = min(page_h, y + h + pad)

        result[y1:y2, x1:x2] = bg_color

        return result

    processed_images = []
    svg_path_str = str(svg_path)

    for page_num, page in enumerate(pages, 1):
        print(f"Processing page {page_num}/{len(pages)}...", end=" ")

        page_np = np.array(page)
        page_h, page_w = page_np.shape[:2]
        page_bgr = cv2.cvtColor(page_np, cv2.COLOR_RGB2BGR)
        page_gray = cv2.cvtColor(page_bgr, cv2.COLOR_BGR2GRAY)

        # Search in bottom-right area
        search_y = page_h - int(page_h * 0.10)
        search_x = page_w - int(page_w * 0.20)

        found = find_logo(page_gray, svg_path_str, search_y, search_x)

        if found:
            x, y, w, h, conf, is_dark_bg = found
            bg_type = "dark" if is_dark_bg else "light"
            page_cleaned = remove_logo_from_page(page_bgr, x, y, w, h, is_dark_bg)
            print(f"Removed at ({x}, {y}) [{bg_type} bg, conf={conf:.2f}]")

            page_rgb = cv2.cvtColor(page_cleaned, cv2.COLOR_BGR2RGB)
            processed_img = Image.fromarray(page_rgb)
        else:
            print("No logo found")
            processed_img = page

        processed_images.append(processed_img)

    # Save PDF
    print(f"\nSaving: {output_path}")
    processed_images[0].save(
        str(output_path), "PDF", resolution=200, save_all=True,
        append_images=processed_images[1:] if len(processed_images) > 1 else []
    )

    print(f"\nDone! Output saved to: {output_path}")
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="Remove NotebookLM logo from PDF files"
    )
    parser.add_argument("input_pdf", help="Path to the input PDF file")
    parser.add_argument("--output", "-o", help="Path to the output PDF file (optional)")

    args = parser.parse_args()

    try:
        remove_logo(args.input_pdf, args.output)
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
