---
name: notebooklm-logo-remover
description: Remove NotebookLM watermark/logo from PDF files. This skill should be used when the user provides a PDF file and requests to remove the NotebookLM logo, watermark, or branding. Common triggers include "NotebookLM 로고 지워줘", "remove NotebookLM logo", "워터마크 제거", or similar requests involving NotebookLM-generated PDFs.
---

# NotebookLM Logo Remover

## Overview

This skill removes the NotebookLM watermark/logo from PDF files using adaptive template matching. It automatically detects whether each page has a light or dark background and applies the appropriate detection algorithm to locate and cleanly remove the logo.

## When to Use

- User provides a PDF file and asks to remove NotebookLM logo/watermark
- User mentions "NotebookLM 로고", "NotebookLM watermark", or similar
- PDF files generated from Google NotebookLM that contain branding

## Quick Start

To remove the NotebookLM logo from a PDF:

```bash
python3 scripts/remove_logo.py "<input_pdf_path>"
```

The script automatically:
1. Converts each PDF page to an image
2. Detects whether the page has a light or dark background
3. Applies adaptive template matching to locate the logo
4. Removes the logo by filling with the sampled background color
5. Saves the output to the same folder with `_로고X` suffix

**Example:**
```
Input:  /Users/joon/Downloads/presentation.pdf
Output: /Users/joon/Downloads/presentation_로고X.pdf
```

## Workflow

1. **Receive PDF path** from user
2. **Execute the removal script**:
   ```bash
   python3 /Users/joon/.claude/skills/notebooklm-logo-remover/scripts/remove_logo.py "<pdf_path>"
   ```
3. **Report completion** with the output file path

## Resources

### scripts/

**`remove_logo.py`** - Main logo removal script
- Takes PDF file path as input
- Outputs cleaned PDF to same folder with `_로고X` suffix
- Uses adaptive template matching for both light and dark backgrounds:
  - Light background: dark logo template (logo pixels = 50, background = 255)
  - Dark background: bright logo template (logo pixels = 255, background = 0)
- Automatically selects the template with higher matching confidence
- Samples background color adaptively based on detected background type
- Handles anti-aliased edges with padding

### assets/

**`NotebookLM_logo.svg`** - Official NotebookLM logo in SVG format
- Used as template for matching logo position in PDF pages
- Vector format enables accurate matching at any scale

## Requirements

The following Python packages must be installed:
- opencv-python
- pdf2image
- pillow
- cairosvg
- numpy

Install with:
```bash
pip3 install opencv-python pdf2image pillow cairosvg numpy
```

Also requires `poppler` for pdf2image:
```bash
brew install poppler  # macOS
```
