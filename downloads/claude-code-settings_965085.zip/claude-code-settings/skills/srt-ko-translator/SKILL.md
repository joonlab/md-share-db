---
name: srt-ko-translator
description: Translate English SRT subtitle files to Korean and save as new SRT files. This skill should be used when the user provides an English SRT file path and requests Korean translation. Triggers include "SRT 번역해줘", "영어 자막을 한국어로", "translate this subtitle to Korean", or similar requests involving SRT subtitle translation.
---

# SRT Korean Translator

## Overview

This skill enables Claude to translate English SRT subtitle files into natural Korean, leveraging Claude's contextual understanding for high-quality translation that preserves timing information.

## When to Use This Skill

Use this skill when users request:
- "이 SRT 파일 한국어로 번역해줘"
- "영어 자막을 한국어로 번역해줘"
- "Translate this subtitle file to Korean"
- "한글 자막 만들어줘" (with an SRT file path)

## Workflow

### Step 1: Extract Subtitle Text

Extract text content from the English SRT file for translation:

```bash
python3 scripts/extract_subtitle_text.py "<srt_file_path>"
```

**Output:** JSON containing:
- `texts`: Array of subtitle text strings (preprocessed and grouped into sentences)
- `metadata.total_count`: Number of subtitle entries
- `metadata.processed_count`: Number after preprocessing

**Important:** The script automatically:
- Fixes overlapping timestamps (common in auto-generated subtitles)
- Removes short duplicate subtitles (<150ms)
- Groups consecutive subtitles into sentence units for better translation context

### Step 2: Translate with Claude

Translate each subtitle text to Korean with the following guidelines:

**Translation Guidelines:**
1. Maintain natural Korean sentence structure
2. Keep translations reasonably similar in length to fit subtitle timing
3. Preserve technical terms appropriately (transliterate or keep original when suitable)
4. Adapt idioms and cultural references for Korean audiences
5. Match the original tone (formal/informal, educational/casual)
6. Maintain the exact same number of entries as the input array

**Output Format:** Create a JSON array of translated strings:

```json
[
  "첫 번째 번역된 자막",
  "두 번째 번역된 자막",
  "세 번째 번역된 자막"
]
```

Save this to a temporary JSON file (e.g., `/tmp/translated_texts.json`).

**Quality Checks:**
- Verify the array length matches the original subtitle count
- Ensure no entries are empty (unless the original was empty)
- Check that the tone matches the original content

### Step 3: Merge Translated Text with SRT Timestamps

Combine the translated texts with the original SRT timing information:

```bash
python3 scripts/merge_translated_subtitle.py "<original_srt>" "<translated_json>" "<output_srt>"
```

**Example:**
```bash
python3 scripts/merge_translated_subtitle.py \
  /path/to/video.en.srt \
  /tmp/translated_texts.json \
  ~/Downloads/video.ko.srt
```

**Output:** JSON containing:
- `success`: boolean
- `subtitle_count`: number of subtitles processed
- `output_path`: path to Korean SRT file

### Step 4: Cleanup and Report

1. Remove the temporary translated JSON file
2. Report the output file location to the user

## Complete Example Workflow

```bash
# 1. Extract subtitle texts
python3 scripts/extract_subtitle_text.py "/path/to/video.en.srt"

# 2. Translate with Claude (manual step)
# - Read extracted texts
# - Translate each text to Korean
# - Save to /tmp/translated_texts.json

# 3. Merge translations with timestamps
python3 scripts/merge_translated_subtitle.py \
  "/path/to/video.en.srt" \
  "/tmp/translated_texts.json" \
  "~/Downloads/video.ko.srt"

# 4. Cleanup
rm /tmp/translated_texts.json
```

## Output Location

By default, save the translated Korean SRT file to `~/Downloads/` with the naming convention:
- Input: `video.en.srt` or `video.srt`
- Output: `video.ko.srt`

## Prerequisites

The following must be installed:
- Python 3.7+
- Python package: `pysrt`

Install dependency:
```bash
pip3 install pysrt
```

## Scripts Reference

### scripts/extract_subtitle_text.py
Preprocesses SRT file and extracts text array for translation. Automatically handles overlapping timestamps and groups subtitles into sentence units.

### scripts/merge_translated_subtitle.py
Combines translated text array with original SRT timing information to create Korean SRT file.
