---
name: macos-file-tags
description: Manage macOS Finder color tags on files and directories. This skill should be used when users want to add, change, remove, or search for files by color tags (빨간색/Red, 파란색/Blue, etc.), check current tags, or organize files with color coding. Common triggers include "빨간색 태그 달아줘", "파란색으로 바꿔줘", "태그 제거해줘", or "빨간색 파일들 찾아줘".
---

# macOS File Tags

## Overview

Manage macOS Finder color tags (빨간색, 주황색, 노란색, 초록색, 파란색, 보라색, 회색) on files and directories using the native tagging system. This skill provides operations to add, change, remove, list, and search files by their color tags.

## Prerequisites

This skill requires the `tag` command-line tool. If not installed, install it:

```bash
brew install tag
```

Verify installation:

```bash
which tag
# Should output: /opt/homebrew/bin/tag
```

## Core Operations

### 1. Check Current Tags

To see what tags are on a file:

```bash
tag -l "file_path"
```

Example output:
```
/Users/joon/Documents/report.pdf	빨간색
```

To verify tags are properly set in system metadata:

```bash
mdls -name kMDItemUserTags "file_path"
```

### 2. Add Tag (Append)

To add a tag without removing existing tags:

```bash
tag -a "tag_name" "file_path"
```

Use `-a` when the user says "add" or "달아줘" and wants to keep existing tags.

### 3. Set Tag (Replace)

To replace all existing tags with a new tag:

```bash
tag -s "tag_name" "file_path"
```

Use `-s` when the user says "change to" or "바꿔줘" - this replaces all existing tags.

### 4. Remove Specific Tag

To remove one specific tag:

```bash
tag -r "tag_name" "file_path"
```

### 5. Remove All Tags

To remove all tags from a file:

```bash
tag -r '*' "file_path"
```

### 6. Find Files by Tag

To search for all files with a specific tag:

```bash
mdfind "kMDItemUserTags == 'tag_name'"
```

To search in a specific directory only:

```bash
mdfind -onlyin /path/to/directory "kMDItemUserTags == 'tag_name'"
```

To count results:

```bash
mdfind "kMDItemUserTags == '빨간색'" | wc -l
```

### 7. Bulk Tag Multiple Files

To tag multiple files at once:

```bash
tag -a "초록색" file1.pdf file2.pdf file3.pdf
```

To tag all files in a directory:

```bash
find "/path/to/directory" -type f -name "*.pdf" -exec tag -a "보라색" {} \;
```

## macOS Color Tags

The standard color tags in Korean macOS systems:

| Korean | English | Common Usage |
|--------|---------|--------------|
| 빨간색 | Red | Urgent, important, high priority |
| 주황색 | Orange | Warning, needs review |
| 노란색 | Yellow | In progress, pending |
| 초록색 | Green | Complete, approved, ready |
| 파란색 | Blue | Reference, information |
| 보라색 | Purple | Personal, creative |
| 회색 | Gray | Archive, low priority |

**Important:** Tag names are case-sensitive and must match the system tag names exactly for colors to appear in Finder. Check system tag names with:

```bash
defaults read ~/Library/SyncedPreferences/com.apple.finder.plist FavoriteTagNames
```

## Common Workflows

### Workflow 1: User Asks to Tag a File

**User request:** "이 파일 빨간색 태그 달아줘"

**Steps:**
1. Verify file exists
2. Apply tag: `tag -s "빨간색" "file_path"`
3. Verify: `tag -l "file_path"`
4. Confirm to user with output

### Workflow 2: User Asks to Change Tag Color

**User request:** "파란색으로 바꿔줘" (referencing a file from context)

**Steps:**
1. Check current tags: `tag -l "file_path"`
2. Replace with new color: `tag -s "파란색" "file_path"`
3. Verify change: `tag -l "file_path"`
4. Confirm to user

### Workflow 3: User Asks to Find Tagged Files

**User request:** "빨간색 태그 파일들 찾아줘"

**Steps:**
1. Search: `mdfind "kMDItemUserTags == '빨간색'"`
2. Count results
3. Format and display list to user
4. Optionally show file details with `ls -lh`

### Workflow 4: User Asks to Remove Tags

**User request:** "태그 제거해줘"

**Steps:**
1. Check current tags: `tag -l "file_path"`
2. Remove all: `tag -r '*' "file_path"`
3. Verify removal: `tag -l "file_path"`
4. Confirm to user

### Workflow 5: Bulk Tag Files in Directory

**User request:** "이 폴더의 모든 PDF 파일을 초록색으로 태그해줘"

**Steps:**
1. Find PDFs: `find "directory" -type f -name "*.pdf"`
2. Apply tag: `find "directory" -type f -name "*.pdf" -exec tag -a "초록색" {} \;`
3. Count tagged files
4. Confirm completion

## Best Practices

1. **Always quote file paths** - Especially important for paths with spaces
2. **Use `-s` for replacing** - When user says "change to X" or "바꿔줘"
3. **Use `-a` for adding** - When user says "add X" or "달아줘"
4. **Verify after tagging** - Always run `tag -l` to confirm operation succeeded
5. **Use exact tag names** - Color tags must match system names exactly (빨간색, not 빨강)
6. **Check system language** - English systems use "Red", "Blue", etc. instead of Korean

## Troubleshooting

### Tags Don't Appear in Finder

**Problem:** Tags are set but no color appears in Finder

**Solutions:**
1. Verify using exact system tag names: check with `defaults read ~/Library/SyncedPreferences/com.apple.finder.plist FavoriteTagNames`
2. Refresh Finder by reopening the folder: `open "directory_path"`
3. Check Finder view settings (⌘J) ensure "Show tags" is enabled
4. In List View, add "Tags" column (right-click column headers)

### Tag Command Not Found

**Problem:** `tag: command not found`

**Solution:**
```bash
brew install tag
```

### Wrong Tag Language

**Problem:** Using "Red" on Korean system or "빨간색" on English system

**Solution:** Check system language and use appropriate tag names:
```bash
defaults read ~/Library/SyncedPreferences/com.apple.finder.plist FavoriteTagNames
```

## Output Format

After tagging operations, provide clear confirmation:

```
✅ 태그 적용 완료
파일: report.pdf
태그: 빨간색 🔴
```

For search results:

```
🔍 빨간색 태그 파일 (총 15개):

1. /Users/joon/Documents/report.pdf
2. /Users/joon/Documents/urgent.docx
3. /Users/joon/Documents/deadline.txt
...
```

## Resources

### references/

The `references/` directory contains detailed examples and advanced usage patterns:

- `tag-examples.md` - Comprehensive examples for search queries, bulk operations, conditional tagging, and integration with other tools

Refer to reference files when users request advanced operations like:
- Complex search queries (multiple tags, file type filters)
- Automation workflows
- Integration with Obsidian or git
- Performance optimization for large directories
