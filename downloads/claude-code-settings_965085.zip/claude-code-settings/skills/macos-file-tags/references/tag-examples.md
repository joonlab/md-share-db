# macOS File Tags - Advanced Examples

This reference provides comprehensive examples for advanced tag operations, search patterns, bulk workflows, and integrations.

## Advanced Search Patterns

### Multi-Tag Search (OR)

Find files with any of multiple tags:

```bash
mdfind "kMDItemUserTags == '빨간색' || kMDItemUserTags == '주황색'"
```

### Multi-Tag Search (AND)

Find files that have both tags:

```bash
mdfind "kMDItemUserTags == '빨간색' && kMDItemUserTags == '중요'"
```

### Search by File Type and Tag

Find all tagged PDFs:

```bash
mdfind "kMDItemUserTags == '빨간색' && kMDItemContentType == 'com.adobe.pdf'"
```

Find tagged markdown files:

```bash
mdfind "kMDItemUserTags == '초록색' && kMDItemFSName == '*.md'"
```

Find tagged images:

```bash
mdfind "kMDItemUserTags == '보라색' && kMDItemContentTypeTree == 'public.image'"
```

### Search in Specific Directory

```bash
mdfind -onlyin ~/Documents "kMDItemUserTags == '빨간색'"
```

### Search with File Details

```bash
mdfind "kMDItemUserTags == '파란색'" -0 | xargs -0 ls -lh
```

## Bulk Operations

### Tag All Files by Extension

Tag all PDF files:

```bash
find ~/Documents -type f -name "*.pdf" -exec tag -a "파란색" {} \;
```

Tag all markdown files recursively:

```bash
find ~/Documents -type f -name "*.md" -exec tag -a "노란색" {} \;
```

### Tag by File Age

Tag files modified in last 7 days:

```bash
find ~/Documents -type f -mtime -7 -exec tag -a "주황색" {} \;
```

Tag files older than 30 days:

```bash
find ~/Documents -type f -mtime +30 -exec tag -a "회색" {} \;
```

### Tag by File Size

Tag files larger than 10MB:

```bash
find ~/Documents -type f -size +10M -exec tag -a "회색" {} \;
```

Tag small files (less than 1MB):

```bash
find ~/Documents -type f -size -1M -exec tag -a "초록색" {} \;
```

### Batch Tag Replacement

Change all red tags to green in a directory:

```bash
for file in $(mdfind -onlyin ~/Documents "kMDItemUserTags == '빨간색'"); do
    tag -r "빨간색" "$file"
    tag -a "초록색" "$file"
done
```

### Remove All Tags from Directory

```bash
find ~/Documents -type f -exec tag -r '*' {} \;
```

## Conditional Tagging

### Tag Only If Not Already Tagged

```bash
find ~/Documents -name "*.pdf" -type f | while read file; do
    if [ -z "$(tag -l "$file" | cut -f2)" ]; then
        tag -a "파란색" "$file"
        echo "Tagged: $file"
    fi
done
```

### Tag Based on File Size

```bash
find ~/Documents -type f | while read file; do
    size=$(stat -f%z "$file")
    if [ $size -gt 10485760 ]; then
        tag -a "회색" "$file"  # Large files
    else
        tag -a "초록색" "$file"  # Small files
    fi
done
```

### Tag Based on Content

Tag files containing "TODO":

```bash
grep -rl "TODO" ~/Documents/*.md | while read file; do
    tag -a "주황색" "$file"
done
```

Tag files with "URGENT" in filename:

```bash
find ~/Documents -name "*URGENT*" -type f -exec tag -a "빨간색" {} \;
```

## Integration Examples

### Obsidian Vault Integration

Tag notes based on frontmatter status:

```bash
find "00. Inbox" -name "*.md" -type f | while read file; do
    if grep -q "status: unread" "$file"; then
        tag -s "빨간색" "$file"
    elif grep -q "status: reading" "$file"; then
        tag -s "노란색" "$file"
    elif grep -q "status: completed" "$file"; then
        tag -s "초록색" "$file"
    fi
done
```

Tag by CMDS category:

```bash
find . -name "*.md" | while read file; do
    if grep -q 'CMDS: ".*Tech News.*"' "$file"; then
        tag -a "파란색" "$file"
    elif grep -q 'CMDS: ".*Personal.*"' "$file"; then
        tag -a "보라색" "$file"
    fi
done
```

### Git Status Integration

Tag files based on git status:

```bash
cd ~/Projects/myapp

# Modified files - yellow
git diff --name-only | while read file; do
    [ -f "$file" ] && tag -s "노란색" "$file"
done

# Staged files - green
git diff --cached --name-only | while read file; do
    [ -f "$file" ] && tag -s "초록색" "$file"
done

# Untracked files - red
git ls-files --others --exclude-standard | while read file; do
    [ -f "$file" ] && tag -s "빨간색" "$file"
done
```

### Project Organization

Tag by project structure:

```bash
# Source code
find ~/Projects/myapp/src -name "*.js" -exec tag -a "파란색" {} \;

# Tests
find ~/Projects/myapp -name "*.test.js" -exec tag -a "초록색" {} \;

# Documentation
find ~/Projects/myapp -name "*.md" -exec tag -a "보라색" {} \;

# Configuration
find ~/Projects/myapp \( -name "*.json" -o -name "*.yaml" \) -exec tag -a "주황색" {} \;
```

## Reporting and Analysis

### Count Files by Tag

```bash
echo "=== File Count by Tag ==="
for tag_name in "빨간색" "주황색" "노란색" "초록색" "파란색" "보라색" "회색"; do
    count=$(mdfind "kMDItemUserTags == '$tag_name'" | wc -l | tr -d ' ')
    echo "$tag_name: $count files"
done
```

### List All Unique Tags

```bash
mdfind "kMDItemUserTags == '*'" | while read file; do
    tag -l "$file" | cut -f2
done | sort -u
```

### Find Untagged Files

```bash
find ~/Documents -type f | while read file; do
    if [ -z "$(tag -l "$file" | cut -f2)" ]; then
        echo "$file"
    fi
done
```

### Total Size by Tag

```bash
mdfind "kMDItemUserTags == '빨간색'" -0 | xargs -0 du -ch | tail -1
```

### Recently Tagged Files

```bash
mdfind "kMDItemUserTags == '*'" | while read file; do
    echo "$(stat -f%m "$file") $file"
done | sort -rn | head -10 | while read timestamp file; do
    echo "$(date -r $timestamp '+%Y-%m-%d %H:%M:%S') - $file"
done
```

### Files with Multiple Tags

```bash
find ~/Documents -type f | while read file; do
    tag_count=$(tag -l "$file" | cut -f2 | tr ' ' '\n' | wc -l | tr -d ' ')
    if [ $tag_count -gt 1 ]; then
        tags=$(tag -l "$file" | cut -f2)
        echo "$file: $tags"
    fi
done
```

## Automation Workflows

### Auto-Tag Downloads

Watch Downloads folder and auto-tag by file type:

```bash
#!/bin/bash
# Requires: brew install fswatch

fswatch -0 ~/Downloads | while read -d "" file; do
    if [ -f "$file" ]; then
        case "$file" in
            *.pdf)
                tag -a "파란색" "$file"
                echo "Tagged PDF: $file"
                ;;
            *.zip|*.tar.gz|*.dmg)
                tag -a "회색" "$file"
                echo "Tagged archive: $file"
                ;;
            *.jpg|*.png|*.gif)
                tag -a "보라색" "$file"
                echo "Tagged image: $file"
                ;;
            *.mov|*.mp4|*.avi)
                tag -a "주황색" "$file"
                echo "Tagged video: $file"
                ;;
        esac
    fi
done
```

### Clean Old Tags

Remove tags from files older than 30 days:

```bash
#!/bin/bash

find ~/Documents -type f -mtime +30 | while read file; do
    current_tags=$(tag -l "$file" | cut -f2)
    if [ ! -z "$current_tags" ]; then
        tag -r '*' "$file"
        echo "Removed tags from: $file"
    fi
done
```

### Tag Cleanup Script

Remove duplicate tags:

```bash
#!/bin/bash

find ~/Documents -type f | while read file; do
    tags=$(tag -l "$file" | cut -f2 | tr ' ' '\n' | sort -u | tr '\n' ' ')
    if [ ! -z "$tags" ]; then
        tag -s $tags "$file"
    fi
done
```

## Performance Tips

### Batch Commands

Instead of looping with individual tag commands:

```bash
# Slower
for file in *.pdf; do
    tag -a "파란색" "$file"
done

# Faster
files=$(find . -name "*.pdf")
tag -a "파란색" $files
```

### Parallel Processing

For large operations:

```bash
find ~/Documents -name "*.pdf" -print0 | xargs -0 -P 4 -I {} tag -a "파란색" {}
```

The `-P 4` flag runs 4 parallel processes.

### Cache Search Results

```bash
# Cache results for reuse
red_files=$(mdfind "kMDItemUserTags == '빨간색'")

# Use cached results
echo "$red_files" | wc -l
echo "$red_files" | head -10
echo "$red_files" | grep ".pdf"
```

## Edge Cases

### Files with Spaces

Always quote file paths:

```bash
tag -a "빨간색" "/Users/joon/Documents/My Report.pdf"
```

### Files with Special Characters

```bash
tag -a "빨간색" "/Users/joon/Documents/\"Special\" File.pdf"
tag -a "파란색" "/Users/joon/Documents/문서_2024.pdf"
```

### Custom Non-Color Tags

Tags that won't show color in Finder but are still useful:

```bash
tag -a "중요" "document.pdf"
tag -a "검토필요" "draft.docx"
tag -a "2024" "report.pdf"
```

Mix color and custom tags:

```bash
tag -a "빨간색" -a "중요" -a "프로젝트A" "file.pdf"
```

### Handling Symlinks

Tag the symlink itself:

```bash
tag -a "파란색" "/path/to/symlink"
```

Tag the symlink target:

```bash
tag -a "빨간색" "$(readlink /path/to/symlink)"
```

Tag both:

```bash
link="/path/to/symlink"
tag -a "초록색" "$link" "$(readlink "$link")"
```

## Debugging

### Check Tag Command

```bash
which tag
tag --version
```

### Check Extended Attributes

```bash
xattr -l "file.pdf"
```

### Check Spotlight Metadata

```bash
mdls "file.pdf" | grep -i tag
```

### Force Spotlight Reindex

```bash
mdimport "file.pdf"
```

### Verify System Tag Names

```bash
defaults read ~/Library/SyncedPreferences/com.apple.finder.plist FavoriteTagNames
```

### Test Tag and Search

```bash
# Tag a test file
tag -s "빨간색" "test.pdf"

# Wait for Spotlight
sleep 2

# Verify metadata
mdls -name kMDItemUserTags "test.pdf"

# Search for it
mdfind "kMDItemUserTags == '빨간색' && kMDItemFSName == 'test.pdf'"
```
