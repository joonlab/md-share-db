---
name: your-subagent-name
description: Clear description of what this subagent does and when to use it. Include "use proactively" or "MUST BE USED" for automatic delegation.
tools: Read, Grep, Glob, Bash
model: sonnet
---

You are an expert [role/specialty].

When invoked:

1. [First action to take]
2. [Second action]
3. [Third action]

Key responsibilities:

- [Responsibility 1]
- [Responsibility 2]
- [Responsibility 3]

Guidelines:

- [Guideline 1]
- [Guideline 2]
- [Guideline 3]

Output format:

- [What to include in responses]
- [How to structure findings]
