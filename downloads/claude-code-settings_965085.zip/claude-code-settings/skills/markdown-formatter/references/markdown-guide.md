# Markdown Formatting Reference Guide

This reference provides comprehensive markdown syntax examples and edge cases for the markdown-formatter skill.

## Table of Contents

1. [Heading Syntax](#heading-syntax)
2. [List Syntax](#list-syntax)
3. [Table Syntax](#table-syntax)
4. [Code Block Syntax](#code-block-syntax)
5. [Emphasis Syntax](#emphasis-syntax)
6. [Link Syntax](#link-syntax)
7. [Edge Cases](#edge-cases)

---

## Heading Syntax

### Basic Heading Levels

```markdown
# H1 - Document Title (use once)
## H2 - Major Section
### H3 - Subsection
#### H4 - Detailed Section
##### H5 - Rarely Used
###### H6 - Rarely Used
```

### Alternative H1/H2 Syntax (Setext)

These are equivalent but less common:

```markdown
H1 Document Title
=================

H2 Major Section
----------------
```

**Recommendation:** Use `#` syntax consistently for clarity.

### Heading Guidelines

- **Only one H1** per document (document title)
- Don't skip heading levels (H2 → H4 is incorrect)
- Keep headings concise (5-10 words max)
- Use sentence case or title case consistently
- Add blank line before and after headings

**Good example:**
```markdown
# User Authentication Guide

## Setup Instructions

### Installing Dependencies

Content here...

### Configuration

Content here...

## Usage Examples

Content here...
```

**Bad example:**
```markdown
# User Authentication Guide
#### Installing Dependencies (skipped H2, H3)
Content here...
### Configuration (wrong level)
```

---

## List Syntax

### Unordered Lists

Three markers are valid, but `-` is recommended for consistency:

```markdown
- Item 1
- Item 2
- Item 3

* Item 1
* Item 2

+ Item 1
+ Item 2
```

### Ordered Lists

```markdown
1. First item
2. Second item
3. Third item
```

**Note:** Numbers can all be `1.` and markdown will auto-number:

```markdown
1. First item
1. Second item
1. Third item
```

This renders correctly but is less readable in source.

### Nested Lists

Indent with **2 spaces** per level:

```markdown
- Item 1
  - Nested item 1.1
  - Nested item 1.2
    - Deeply nested item 1.2.1
- Item 2
  - Nested item 2.1
```

Mixed ordered and unordered:

```markdown
1. First step
   - Important point
   - Another point
2. Second step
   - Sub-point A
   - Sub-point B
```

### Lists with Multiple Paragraphs

Indent continuation paragraphs with 2-4 spaces:

```markdown
- First item

  This is a continuation paragraph for the first item.

  This is another paragraph.

- Second item

  Continuation for second item.
```

### Lists with Code Blocks

Indent code blocks with 4 spaces (or 1 tab):

```markdown
1. Install the package

    ```bash
    npm install package-name
    ```

2. Import it in your code

    ```javascript
    import package from 'package-name';
    ```
```

### Task Lists (GitHub-Flavored Markdown)

```markdown
- [ ] Incomplete task
- [x] Complete task
- [ ] Another incomplete task
```

---

## Table Syntax

### Basic Table

```markdown
| Header 1 | Header 2 | Header 3 |
|----------|----------|----------|
| Cell 1   | Cell 2   | Cell 3   |
| Cell 4   | Cell 5   | Cell 6   |
```

### Column Alignment

```markdown
| Left-aligned | Center-aligned | Right-aligned |
|:-------------|:--------------:|--------------:|
| Left         | Center         | Right         |
| Text         | Text           | 123           |
```

- `:---` = left-aligned (default)
- `:---:` = center-aligned
- `---:` = right-aligned

### Tables with Varying Column Widths

Markdown doesn't enforce column width—renderers handle it. For source readability, align manually:

```markdown
| Name       | Description                  | Price  |
|------------|------------------------------|--------|
| Product A  | Short description            | $10.00 |
| Product B  | Much longer description here | $25.50 |
```

### Tables with Inline Code

```markdown
| Function      | Description                    |
|---------------|--------------------------------|
| `print()`     | Outputs text to console        |
| `len()`       | Returns length of object       |
| `range(n)`    | Generates sequence of numbers  |
```

### Tables with Links

```markdown
| Resource   | Link                                    |
|------------|-----------------------------------------|
| Docs       | [Documentation](https://example.com)    |
| Source     | [GitHub](https://github.com/repo)       |
```

### Escaping Pipe Characters

If data contains `|`, escape it with backslash:

```markdown
| Command           | Description              |
|-------------------|--------------------------|
| `echo "a \| b"`   | Prints "a \| b"          |
```

### Complex Tables (When to Avoid)

Markdown tables work best for simple data. For complex tables with:
- Merged cells
- Multi-line cell content
- Complex formatting

Consider using HTML tables or simplifying the data structure.

---

## Code Block Syntax

### Fenced Code Blocks (Recommended)

Use triple backticks with language identifier:

````markdown
```python
def hello():
    print("Hello, World!")
```
````

### Indented Code Blocks (Legacy)

Indent with 4 spaces or 1 tab:

```markdown
    def hello():
        print("Hello, World!")
```

**Problem:** No syntax highlighting, less clear in source.

### Common Language Identifiers

```
python, javascript, java, c, cpp, csharp, php, ruby, go, rust
html, css, scss, json, xml, yaml, toml
bash, shell, sh, powershell, cmd
sql, mysql, postgresql
markdown, md
plaintext, text (for no highlighting)
```

### Code Blocks with Line Numbers

Some renderers support:

````markdown
```python {linenos=true}
def hello():
    print("Hello")
```
````

This is not universal markdown—check renderer support.

### Highlighting Specific Lines

Some renderers support:

````markdown
```python {hl_lines="2 3"}
def hello():
    print("Hello")  # highlighted
    return True     # highlighted
```
````

Again, not universal.

### Inline Code

Use single backticks:

```markdown
Use the `print()` function to output text.
The file is located at `/usr/local/bin/app`.
```

### Escaping Backticks in Inline Code

Use double backticks:

```markdown
To show a backtick, use ``code with `backtick` inside``.
```

### Code Blocks in Lists

Indent by 4 spaces (or 1 tab) within list item:

```markdown
1. First step

    ```python
    import package
    ```

2. Second step
```

---

## Emphasis Syntax

### Bold

```markdown
**bold text**
__also bold__
```

Recommendation: Use `**` for consistency.

### Italic

```markdown
*italic text*
_also italic_
```

Recommendation: Use `*` for consistency.

### Bold + Italic

```markdown
***bold and italic***
___also bold and italic___
**_mixed syntax_**
*__mixed syntax__*
```

### Strikethrough (GitHub-Flavored Markdown)

```markdown
~~strikethrough text~~
```

### Underline

Pure markdown doesn't support underline. Use HTML if needed:

```html
<u>underlined text</u>
```

### Emphasis Best Practices

- Use bold for **key terms** and **important concepts**
- Use italic for *subtle emphasis*, *definitions*, *foreign words*
- Don't overuse—too much emphasis = no emphasis
- Be consistent with marker choice (`*` vs `_`)

---

## Link Syntax

### Inline Links

```markdown
[Link text](https://example.com)
[Link with title](https://example.com "Title on hover")
```

### Reference-Style Links

Define links separately:

```markdown
[Link text][1]
[Another link][2]

[1]: https://example.com
[2]: https://example.com/page
```

Or use implicit reference:

```markdown
[GitHub]

[GitHub]: https://github.com
```

### Autolinks

```markdown
<https://example.com>
<email@example.com>
```

Some parsers auto-detect URLs without brackets:

```markdown
https://example.com
```

### Internal Links (Heading Anchors)

Link to headings within the same document:

```markdown
[Go to Installation](#installation)

## Installation

Content here...
```

**Note:** Heading anchor = lowercase heading text with spaces replaced by hyphens.

### Links with Inline Code

```markdown
See the [`print()`](https://docs.python.org/3/library/functions.html#print) function.
```

### Image Links

```markdown
[![Alt text](image.png)](https://example.com)
```

Clicking the image opens the link.

---

## Edge Cases

### Escaping Markdown Characters

Use backslash to escape:

```markdown
\* Not a bullet point
\# Not a heading
\[Not a link\](test)
```

### Horizontal Rules

Three or more hyphens, asterisks, or underscores:

```markdown
---
***
___
```

Recommendation: Use `---` for consistency.

### Blockquotes

```markdown
> This is a quote.
> It can span multiple lines.

> Nested quote:
>> Second level
>>> Third level
```

### Mixing HTML

Markdown supports inline HTML:

```markdown
This is **markdown** and <strong>HTML</strong>.

<div class="custom">
Custom HTML block
</div>
```

**Note:** This breaks portability—use sparingly.

### Empty Lines in Lists

Too many empty lines break the list:

```markdown
- Item 1

- Item 2  ✅ (still part of list)


- Item 3  ❌ (new list started)
```

### Hard Line Breaks

End line with 2+ spaces or backslash:

```markdown
Line 1
Line 2 (two spaces above)

Line 1\
Line 2 (backslash above)
```

Otherwise lines flow together:

```markdown
Line 1
Line 2
(renders as "Line 1 Line 2")
```

### Special Characters in Headings

Avoid special characters that conflict with anchor generation:

```markdown
## What is C++?  ✅
## What is C++??? ⚠️ (multiple ? may cause issues)
## (1) First Section ⚠️ (parentheses may cause issues)
```

### Zero-Width Spaces

Invisible characters can break syntax:

```markdown
- Item​1 (contains zero-width space)
```

Hard to detect visually—watch for formatting issues.

### Nested Emphasis

Nesting different emphasis types works:

```markdown
*italic with **bold inside** more italic*
**bold with *italic inside* more bold**
```

Nesting same type requires different markers:

```markdown
*italic with _more italic_ back to italic*
```

---

## Platform-Specific Markdown

### GitHub-Flavored Markdown (GFM)

Adds:
- Task lists `- [ ]`
- Strikethrough `~~text~~`
- Tables (shown above)
- Auto-linked URLs
- Emoji `:smile:` → 😄

### Obsidian Markdown

Adds:
- Wikilinks `[[Note Name]]`
- Callouts `> [!note]`
- Embedded notes `![[Note]]`
- Math `$equation$` and `$$block$$`

### CommonMark

Strict markdown standard—most compatible.

### When Formatting for Different Platforms

- **GitHub README:** Use GFM features (tables, task lists)
- **General documentation:** Stick to CommonMark for max compatibility
- **Obsidian vault:** Use Obsidian-specific syntax freely
- **Blog/website:** Check your static site generator's markdown flavor

---

## Validation Tips

### Check Rendering

Always preview formatted markdown in target environment:
- GitHub: Use preview tab in editor
- VS Code: Use markdown preview (Cmd/Ctrl+Shift+V)
- Obsidian: Live preview mode

### Common Rendering Issues

1. **Lists not rendering:** Check for proper blank lines and indentation
2. **Code blocks showing raw:** Missing language identifier or mismatched backticks
3. **Tables malformed:** Incorrect number of pipes per row
4. **Links broken:** URL encoding issues or incorrect syntax
5. **Headings not working:** Missing space after `#`

### Linting Tools

Use markdown linters to catch issues:
- `markdownlint` - VS Code extension
- `remark` - CLI tool
- Online validators

---

## Quick Reference

### Most Common Syntax

```markdown
# Heading 1
## Heading 2
### Heading 3

**bold** and *italic*

- Unordered list
- Another item

1. Ordered list
2. Another item

[Link](https://example.com)

`inline code`

```python
# code block
print("Hello")
```

| Table | Header |
|-------|--------|
| Cell  | Cell   |

> Blockquote

---

Horizontal rule
```

---

This reference guide should cover most markdown formatting scenarios. Refer back to it when handling edge cases or uncommon syntax during formatting tasks.
