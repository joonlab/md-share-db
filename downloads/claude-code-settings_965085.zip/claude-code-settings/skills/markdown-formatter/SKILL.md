---
name: markdown-formatter
description: Transform plain text, web content, or poorly formatted markdown into well-structured, standard-compliant markdown documents. Use this skill when users provide content and ask to format it as markdown, or when they say "format this", "마크다운으로 정리해줘", "clean up this text". Analyzes content structure to apply appropriate markdown syntax including headings, lists, tables, code blocks, and emphasis.
---

# Markdown Formatter

## Overview

Transform any content—plain text, web clippings, AI-generated output, or messy markdown—into clean, well-structured markdown documents. This skill intelligently analyzes content structure and applies appropriate markdown syntax to enhance readability and organization.

## When to Use This Skill

Use this skill when:
- User provides content and requests markdown formatting
- Plain text needs structure and markdown syntax
- Web content or copied text needs cleanup
- AI-generated content needs proper markdown formatting
- Poorly formatted markdown needs standardization
- Lists, tables, or code blocks need proper syntax

**Trigger phrases:**
- "Format this as markdown"
- "마크다운으로 정리해줘"
- "Clean up this text"
- "Convert to markdown"
- "Make this markdown"

**Do NOT use this skill when:**
- Content is already well-formatted markdown
- User wants to preserve exact original formatting
- Request is for specialized vault formats (use cmds-doc-formatter instead)

## Workflow: 6-Step Markdown Transformation

Follow these steps in order to transform any content into clean markdown:

### Step 1: Analyze Content Structure

Before applying any formatting, understand the content structure by identifying:

**Hierarchical elements:**
- Main title (will become H1)
- Major sections (will become H2)
- Subsections (will become H3-H6)
- Logical groupings and boundaries

**Content types:**
- Paragraphs and body text
- Lists (ordered/unordered/nested)
- Tabular or structured data
- Code snippets or technical content
- Quotes or callouts
- Emphasis patterns (bold/italic)

**Action items:**
1. Read through entire content once
2. Identify the main topic and major sections
3. Note patterns that indicate structure (numbering, indentation, repetition)
4. Look for content that should be tables, lists, or code blocks
5. Identify relationships between sections

---

### Step 2: Apply Heading Hierarchy

Create clear document structure with proper heading levels.

**Heading rules:**
- **H1 (`#`)** - Document title (only ONE per document)
- **H2 (`##`)** - Major sections
- **H3 (`###`)** - Subsections under H2
- **H4 (`####`)** - Detailed breakdowns
- **H5-H6** - Rarely needed, only for very deep nesting

**Pattern recognition:**
- ALL CAPS or larger font → Likely heading
- Numbers (1., 2., 3.) at start of major sections → Likely H2
- Bold text at start of paragraph → Possibly heading
- Short lines followed by longer content → Likely heading

**Before:**
```
Introduction to Markdown
Markdown is a lightweight markup language.

What is Markdown?
Markdown was created by John Gruber...

Basic Syntax
Headers
You can create headers using #...
```

**After:**
```markdown
# Introduction to Markdown

Markdown is a lightweight markup language.

## What is Markdown?

Markdown was created by John Gruber...

## Basic Syntax

### Headers

You can create headers using #...
```

**Action items:**
1. Identify document title and make it H1
2. Find major section breaks and make them H2
3. Add H3 for subsections under each H2
4. Ensure hierarchy doesn't skip levels (H2 → H4 ❌)
5. Keep headings concise and descriptive

---

### Step 3: Format Lists Properly

Convert irregular lists into clean, consistent markdown lists.

**List types:**
- **Unordered lists:** Use `-` (hyphen + space)
- **Ordered lists:** Use `1.` `2.` `3.` (number + period + space)
- **Nested lists:** Indent with 2 spaces per level

**Pattern recognition:**
- Lines starting with `-`, `*`, `•`, `●` → Unordered list
- Lines starting with numbers `1.`, `2.)`, `(1)` → Ordered list
- Indented items → Nested lists
- Consistent item structure → Likely list

**Before (irregular):**
```
* Item one
• Item two
  - Nested item
* Item three

1) First step
2) Second step
  a) Sub-step
```

**After (clean):**
```markdown
- Item one
- Item two
  - Nested item
- Item three

1. First step
2. Second step
   - Sub-step
```

**Action items:**
1. Normalize all unordered list markers to `-`
2. Ensure ordered lists use `1. 2. 3.` format
3. Fix nested list indentation (2 spaces per level)
4. Remove extra blank lines within lists
5. Ensure consistent spacing (blank line before/after list)

---

### Step 4: Create Tables from Structured Data

Identify repeated structures and convert them to markdown tables.

**When to create tables:**
- Data with consistent attributes across multiple items
- Comparisons (features, specs, options)
- Name-value pairs repeated multiple times
- Directory listings with descriptions
- Any tabular layout in original content

**Pattern recognition:**
- Multiple lines with same structure (e.g., "Name: Value")
- Comparison lists with similar attributes
- Consistent delimiters (|, :, -, tabs)
- Grid-like visual arrangement

**Before (structured list):**
```
Name: Python, Type: Interpreted, Year: 1991
Name: JavaScript, Type: Interpreted, Year: 1995
Name: Go, Type: Compiled, Year: 2009
```

**After (table):**
```markdown
| Name       | Type        | Year |
|------------|-------------|------|
| Python     | Interpreted | 1991 |
| JavaScript | Interpreted | 1995 |
| Go         | Compiled    | 2009 |
```

**Table formatting rules:**
- First row: Headers
- Second row: Separator with hyphens
- Left-align text columns, right-align numbers
- Use consistent spacing for readability

**Action items:**
1. Identify repeating data patterns
2. Extract column headers from data structure
3. Create table with proper pipe syntax
4. Align columns for visual clarity
5. Ensure all rows have same number of columns

---

### Step 5: Format Code Blocks and Technical Content

Detect code snippets and technical content, then apply proper code block syntax.

**Code block detection patterns:**
- Indented text with syntax characters (`{`, `}`, `;`, `()`)
- Commands or terminal output
- File paths or URLs (when grouped together)
- Function names with parentheses
- Programming keywords (function, class, import, def, etc.)
- Consistent indentation patterns

**Inline code detection:**
- Short technical terms mid-sentence
- Function names, variables, file names
- Commands, paths, or URLs
- API endpoints or keys

**Language identification:**
```
Keywords/patterns → Language
import, def, print() → python
function, const, => → javascript
func, package, := → go
<html>, <div> → html
$, sudo, apt-get → bash
SELECT, FROM, WHERE → sql
```

**Before (plain text):**
```
Here's a Python example:
def hello():
    print("Hello, World!")

To run it, use: python script.py
```

**After (formatted):**
````markdown
Here's a Python example:

```python
def hello():
    print("Hello, World!")
```

To run it, use: `python script.py`
````

**Action items:**
1. Identify code blocks (3+ lines with code patterns)
2. Wrap with triple backticks and language identifier
3. Find inline technical terms and wrap with single backticks
4. Preserve exact indentation within code blocks
5. Don't modify code content—only wrap it

---

### Step 6: Apply Text Emphasis and Final Polish

Add appropriate emphasis and perform final readability improvements.

**Emphasis patterns:**
- **Bold (`**text**`)** for key terms, labels, important concepts
- *Italic (`*text*`)* for emphasis, foreign words, definitions
- `Code (`text`)` for technical terms (already handled in Step 5)

**Pattern recognition:**
- ALL CAPS words → Consider making bold
- "Important:", "Note:", "Key point:" → Bold the label
- Quotes around concepts → Consider italic or bold
- Repeated emphasis patterns → Standardize

**Readability checklist:**
- [ ] Paragraphs broken into 3-5 sentence chunks
- [ ] Blank line between paragraphs
- [ ] Blank line before/after headings
- [ ] Blank line before/after lists
- [ ] Blank line before/after code blocks
- [ ] Blank line before/after tables
- [ ] No more than 2 consecutive blank lines
- [ ] Consistent line length (avoid extremely long lines)

**Before (wall of text):**
```
Markdown is a LIGHTWEIGHT markup language. You can use it to format text using simple syntax. It was created by John Gruber in 2004. The main goal was readability. It's now used everywhere including GitHub, Reddit, and Stack Overflow.
```

**After (polished):**
```markdown
Markdown is a **lightweight markup language**. You can use it to format text using simple syntax.

It was created by John Gruber in 2004. The main goal was *readability*.

It's now used everywhere including GitHub, Reddit, and Stack Overflow.
```

**Action items:**
1. Break long paragraphs into readable chunks
2. Add bold emphasis to key terms (sparingly)
3. Use italic for subtle emphasis
4. Ensure proper spacing throughout document
5. Remove excessive blank lines
6. Check for consistent formatting patterns

---

## Output Guidelines

### Present the Formatted Result

After formatting, present the complete markdown document:

1. **Show the full formatted document** (don't truncate)
2. **Provide a brief summary** of changes made
3. **Ask if adjustments needed** (heading levels, table creation, etc.)

**Example summary format:**
```
✅ Markdown formatting complete:
- Added hierarchical headings (H1-H3)
- Formatted 3 lists with proper syntax
- Created 2 tables from structured data
- Wrapped 5 code blocks with language identifiers
- Applied emphasis to key terms
- Improved spacing and readability
```

### Save to File (If Requested)

If user requests saving:
- Use descriptive filename: `formatted-content.md`
- Save to current directory or user-specified path
- Confirm file location after saving

---

## Special Content Handling

### Web Clippings

Web content often has artifacts that need removal:

**Remove:**
- Navigation elements (Home, Back, Menu)
- Timestamps and metadata (unless relevant)
- Duplicate content (headers/footers)
- Advertisement markers
- HTML artifacts (`&nbsp;`, `<div>`, etc.)

**Extract:**
- Main content only
- Meaningful headings
- Actual data and lists

### AI-Generated Content

AI outputs often need:
- Structure improvement (add headings)
- List formatting (convert prose to lists)
- Code block wrapping (code is often inline)
- Emphasis addition (AI text is often flat)

### Mixed Language Content

When content has multiple languages (e.g., Korean + English):
- Preserve language mixing
- Keep technical terms in original language
- Don't translate unless requested

### Preserving Links

**Inline links:**
```markdown
[Link text](https://example.com)
```

**Reference-style links** (for many links):
```markdown
[Link text][1]

[1]: https://example.com
```

---

## Common Formatting Patterns

### Documentation Structure

```markdown
# Project Title

Brief description of the project.

## Installation

Step-by-step installation instructions.

## Usage

How to use the project.

## API Reference

API documentation.
```

### Tutorial Structure

```markdown
# Tutorial Title

## Introduction

What you'll learn.

## Prerequisites

What you need before starting.

## Step 1: Setup

Instructions...

## Step 2: Implementation

Instructions...

## Conclusion

Summary and next steps.
```

### Article/Blog Structure

```markdown
# Article Title

Brief introduction.

## Main Point 1

Content...

## Main Point 2

Content...

## Conclusion

Final thoughts.
```

---

## Quality Checklist

Before completing, verify:

- [ ] Single H1 title at document start
- [ ] Logical heading hierarchy (no skipped levels)
- [ ] All lists properly formatted
- [ ] Tables aligned and complete
- [ ] Code blocks have language identifiers
- [ ] Inline code marked with backticks
- [ ] Appropriate bold/italic emphasis
- [ ] Consistent spacing throughout
- [ ] No HTML artifacts remaining
- [ ] Links properly formatted
- [ ] Document is readable and scannable

---

## Examples

### Example 1: Plain Text → Markdown

**Input:**
```
INTRODUCTION TO PYTHON
Python is a high-level programming language. It's used for:
Web development
Data analysis
Machine learning
Basic syntax example:
print("Hello, World!")
```

**Output:**
```markdown
# Introduction to Python

Python is a high-level programming language. It's used for:

- Web development
- Data analysis
- Machine learning

Basic syntax example:

```python
print("Hello, World!")
```
```

### Example 2: Structured Data → Table

**Input:**
```
Product: Laptop | Price: $999 | Stock: Yes
Product: Mouse | Price: $25 | Stock: Yes
Product: Monitor | Price: $299 | Stock: No
```

**Output:**
```markdown
| Product | Price | Stock |
|---------|-------|-------|
| Laptop  | $999  | Yes   |
| Mouse   | $25   | Yes   |
| Monitor | $299  | No    |
```

---

## Success Criteria

Formatting is complete when:
- ✅ Content has clear hierarchical structure
- ✅ All lists are properly formatted
- ✅ Structured data converted to tables where appropriate
- ✅ Code blocks wrapped with correct syntax
- ✅ Appropriate emphasis applied
- ✅ Document is readable and well-spaced
- ✅ Markdown syntax is valid and consistent
- ✅ User confirms satisfaction with formatting
