# Safety

- Do not share sensitive information with the council.
