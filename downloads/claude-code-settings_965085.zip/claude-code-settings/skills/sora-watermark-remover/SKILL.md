---
name: sora-watermark-remover
description: Remove watermarks from Sora-generated videos. Use this skill when the user requests to remove watermarks from Sora video files or asks to process Sora-generated videos. The skill processes video files and saves the cleaned output to /Users/joon/Downloads with a timestamped filename prefix.
---

# Sora Watermark Remover

## Overview

Remove watermarks from Sora-generated videos using the SoraWatermarkCleaner library. This skill detects and removes the Sora watermark overlay from videos, outputting clean video files to the Downloads folder.

## When to Use This Skill

Use this skill when the user:
- Requests to "remove watermark from Sora video"
- Provides a Sora video file path and asks to clean it
- Says "워터마크 제거해줘" or similar Korean phrases about watermark removal
- Wants to process Sora-generated videos to remove branding

**Example user requests:**
- "Remove the watermark from this Sora video: /path/to/video.mp4"
- "이 Sora 비디오에서 워터마크 제거해줘"
- "Clean this Sora video and save it to Downloads"

## Prerequisites

Verify that the SoraWatermarkCleaner package is installed:

```python
try:
    from sorawm.core import SoraWM
    from sorawm.schemas import CleanerType
except ImportError:
    print("SoraWatermarkCleaner not installed.")
    print("Install from: https://github.com/linkedlist771/SoraWatermarkCleaner")
    print("\nInstallation steps:")
    print("1. git clone https://github.com/linkedlist771/SoraWatermarkCleaner")
    print("2. cd SoraWatermarkCleaner && uv sync")
    print("3. source .venv/bin/activate")
```

If not installed, inform the user and provide installation instructions.

## Quick Start

To remove a watermark from a Sora video, use the `scripts/remove_watermark.py` script with the SoraWatermarkCleaner environment:

```bash
source .venv/bin/activate && PYTHONPATH=/Users/joon/Desktop/sora-watermark-removal:$PYTHONPATH python scripts/remove_watermark.py "<video_path>"
```

The script will:
1. Validate the input video file exists
2. Detect watermark locations using YOLO model
3. Remove watermarks using the specified cleaner
4. Save the output to `/Users/joon/Downloads/watermark_removed_{timestamp}_{original_filename}`

**Example workflow:**
```python
# User request: "워터마크 제거해줘: /Users/joon/Downloads/video.mp4"

# Execute the removal script with proper environment
result = bash(
    'source .venv/bin/activate && '
    'PYTHONPATH=/Users/joon/Desktop/sora-watermark-removal:$PYTHONPATH '
    'python /Users/joon/.claude/skills/sora-watermark-remover/scripts/remove_watermark.py '
    '"/Users/joon/Downloads/video.mp4"'
)

# Inform user of the output location
print("✅ Watermark removed successfully!")
print(f"📁 Output saved to: /Users/joon/Downloads/watermark_removed_{timestamp}_video.mp4")
```

## Cleaner Types

Two cleaner types are available:

### 1. LAMA (Default, Recommended)
- **Speed:** Fast processing
- **Quality:** Good quality, may have slight flicker on the cleaned area
- **Best for:** Most use cases, quick processing needed
- **Usage:** `--cleaner-type LAMA` (default, can be omitted)

### 2. E2FGVI_HQ
- **Speed:** Fast on Apple Silicon (MPS), moderate on CPU, fastest on CUDA
- **Quality:** Time-consistent, no flicker
- **Best for:** When temporal consistency is critical, especially on macOS with Apple Silicon
- **Usage:** `--cleaner-type E2FGVI_HQ`
- **Apple Silicon Performance:** ~7x faster than CPU thanks to MPS acceleration (30-40 min for typical videos)

**Selection guidance:**
- Default to LAMA for quickest results (under 1 minute for most videos)
- Recommend E2FGVI_HQ when the user explicitly needs flicker-free, time-consistent output
- E2FGVI_HQ now works well on Apple Silicon Macs (M1/M2/M3) with GPU acceleration
- On non-Apple hardware without CUDA, E2FGVI_HQ will be slower (CPU fallback)

**Example with E2FGVI_HQ:**
```bash
source .venv/bin/activate && PYTHONPATH=/Users/joon/Desktop/sora-watermark-removal:$PYTHONPATH python scripts/remove_watermark.py "/path/to/video.mp4" --cleaner-type E2FGVI_HQ
```

## Output File Naming

Output files are automatically saved to `/Users/joon/Downloads/` with the naming pattern:

```
watermark_removed_{timestamp}_{original_filename}
```

Where:
- `{timestamp}`: Current time in `YYYYMMDD_HHMMSS` format
- `{original_filename}`: The original input filename

**Example:**
```
Input:  /Users/joon/Downloads/sora_video.mp4
Output: /Users/joon/Downloads/watermark_removed_20250124_143022_sora_video.mp4
```

## Error Handling

Handle common errors gracefully:

1. **Missing input file:**
   - Verify the file path exists before processing
   - Inform the user if the path is invalid

2. **Package not installed:**
   - Check for `sorawm` package availability
   - Provide installation instructions if missing

3. **Processing errors:**
   - Catch and report any processing exceptions
   - Clean up partial output files on failure

4. **User interruption:**
   - Handle `KeyboardInterrupt` (Ctrl+C) gracefully
   - Exit with appropriate status code (130)

## Resources

### scripts/

**`remove_watermark.py`** - Main watermark removal script
- Takes video file path as input argument
- Optionally accepts `--cleaner-type` parameter (LAMA or E2FGVI_HQ)
- Outputs processed video to `/Users/joon/Downloads/` with timestamped filename
- Provides progress feedback during processing
- Handles errors and edge cases

Execute directly via Bash tool when the user requests watermark removal.

## Implementation Notes

- Always use absolute paths for video files
- Default to LAMA cleaner unless user specifies otherwise
- Provide progress updates during long-running operations
- Report the final output path to the user after successful completion
- The script automatically creates the output directory if it doesn't exist

### Performance Optimization

**Apple Silicon GPU Acceleration:**
- The E2FGVI_HQ cleaner now supports MPS (Metal Performance Shaders) for GPU acceleration on Apple Silicon Macs
- MPS support provides ~7x speed improvement over CPU processing
- The optimization automatically detects and uses MPS when available
- Fallback padding mode is used to maintain compatibility (border → zeros)

**Platform-specific performance:**
- **Apple Silicon (M1/M2/M3):** E2FGVI_HQ uses MPS GPU acceleration (~30-40 min for typical videos)
- **CUDA-enabled GPUs:** E2FGVI_HQ uses CUDA for fastest processing
- **CPU only:** E2FGVI_HQ falls back to CPU (significantly slower, 60+ min)
