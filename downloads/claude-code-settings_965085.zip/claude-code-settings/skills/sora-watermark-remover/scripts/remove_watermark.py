#!/usr/bin/env python3
"""
Sora Watermark Removal Script

This script removes watermarks from Sora-generated videos using the SoraWatermarkCleaner library.
It takes a video file path as input and outputs the cleaned video to /Users/joon/Downloads
with a timestamped filename.

Usage:
    python remove_watermark.py <input_video_path> [--cleaner-type <LAMA|E2FGVI_HQ>]

Example:
    python remove_watermark.py "/path/to/video.mp4"
    python remove_watermark.py "/path/to/video.mp4" --cleaner-type E2FGVI_HQ
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path


def remove_watermark(input_video_path: str, cleaner_type: str = "LAMA") -> Path:
    """
    Remove watermark from a Sora video file.
    
    Args:
        input_video_path: Path to the input video file
        cleaner_type: Type of cleaner to use (LAMA or E2FGVI_HQ)
        
    Returns:
        Path to the output video file
        
    Raises:
        ImportError: If sorawm package is not installed
        FileNotFoundError: If input video file does not exist
    """
    try:
        from sorawm.core import SoraWM
        from sorawm.schemas import CleanerType
    except ImportError:
        print("Error: sorawm package not found.")
        print("Please install it from: https://github.com/linkedlist771/SoraWatermarkCleaner")
        print("\nInstallation instructions:")
        print("1. Clone the repository:")
        print("   git clone https://github.com/linkedlist771/SoraWatermarkCleaner")
        print("2. Install dependencies:")
        print("   cd SoraWatermarkCleaner && uv sync")
        print("3. Activate the environment:")
        print("   source .venv/bin/activate")
        sys.exit(1)
    
    # Validate input path
    input_path = Path(input_video_path).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError(f"Input video file not found: {input_path}")
    
    # Create output path with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"watermark_removed_{timestamp}_{input_path.name}"
    output_path = Path("/Users/joon/Downloads") / output_filename
    
    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Select cleaner type
    if cleaner_type.upper() == "LAMA":
        cleaner = CleanerType.LAMA
        print(f"Using LAMA cleaner (fast, may have slight flicker)")
    elif cleaner_type.upper() == "E2FGVI_HQ":
        cleaner = CleanerType.E2FGVI_HQ
        print(f"Using E2FGVI_HQ cleaner (time-consistent, GPU-accelerated on Apple Silicon)")
    else:
        print(f"Warning: Unknown cleaner type '{cleaner_type}', defaulting to LAMA")
        cleaner = CleanerType.LAMA
    
    print(f"\nInput:  {input_path}")
    print(f"Output: {output_path}")
    print(f"\nProcessing video...")
    
    # Initialize and run watermark remover
    sora_wm = SoraWM(cleaner_type=cleaner)
    
    # Progress callback
    last_progress = [0]
    def progress_callback(progress: int):
        if progress > last_progress[0]:
            print(f"Progress: {progress}%", end="\r", flush=True)
            last_progress[0] = progress
    
    try:
        sora_wm.run(input_path, output_path, progress_callback=progress_callback)
        print(f"\n\n✅ Successfully removed watermark!")
        print(f"📁 Output saved to: {output_path}")
        return output_path
    except Exception as e:
        print(f"\n\n❌ Error during processing: {e}")
        # Clean up partial output file if it exists
        if output_path.exists():
            output_path.unlink()
        raise


def main():
    parser = argparse.ArgumentParser(
        description="Remove watermark from Sora-generated videos",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Remove watermark using LAMA (fast, default)
    python remove_watermark.py "/path/to/video.mp4"
    
    # Remove watermark using E2FGVI_HQ (time-consistent, slower)
    python remove_watermark.py "/path/to/video.mp4" --cleaner-type E2FGVI_HQ

Cleaner Types:
    LAMA        - Fast processing, good quality, may have slight flicker (default)
    E2FGVI_HQ   - Time-consistent, no flicker, GPU-accelerated on Apple Silicon (MPS)
        """
    )
    
    parser.add_argument(
        "input_video",
        type=str,
        help="Path to the input video file"
    )
    
    parser.add_argument(
        "--cleaner-type",
        type=str,
        default="LAMA",
        choices=["LAMA", "E2FGVI_HQ"],
        help="Type of cleaner to use (default: LAMA)"
    )
    
    args = parser.parse_args()
    
    try:
        remove_watermark(args.input_video, args.cleaner_type)
    except KeyboardInterrupt:
        print("\n\n⚠️  Processing interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
