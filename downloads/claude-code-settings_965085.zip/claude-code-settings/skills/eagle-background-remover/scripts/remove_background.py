#!/usr/bin/env python3
"""
Remove image background using Eagle's BiRefNet model.

Usage:
    python3 remove_background.py <image_path>

Output:
    Saves the result to ~/Downloads/<original_filename>_background_removed.png
"""

import sys
import os
import subprocess

# Configuration
EAGLE_PLUGIN_PATH = os.path.expanduser(
    "~/Library/Application Support/Eagle/Plugins/ai-background-remover/modules/background-remover/bin"
)
BINARY_NAME = "BiRefNet-massive-epoch_240"
MODEL_NAME = "BiRefNet-massive-epoch_240.pth"
DOWNLOADS_DIR = os.path.expanduser("~/Downloads")
SUPPORTED_FORMATS = {".png", ".jpg", ".jpeg", ".webp"}
PROCESS_TIMEOUT = 180  # seconds


def remove_background(input_path: str, output_path: str) -> None:
    """Remove background from image using BiRefNet run mode."""
    binary_path = os.path.join(EAGLE_PLUGIN_PATH, BINARY_NAME)
    model_path = os.path.join(EAGLE_PLUGIN_PATH, MODEL_NAME)

    if not os.path.exists(binary_path):
        raise FileNotFoundError(f"BiRefNet binary not found: {binary_path}")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"BiRefNet model not found: {model_path}")

    print("Processing image (model loading + inference)...")

    result = subprocess.run(
        [
            binary_path,
            "run",
            "--input", input_path,
            "--output", output_path,
            "--model-dir", model_path,
        ],
        capture_output=True,
        text=True,
        timeout=PROCESS_TIMEOUT,
    )

    if result.returncode != 0:
        error_msg = result.stderr or result.stdout or "Unknown error"
        raise RuntimeError(f"BiRefNet processing failed: {error_msg}")

    if not os.path.exists(output_path):
        raise RuntimeError("Output file was not created")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 remove_background.py <image_path>")
        sys.exit(1)

    image_path = sys.argv[1]

    # Validate input file
    if not os.path.exists(image_path):
        print(f"Error: File not found: {image_path}")
        sys.exit(1)

    ext = os.path.splitext(image_path)[1].lower()
    if ext not in SUPPORTED_FORMATS:
        print(f"Error: Unsupported format '{ext}'. Supported: {', '.join(SUPPORTED_FORMATS)}")
        sys.exit(1)

    # Prepare output path
    input_filename = os.path.basename(image_path)
    input_name = os.path.splitext(input_filename)[0]
    output_filename = f"{input_name}_배경제거.png"
    output_path = os.path.join(DOWNLOADS_DIR, output_filename)

    try:
        remove_background(image_path, output_path)
        print(f"Background removed successfully!")
        print(f"Output: {output_path}")
    except KeyboardInterrupt:
        print("\nCancelled by user.")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        print(f"Error: Processing timed out after {PROCESS_TIMEOUT} seconds")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
