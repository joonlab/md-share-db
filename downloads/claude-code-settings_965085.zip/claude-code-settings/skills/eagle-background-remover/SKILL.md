---
name: eagle-background-remover
description: Remove image backgrounds using Eagle's BiRefNet model. This skill should be used when the user requests background removal from images (e.g., "remove background from this image", "make this image transparent", "extract subject from photo"). Supports PNG, JPG, JPEG, WEBP formats. Results are saved to ~/Downloads with "_배경제거" suffix.
---

# Eagle Background Remover

## Overview

This skill removes image backgrounds using the BiRefNet (Bilateral Reference Network) model bundled with the Eagle app. BiRefNet excels at precise edge detection, handling complex boundaries like hair and transparent objects.

## Requirements

- Eagle app must be installed with the "AI Background Remover" plugin
- The BiRefNet model files must exist at:
  - Binary: `~/Library/Application Support/Eagle/Plugins/ai-background-remover/modules/background-remover/bin/BiRefNet-massive-epoch_240`
  - Model: `~/Library/Application Support/Eagle/Plugins/ai-background-remover/modules/background-remover/bin/BiRefNet-massive-epoch_240.pth` (~885MB)

## Usage

To remove the background from an image, execute the script:

```bash
python3 ~/.claude/skills/eagle-background-remover/scripts/remove_background.py "<image_path>"
```

## Important Notes

- Uses **direct run mode** (not server mode) for stability
- Model loading takes ~1 second, processing takes ~10 seconds per image
- Output is always PNG format with transparency
- Total processing time: ~10-15 seconds per image

## Workflow

When the user provides an image path and requests background removal:

1. Verify the image file exists and is a supported format (PNG, JPG, JPEG, WEBP)
2. Execute the `remove_background.py` script with the absolute image path
3. Wait for completion (~10-15 seconds)
4. Report the output file location: `~/Downloads/<filename>_배경제거.png`

## Supported Formats

| Input | Output |
|-------|--------|
| PNG, JPG, JPEG, WEBP | PNG (with transparency) |

## Example Triggers

- "Remove background from /path/to/image.jpg"
- "이 이미지 배경 제거해줘: /path/to/photo.png"
- "Make this image transparent"
- "Extract the subject from this picture"

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Processing timeout | Script has 180 second timeout. Large images may take longer. |
| Binary not found | Ensure Eagle app is installed with the "AI Background Remover" plugin |
| Model not found | The model file (.pth) must be downloaded via Eagle's plugin system |
