#!/usr/bin/env python3
"""
PDF to Images Converter

Converts each page of a PDF file to PNG images.

Usage:
    python convert_pdf.py <pdf_path> <output_dir> [--dpi DPI]

Arguments:
    pdf_path    - Path to the PDF file
    output_dir  - Directory to save the images
    --dpi       - Image resolution (default: 200)

Output:
    Creates slide_01.png, slide_02.png, ... in the output directory
    Prints the total number of pages converted
"""

import argparse
import os
import sys

def convert_pdf_to_images(pdf_path: str, output_dir: str, dpi: int = 200) -> int:
    """
    Convert PDF pages to PNG images.
    
    Args:
        pdf_path: Path to the PDF file
        output_dir: Directory to save the images
        dpi: Image resolution (default: 200)
    
    Returns:
        Number of pages converted
    """
    try:
        from pdf2image import convert_from_path
    except ImportError:
        print("Error: pdf2image is not installed. Install it with: pip install pdf2image", file=sys.stderr)
        sys.exit(1)
    
    if not os.path.exists(pdf_path):
        print(f"Error: PDF file not found: {pdf_path}", file=sys.stderr)
        sys.exit(1)
    
    os.makedirs(output_dir, exist_ok=True)
    
    images = convert_from_path(pdf_path, dpi=dpi)
    total_pages = len(images)
    
    for i, image in enumerate(images, 1):
        output_path = os.path.join(output_dir, f"slide_{i:02d}.png")
        image.save(output_path, "PNG")
        print(f"Saved: slide_{i:02d}.png")
    
    print(f"\nTotal pages converted: {total_pages}")
    return total_pages


def main():
    parser = argparse.ArgumentParser(
        description="Convert PDF pages to PNG images"
    )
    parser.add_argument("pdf_path", help="Path to the PDF file")
    parser.add_argument("output_dir", help="Directory to save the images")
    parser.add_argument("--dpi", type=int, default=200, help="Image resolution (default: 200)")
    
    args = parser.parse_args()
    convert_pdf_to_images(args.pdf_path, args.output_dir, args.dpi)


if __name__ == "__main__":
    main()
