---
name: pdf-slide-viewer
description: Convert PDF files into interactive web-based slide viewers. This skill should be used when the user provides a PDF file path and requests to create a website or web viewer for it (e.g., "make this PDF into a website", "create a slide viewer for this PDF", "PDF to web", "view this PDF as slides"). Creates a project folder in /Users/joon/Downloads with assets containing page images and an index.html with full-featured slide navigation, then deploys to GitHub Pages.
---

# PDF Slide Viewer

Convert PDF documents into interactive, responsive web-based slide viewers with thumbnail grid view and fullscreen slideshow mode. Automatically deploys to GitHub Pages.

## When to Use

This skill applies when the user:
- Provides a PDF file path and asks to "make it a website" or "view as slides"
- Requests converting a PDF presentation into a web viewer
- Asks to create an interactive slide viewer from a PDF
- Wants to browse PDF pages in a web browser with navigation

## Workflow

### Step 1: Extract Project Name from PDF

Derive the project folder name from the PDF filename with **strict naming rules**:

**Required Format:**
- **Allowed characters:** lowercase English letters (`a-z`), numbers (`0-9`), and hyphens (`-`) only
- **Maximum length:** 30 characters
- **No consecutive hyphens** (`--`)
- **No leading/trailing hyphens**

**Conversion Process:**
1. Remove the `.pdf` extension
2. Convert to lowercase
3. Replace spaces, underscores, and special characters with hyphens
4. Remove any characters not in `[a-z0-9-]`
5. Collapse consecutive hyphens into single hyphens
6. Trim leading/trailing hyphens
7. **Truncate to 30 characters** (trim at word boundary if possible, otherwise hard cut)

**Examples:**
| Original Filename | Project Folder Name |
|-------------------|---------------------|
| `2025 AI Report_Summary.pdf` | `2025-ai-report-summary` |
| `AI_시대_리더의_일하는_법.pdf` | `ai-leader-work-guide` |
| `Very Long Document Title That Exceeds Limit.pdf` | `very-long-document-title-that` |
| `Report!!!@#$%2024.pdf` | `report2024` |

### Step 2: Create Project Structure

Create the project folder in `/Users/joon/Downloads`:

```
/Users/joon/Downloads/<project-name>/
├── assets/
│   ├── slide_01.png
│   ├── slide_02.png
│   └── ...
└── index.html
```

### Step 3: Convert PDF to Images

Run the conversion script:

```bash
python3 scripts/convert_pdf.py "<pdf_path>" "/Users/joon/Downloads/<project-name>/assets"
```

The script outputs the total number of pages, which is needed for the HTML template.

### Step 4: Generate index.html

> **CRITICAL: 템플릿을 반드시 그대로 사용할 것!**
>
> 템플릿 파일 `assets/index_template.html`을 **있는 그대로** 사용하고, 오직 placeholder만 치환해야 합니다.
> - **절대 코드를 간소화하거나 다시 작성하지 마세요**
> - **절대 "최적화"를 위해 코드를 수정하지 마세요**
> - **템플릿의 모든 기능(iOS 지원, 탭 내비게이션, webkit 호환 등)이 포함되어야 합니다**

**방법 1: sed 명령어 (권장)**
```bash
cat /Users/joon/.claude/skills/pdf-slide-viewer/assets/index_template.html | \
  sed 's/{{TITLE}}/<TITLE>/g' | \
  sed 's/{{HEADER_TITLE}}/<HEADER_TITLE>/g' | \
  sed 's/{{BADGE_TEXT}}/<BADGE_TEXT>/g' | \
  sed 's/{{TOTAL_SLIDES}}/<TOTAL_SLIDES>/g' > /Users/joon/Downloads/<project-name>/index.html
```

**방법 2: Read → Replace → Write**
1. `Read` 도구로 템플릿 파일 읽기
2. 문자열 치환 (placeholder만!)
3. `Write` 도구로 저장

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{TITLE}}` | Browser tab title | `AI Report Slides` |
| `{{HEADER_TITLE}}` | Header display title | `AI Report` |
| `{{BADGE_TEXT}}` | **Current date in Korea timezone (KST), format: `YYYY.MM.DD`** | `2025.12.14` |
| `{{TOTAL_SLIDES}}` | Number of pages (from script output) | `15` |

**Important:** `{{BADGE_TEXT}}` must always be the current date at the time of generation, in Korea Standard Time (KST/UTC+9), formatted as `YYYY.MM.DD`.

### Step 5: Open in Browser

```bash
open /Users/joon/Downloads/<project-name>/index.html
```

### Step 6: Deploy to GitHub Pages

Deploy the newly created slide viewer to the GitHub Pages repository.

#### 6.1 Copy to Repository

```bash
cp -r /Users/joon/Downloads/<project-name> /Users/joon/Downloads/pdf-slide-viewer/
```

#### 6.2 Update slides.json

Read the existing `/Users/joon/Downloads/pdf-slide-viewer/slides.json` and add a new entry:

```json
{
  "id": "<project-name>",
  "title": "<HEADER_TITLE>",
  "date": "<BADGE_TEXT>",
  "thumbnail": "<project-name>/assets/slide_01.png",
  "slides": <TOTAL_SLIDES>
}
```

Write back the updated JSON array to `slides.json`.

#### 6.3 Commit and Push

```bash
cd /Users/joon/Downloads/pdf-slide-viewer && git add . && git commit -m "Add <project-name> slide viewer

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>" && git push
```

### Step 7: Report Completion

After successful deployment, report the following to the user:

```
완료되었습니다!

- 로컬 파일: /Users/joon/Downloads/<project-name>/index.html
- GitHub Pages: https://joonlab.github.io/pdf-slide-viewer/<project-name>/

GitHub Pages 배포는 1-2분 후 반영됩니다. 잠시 후 위 URL에서 확인해주세요.
```

## Features of Generated Viewer

### Desktop Features
- **Thumbnail Grid**: Overview of all slides with hover effects
- **Fullscreen Slideshow**: Click any thumbnail to enter slideshow mode
- **Keyboard Navigation**: Arrow keys to navigate, ESC to exit, F for fullscreen
- **Presentation Mode**: Press F or click FAB button for distraction-free viewing (slide + progress bar only)
- **Progress Indicator**: Visual progress bar and slide counter
- **Mini Thumbnails**: Quick navigation strip at the bottom
- **Dark Theme**: Easy on the eyes, professional appearance

### Mobile Features
- **Touch Navigation**: Swipe left/right to navigate slides
- **Tap Navigation**: Tap left half for previous, right half for next slide
- **Fullscreen FAB Button**: Large floating button for easy access to presentation mode
- **Landscape Mode**: Auto-rotates to landscape on Android when entering presentation mode
- **iOS Support**: Shows orientation hint and enters presentation mode (iOS doesn't support fullscreen API)
- **Responsive Design**: Optimized layout for mobile screens

### Presentation Mode
When entering presentation mode (via F key, FAB button, or fullscreen button in slideshow):
- All UI elements hidden except slide and minimal progress bar
- Slide fills the screen for maximum visibility
- On Android: Automatically locks to landscape orientation
- On iOS: Shows "rotate device" hint, then enters presentation mode with exit button

## GitHub Pages Repository

- **Repository**: https://github.com/joonlab/pdf-slide-viewer
- **GitHub Pages URL**: https://joonlab.github.io/pdf-slide-viewer/
- **Main Page**: Neobrutalism-styled card grid listing all slides

## Dependencies

- Python 3 with `pdf2image` library
- poppler (for PDF rendering): `brew install poppler`
- Git and GitHub CLI (`gh`)
