#!/bin/bash
# Git Worktree Helper for Claude Code Parallel Development
# Usage: source this file or add functions to your shell config

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Create a new worktree with a new branch
# Usage: worktree-new <branch-name> [folder-name]
worktree-new() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: Branch name required${NC}"
        echo "Usage: worktree-new <branch-name> [folder-name]"
        return 1
    fi

    local branch=$1
    local name=${2:-$(basename "$branch")}
    local base="../worktrees"

    # Check if we're in a git repo
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        echo -e "${RED}Error: Not in a git repository${NC}"
        return 1
    fi

    mkdir -p "$base"

    if git worktree add -b "$branch" "$base/$name" 2>/dev/null; then
        echo -e "${GREEN}Created worktree:${NC} $base/$name"
        echo -e "${BLUE}Branch:${NC} $branch"
        echo ""
        echo -e "${YELLOW}To start Claude Code:${NC}"
        echo "  cd $base/$name && claude"
    else
        echo -e "${RED}Failed to create worktree${NC}"
        echo "The branch might already exist. Try:"
        echo "  git worktree add $base/$name $branch"
        return 1
    fi
}

# Create multiple worktrees at once
# Usage: worktree-batch <branch1> <branch2> ...
worktree-batch() {
    if [ $# -eq 0 ]; then
        echo -e "${RED}Error: At least one branch name required${NC}"
        echo "Usage: worktree-batch <branch1> <branch2> ..."
        return 1
    fi

    local base="../worktrees"
    mkdir -p "$base"

    echo -e "${BLUE}Creating worktrees...${NC}"
    echo ""

    for branch in "$@"; do
        local name=$(basename "$branch")
        if git worktree add -b "$branch" "$base/$name" 2>/dev/null; then
            echo -e "${GREEN}[OK]${NC} $base/$name ($branch)"
        else
            echo -e "${RED}[FAIL]${NC} $branch - might already exist"
        fi
    done

    echo ""
    echo -e "${YELLOW}Claude Code commands:${NC}"
    for branch in "$@"; do
        local name=$(basename "$branch")
        echo "  cd $base/$name && claude"
    done
}

# List all worktrees with Claude Code hints
# Usage: worktree-ls
worktree-ls() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        echo -e "${RED}Error: Not in a git repository${NC}"
        return 1
    fi

    echo -e "${BLUE}=== Worktrees ===${NC}"
    git worktree list
    echo ""
    echo -e "${YELLOW}=== Claude Code Commands ===${NC}"
    git worktree list --porcelain | grep "^worktree" | cut -d' ' -f2 | while read path; do
        echo "cd $path && claude"
    done
}

# Remove a specific worktree
# Usage: worktree-rm <path-or-name>
worktree-rm() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: Worktree path required${NC}"
        echo "Usage: worktree-rm <path-or-name>"
        return 1
    fi

    local target=$1

    # If just a name, prepend ../worktrees/
    if [[ "$target" != /* && "$target" != ../* ]]; then
        target="../worktrees/$target"
    fi

    if git worktree remove "$target" 2>/dev/null; then
        echo -e "${GREEN}Removed:${NC} $target"
    elif git worktree remove --force "$target" 2>/dev/null; then
        echo -e "${YELLOW}Force removed:${NC} $target"
    else
        echo -e "${RED}Failed to remove:${NC} $target"
        return 1
    fi
}

# Clean up all worktrees except main
# Usage: worktree-clean [--force]
worktree-clean() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        echo -e "${RED}Error: Not in a git repository${NC}"
        return 1
    fi

    local force=$1
    local main_path=$(git rev-parse --show-toplevel)

    echo -e "${BLUE}Cleaning worktrees...${NC}"
    echo -e "${YELLOW}Main project:${NC} $main_path (will be kept)"
    echo ""

    git worktree list --porcelain | grep "^worktree" | cut -d' ' -f2 | while read path; do
        if [ "$path" != "$main_path" ]; then
            if [ "$force" = "--force" ]; then
                git worktree remove --force "$path" 2>/dev/null
                echo -e "${GREEN}Removed:${NC} $path"
            else
                if git worktree remove "$path" 2>/dev/null; then
                    echo -e "${GREEN}Removed:${NC} $path"
                else
                    echo -e "${YELLOW}Skipped (has changes):${NC} $path"
                    echo "  Use: worktree-clean --force"
                fi
            fi
        fi
    done

    git worktree prune
    echo ""
    echo -e "${GREEN}Done!${NC}"
}

# Show status of all worktrees
# Usage: worktree-status
worktree-status() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        echo -e "${RED}Error: Not in a git repository${NC}"
        return 1
    fi

    echo -e "${BLUE}=== Worktree Status ===${NC}"
    echo ""

    git worktree list --porcelain | grep "^worktree" | cut -d' ' -f2 | while read path; do
        local branch=$(cd "$path" && git branch --show-current 2>/dev/null)
        local changes=$(cd "$path" && git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
        local ahead=$(cd "$path" && git rev-list --count @{u}..HEAD 2>/dev/null || echo "?")

        echo -e "${GREEN}$path${NC}"
        echo "  Branch: $branch"
        echo "  Changes: $changes files"
        echo "  Ahead: $ahead commits"
        echo ""
    done
}

# Help
worktree-help() {
    echo -e "${BLUE}Git Worktree Helper Commands${NC}"
    echo ""
    echo "  worktree-new <branch> [name]  Create new worktree with new branch"
    echo "  worktree-batch <b1> <b2>...   Create multiple worktrees"
    echo "  worktree-ls                   List worktrees with Claude hints"
    echo "  worktree-rm <path>            Remove a worktree"
    echo "  worktree-clean [--force]      Clean up all worktrees"
    echo "  worktree-status               Show status of all worktrees"
    echo "  worktree-help                 Show this help"
    echo ""
    echo -e "${YELLOW}Examples:${NC}"
    echo "  worktree-new feature/auth"
    echo "  worktree-batch feature/frontend feature/backend feature/api"
    echo "  worktree-rm auth"
    echo "  worktree-clean --force"
}

# Show help on source
echo -e "${GREEN}Git Worktree Helper loaded!${NC}"
echo "Run 'worktree-help' for available commands."
