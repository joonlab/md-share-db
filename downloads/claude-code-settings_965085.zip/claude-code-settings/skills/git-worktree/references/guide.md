# Git Worktree + Claude Code 병렬 개발 완벽 가이드

> **TL;DR**: Git worktree로 여러 브랜치를 동시에 체크아웃하고, 각각에서 Claude Code를 실행하면 개발 속도가 4-5배 향상됩니다.

---

## 목차

1. [개념 이해](#1-개념-이해)
2. [기본 사용법](#2-기본-사용법)
3. [Claude Code와 조합하기](#3-claude-code와-조합하기)
4. [실전 시나리오](#4-실전-시나리오)
5. [고급 패턴](#5-고급-패턴)
6. [문제 해결](#6-문제-해결)
7. [모범 사례](#7-모범-사례)

---

## 1. 개념 이해

### Git Worktree란?

Git의 기본 기능으로, **하나의 저장소에서 여러 브랜치를 동시에 다른 디렉토리에서 작업**할 수 있게 해주는 도구입니다.

#### 기존 방식 vs Worktree 방식

```
기존 방식 (순차적)
─────────────────────────────────────────────────────────────────→ 시간
│ main 작업 │→ stash →│ feature 작업 │→ stash →│ main 작업 │
            컨텍스트 손실    컨텍스트 손실

Worktree 방식 (병렬)
─────────────────────────────────────────────────────────────────→ 시간
│ 폴더A: main 작업 계속...                                        │
│ 폴더B: feature 작업 계속...                                     │
│ 폴더C: bugfix 작업 계속...                                      │
```

#### 핵심 특징

| 특징 | 설명 |
|------|------|
| **디스크 절약** | 전체 clone이 아닌 working files만 추가 (약 1/10 용량) |
| **Git 히스토리 공유** | 모든 worktree가 동일한 `.git` 데이터 참조 |
| **완전한 독립성** | 각 worktree는 독립적인 작업 디렉토리 |
| **즉시 전환** | 브랜치 전환 없이 폴더 이동만으로 다른 브랜치 작업 |

### 왜 Claude Code와 조합이 강력한가?

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   터미널 1      │     │   터미널 2      │     │   터미널 3      │
│                 │     │                 │     │                 │
│  메인 프로젝트  │     │  worktree/auth  │     │  worktree/api   │
│  (main 브랜치)  │     │  (feature/auth) │     │  (feature/api)  │
│                 │     │                 │     │                 │
│  Claude Code 1  │     │  Claude Code 2  │     │  Claude Code 3  │
│  "UI 개선해줘"  │     │  "인증 구현해줘"│     │  "API 만들어줘" │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        └───────────────────────┼───────────────────────┘
                                │
                         ┌──────▼──────┐
                         │   .git/     │
                         │  (공유됨)   │
                         └─────────────┘
```

**장점**:
- 각 Claude 세션이 독립적인 컨텍스트 유지
- 한 세션의 변경이 다른 세션에 영향 없음
- 동시에 여러 기능 개발 가능
- 실제 사례에서 개발 속도 **4-5배 향상** (incident.io)

---

## 2. 기본 사용법

### Worktree 생성

```bash
# 새 브랜치와 함께 생성 (가장 많이 사용)
git worktree add -b feature/new-feature ../worktree-feature

# 기존 브랜치로 생성
git worktree add ../worktree-feature feature/existing-branch

# 원격 브랜치 기반으로 생성
git worktree add -b feature/local ../worktree-feature origin/main
```

### Worktree 관리

```bash
# 목록 확인
git worktree list
# 출력 예시:
# /home/user/my-project         abc1234 [main]
# /home/user/worktree-feature   def5678 [feature/new-feature]

# 삭제 (작업 디렉토리도 함께 삭제)
git worktree remove ../worktree-feature

# 강제 삭제 (수정사항이 있어도 삭제)
git worktree remove --force ../worktree-feature

# 무효한 worktree 정리
git worktree prune
```

### 명령어 빠른 참조

| 작업 | 명령어 |
|------|--------|
| 새 브랜치로 생성 | `git worktree add -b <브랜치> <경로>` |
| 기존 브랜치로 생성 | `git worktree add <경로> <브랜치>` |
| 목록 확인 | `git worktree list` |
| 삭제 | `git worktree remove <경로>` |
| 강제 삭제 | `git worktree remove --force <경로>` |
| 정리 | `git worktree prune` |
| 잠금 (실수 방지) | `git worktree lock <경로>` |
| 잠금 해제 | `git worktree unlock <경로>` |

---

## 3. Claude Code와 조합하기

### 권장 디렉토리 구조

```
my-project/               ← 메인 프로젝트 (main 브랜치)
├── .git/                 ← Git 데이터 (모든 worktree가 공유)
├── src/
├── package.json
└── ...

worktrees/                ← worktree 모음 폴더 (메인과 같은 레벨)
├── feature-auth/         ← feature/auth 브랜치
├── feature-api/          ← feature/api 브랜치
├── feature-ui/           ← feature/ui 브랜치
└── hotfix-urgent/        ← hotfix/urgent 브랜치
```

### 병렬 개발 환경 구성

```bash
# 1. 메인 프로젝트에서 시작
cd ~/my-project

# 2. worktrees 폴더 생성
WORKTREE_BASE="../worktrees"
mkdir -p "$WORKTREE_BASE"

# 3. 필요한 worktree들 생성
git worktree add -b feature/auth "$WORKTREE_BASE/auth"
git worktree add -b feature/api "$WORKTREE_BASE/api"
git worktree add -b feature/ui "$WORKTREE_BASE/ui"

# 4. 확인
git worktree list
```

### Claude Code 실행

각 터미널에서:

```bash
# 터미널 1: 메인 프로젝트
cd ~/my-project
claude
# → "메인 페이지 레이아웃 개선해줘"

# 터미널 2: 인증 기능
cd ~/worktrees/auth
claude
# → "JWT 기반 인증 시스템 구현해줘"

# 터미널 3: API 개발
cd ~/worktrees/api
claude
# → "사용자 CRUD API 만들어줘"

# 터미널 4: UI 컴포넌트
cd ~/worktrees/ui
claude
# → "재사용 가능한 버튼 컴포넌트 만들어줘"
```

### AGENTS.md 활용 (선택)

프로젝트 루트에 `AGENTS.md`로 전체 스펙을 정의하면 각 Claude 세션이 일관된 방향으로 작업합니다:

```markdown
# AGENTS.md

## 공통 규약
- API 응답 형식: { success: boolean, data?: any, error?: string }
- 인증: Bearer Token (JWT)
- Base URL: /api/v1

## Data Models
- User: { id, email, name, role, createdAt }
- Post: { id, title, content, authorId, createdAt }

## Frontend Requirements
- React 18 + TypeScript
- Tailwind CSS
- 반응형 디자인

## Backend Requirements
- Node.js + Express
- PostgreSQL + Prisma
- JWT 인증
```

---

## 4. 실전 시나리오

### 시나리오 1: 모노레포 프론트/백엔드 동시 개발

```bash
# 상황: 새 기능의 프론트엔드와 백엔드를 동시에 개발

# 1. Worktree 생성
git worktree add -b feature/user-profile-frontend ../worktrees/frontend
git worktree add -b feature/user-profile-backend ../worktrees/backend

# 2. 각각에서 Claude Code 실행
# 터미널 1
cd ../worktrees/frontend && claude
# → "사용자 프로필 페이지 만들어줘. API는 /api/v1/users/:id 사용"

# 터미널 2
cd ../worktrees/backend && claude
# → "사용자 프로필 API 만들어줘. GET /api/v1/users/:id"

# 3. 작업 완료 후 병합
cd ~/my-project
git merge feature/user-profile-backend
git merge feature/user-profile-frontend
```

### 시나리오 2: 긴급 버그픽스 + 기능 개발 병행

```bash
# 상황: 기능 개발 중 긴급 버그 발견

# 현재: feature 브랜치에서 작업 중
# 긴급: main에서 버그 발견됨

# 1. 버그픽스용 worktree 생성 (기존 작업 중단 없이)
git worktree add -b hotfix/critical-bug ../worktrees/hotfix main

# 2. 버그픽스 작업 (별도 터미널)
cd ../worktrees/hotfix && claude
# → "로그인 시 발생하는 null pointer 오류 수정해줘"

# 3. 버그픽스 완료 후 즉시 배포
git checkout main
git merge hotfix/critical-bug
git push origin main

# 4. worktree 정리
git worktree remove ../worktrees/hotfix
git branch -d hotfix/critical-bug

# 기존 feature 작업은 계속 진행 중!
```

### 시나리오 3: PR 코드 리뷰 + 수정

```bash
# 상황: 팀원의 PR을 로컬에서 리뷰하고 직접 수정

# 1. PR 브랜치를 worktree로 체크아웃
git fetch origin pull/123/head:pr-123
git worktree add ../worktrees/pr-review pr-123

# 2. 리뷰 및 수정
cd ../worktrees/pr-review && claude
# → "이 PR 코드 리뷰해줘. 개선점 있으면 직접 수정해줘"

# 3. 수정사항 push
git push origin pr-123

# 4. 정리
git worktree remove ../worktrees/pr-review
```

### 시나리오 4: 대규모 리팩토링 (단계별)

```bash
# 상황: 레거시 코드를 3단계로 리팩토링

# 1. 각 단계별 worktree 생성
git worktree add -b refactor/phase1-utils ../worktrees/phase1
git worktree add -b refactor/phase2-services ../worktrees/phase2
git worktree add -b refactor/phase3-controllers ../worktrees/phase3

# 2. 단계별 병렬 작업
# Phase 1: 유틸리티 함수 정리
cd ../worktrees/phase1 && claude
# → "utils 폴더의 중복 함수들 통합해줘"

# Phase 2: 서비스 레이어 개선
cd ../worktrees/phase2 && claude
# → "서비스 레이어에 의존성 주입 패턴 적용해줘"

# Phase 3: 컨트롤러 정리
cd ../worktrees/phase3 && claude
# → "컨트롤러에서 비즈니스 로직을 서비스로 분리해줘"

# 3. 순차적 병합 (의존성 순서대로)
git merge refactor/phase1-utils
git merge refactor/phase2-services
git merge refactor/phase3-controllers
```

---

## 5. 고급 패턴

### Sub Agent vs Worktree 비교

| 구분 | Claude Sub Agent | Git Worktree |
|------|------------------|--------------|
| 작업 디렉토리 | 같은 디렉토리 | 물리적으로 분리 |
| 브랜치 | 같은 브랜치 | 각각 다른 브랜치 |
| 독립성 | 메인 agent가 조율 | 완전히 독립적 |
| 적합 상황 | 파일 간 의존성 있을 때 | 모듈 간 독립성 높을 때 |
| 비용 | 하나의 세션 | 세션 수만큼 토큰 사용 |

**Sub Agent 사용**:
```
"프론트엔드와 백엔드 코드를 sub agent를 만들어서 병렬로 작성해줘"
```

**Worktree 사용**: 물리적으로 분리된 환경에서 완전 독립적인 작업

### 자동화 스크립트

`~/.bashrc` 또는 `~/.zshrc`에 추가:

```bash
# worktree 빠른 생성
worktree-new() {
    local branch=$1
    local name=${2:-$branch}
    local base="../worktrees"
    mkdir -p "$base"
    git worktree add -b "$branch" "$base/$name"
    echo "Created: $base/$name ($branch)"
    echo "Run: cd $base/$name && claude"
}

# worktree 목록 + Claude 실행 힌트
worktree-ls() {
    echo "=== Worktrees ==="
    git worktree list
    echo ""
    echo "=== Claude 실행 ==="
    git worktree list --porcelain | grep "^worktree" | cut -d' ' -f2 | while read path; do
        echo "cd $path && claude"
    done
}

# 모든 worktree 정리
worktree-clean() {
    git worktree list --porcelain | grep "^worktree" | cut -d' ' -f2 | while read path; do
        if [ "$path" != "$(git rev-parse --show-toplevel)" ]; then
            echo "Removing: $path"
            git worktree remove "$path" 2>/dev/null || git worktree remove --force "$path"
        fi
    done
    git worktree prune
    echo "Done!"
}
```

사용:
```bash
worktree-new feature/auth auth-work
worktree-ls
worktree-clean
```

---

## 6. 문제 해결

### 오류: 이미 체크아웃된 브랜치

```
fatal: 'feature/auth' is already checked out at '/path/to/worktree'
```

**해결**: 같은 브랜치는 동시에 하나의 worktree에서만 체크아웃 가능

```bash
# 방법 1: 다른 브랜치명 사용
git worktree add -b feature/auth-v2 ../worktree-auth-v2

# 방법 2: 기존 worktree 삭제 후 재생성
git worktree remove ../existing-worktree
git worktree add -b feature/auth ../new-worktree
```

### 오류: 경로가 이미 존재함

```
fatal: '/path/to/worktree' already exists
```

**해결**:
```bash
# 해당 폴더 삭제 후 재시도
rm -rf ../worktree-feature
git worktree add -b feature ../worktree-feature
```

### 오류: worktree 삭제 실패

```
fatal: cannot remove a dirty working tree
```

**해결**:
```bash
# 강제 삭제
git worktree remove --force ../worktree-feature

# 또는 변경사항 커밋 후 삭제
cd ../worktree-feature
git add . && git commit -m "WIP"
cd -
git worktree remove ../worktree-feature
```

### Claude Code 세션 충돌

각 worktree의 Claude Code 세션은 독립적이지만, 같은 파일을 수정하면 merge 시 충돌 발생

**예방**:
- 각 세션이 다른 파일/모듈을 담당하도록 분배
- AGENTS.md에 작업 범위 명시
- 공통 파일(config 등)은 한 세션에서만 수정

---

## 7. 모범 사례

### Do's (권장)

1. **명확한 작업 분리**: 각 worktree가 독립적인 기능/모듈 담당
2. **일관된 네이밍**: `feature/기능명`, `hotfix/버그명` 형식 유지
3. **정기적인 정리**: 완료된 worktree는 즉시 삭제
4. **AGENTS.md 활용**: 전체 스펙을 정의하여 일관성 유지
5. **작은 단위로 커밋**: 각 worktree에서 자주 커밋

### Don'ts (주의)

1. **같은 파일 동시 수정**: merge 충돌 발생
2. **너무 많은 worktree**: 3-5개가 적정 (관리 복잡성)
3. **장기간 방치**: 오래된 worktree는 main과 괴리 발생
4. **메인 프로젝트 직접 수정**: worktree에서 작업 후 병합 권장

### 체크리스트

```markdown
## Worktree 작업 전
- [ ] 메인 브랜치(main/master) 최신화
- [ ] 작업 범위 및 브랜치명 결정
- [ ] AGENTS.md 준비 (선택)

## Worktree 작업 중
- [ ] 각 세션에서 담당 영역만 수정
- [ ] 자주 커밋
- [ ] 필요시 rebase로 최신화

## Worktree 작업 후
- [ ] 모든 테스트 통과 확인
- [ ] 순서대로 병합 (의존성 고려)
- [ ] worktree 삭제
- [ ] 브랜치 정리
```

---

## 참고 자료

- [Git 공식 문서 - git-worktree](https://git-scm.com/docs/git-worktree)
- [Shane Park - Git Worktree를 활용한 Claude Code 병렬 실행](https://shanepark.tistory.com/554)
- [Medium - Mastering Git Worktrees with Claude Code](https://medium.com/@dtunai/mastering-git-worktrees-with-claude-code-for-parallel-development-workflow-41dc91e645fe)
- [NX Blog - How Git Worktrees Changed My AI Agent Workflow](https://nx.dev/blog/git-worktrees-ai-agents)

---

*이 가이드는 Claude Code에서 `/git-worktree` skill의 일부로 제공됩니다.*
