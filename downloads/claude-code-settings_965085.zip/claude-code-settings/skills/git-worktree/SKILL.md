---
name: git-worktree
description: |
  Git worktree를 활용한 Claude Code 병렬 개발 환경 구성 및 관리.
  이 skill은 사용자가 (1) 여러 Claude Code 세션을 병렬로 실행하고 싶을 때,
  (2) git worktree 생성/관리를 요청할 때, (3) 브랜치별 독립 작업 환경이 필요할 때,
  (4) 모노레포에서 프론트/백엔드를 동시 개발할 때 사용됩니다.
  트리거 키워드: "worktree", "병렬 개발", "동시 작업", "브랜치 분리", "parallel claude"
---

# Git Worktree + Claude Code 병렬 개발

Git worktree를 활용하여 여러 Claude Code 세션을 **동시에** 실행하는 병렬 개발 환경을 구성한다.

## 핵심 개념

```
메인 프로젝트/          ← main 브랜치 (Claude 세션 1)
├── .git/              ← 공유되는 Git 데이터

../worktrees/          ← worktree 모음 폴더
├── feature-auth/      ← feature/auth 브랜치 (Claude 세션 2)
├── feature-api/       ← feature/api 브랜치 (Claude 세션 3)
└── hotfix-urgent/     ← hotfix/urgent 브랜치 (Claude 세션 4)
```

**장점**: 컨텍스트 격리, 디스크 절약, 개발 속도 4-5배 향상

## 워크플로우

### 1. Worktree 생성

사용자가 병렬 작업 환경을 요청하면:

```bash
# 현재 디렉토리 확인
pwd && git status

# worktrees 폴더 생성 (메인 프로젝트와 같은 레벨)
WORKTREE_BASE="$(dirname "$(pwd)")/worktrees"
mkdir -p "$WORKTREE_BASE"

# 새 브랜치와 함께 worktree 생성
git worktree add -b <브랜치명> "$WORKTREE_BASE/<폴더명>"

# 예시: feature/auth 브랜치로 auth-work worktree 생성
git worktree add -b feature/auth "$WORKTREE_BASE/auth-work"
```

### 2. 여러 Worktree 한번에 생성

병렬 개발 환경 전체 구성 시:

```bash
WORKTREE_BASE="$(dirname "$(pwd)")/worktrees"
mkdir -p "$WORKTREE_BASE"

# 프론트엔드/백엔드 분리 개발
git worktree add -b feature/frontend "$WORKTREE_BASE/frontend"
git worktree add -b feature/backend "$WORKTREE_BASE/backend"

# 또는 기능별 분리
git worktree add -b feature/auth "$WORKTREE_BASE/auth"
git worktree add -b feature/dashboard "$WORKTREE_BASE/dashboard"
git worktree add -b feature/api "$WORKTREE_BASE/api"
```

### 3. Worktree 목록 확인

```bash
git worktree list
```

### 4. Claude Code 병렬 실행 안내

worktree 생성 후 사용자에게 안내:

```
## 병렬 실행 방법

각 터미널에서 Claude Code를 실행하세요:

터미널 1 (메인):
  cd <메인프로젝트경로>
  claude

터미널 2:
  cd <worktree경로1>
  claude

터미널 3:
  cd <worktree경로2>
  claude

각 세션에서 독립적으로 작업하면 됩니다!
```

### 5. 작업 완료 후 병합

```bash
# 메인 프로젝트로 이동
cd <메인프로젝트경로>

# 각 브랜치 병합
git merge feature/frontend
git merge feature/backend

# worktree 정리
git worktree remove "$WORKTREE_BASE/frontend"
git worktree remove "$WORKTREE_BASE/backend"

# 브랜치 정리 (선택)
git branch -d feature/frontend
git branch -d feature/backend
```

### 6. Worktree 삭제

```bash
# 단일 삭제
git worktree remove <경로>

# 전체 정리
git worktree prune
```

## 빠른 명령어 참조

| 작업 | 명령어 |
|------|--------|
| 새 브랜치로 생성 | `git worktree add -b <브랜치> <경로>` |
| 기존 브랜치로 생성 | `git worktree add <경로> <브랜치>` |
| 목록 확인 | `git worktree list` |
| 삭제 | `git worktree remove <경로>` |
| 정리 | `git worktree prune` |

## 주의사항

1. **같은 브랜치 중복 체크아웃 불가**: 이미 체크아웃된 브랜치는 다른 worktree에서 사용 불가
2. **파일 충돌 방지**: 각 세션이 다른 파일을 수정하도록 작업 범위 명확히 구분
3. **토큰 사용량**: 동시 실행 세션 수에 비례하여 증가

## 상세 가이드

완벽한 가이드와 실전 예제는 `references/guide.md` 참조.
