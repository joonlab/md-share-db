---
name: gemini-with-claudecode
description: Call Google Gemini CLI from within Claude Code to leverage Gemini models for cross-checking, web search integration, or alternative perspectives. This skill should be used when the user requests to use Gemini or Google AI from within Claude Code, or when cross-validation with another AI is needed. Triggers include "Gemini한테 물어봐", "Google AI로 확인해봐", "Gemini로 검색해봐", or similar requests involving Google's Gemini models.
---

# Gemini with Claude Code

## ⚠️ 필수 실행 순서 (반드시 따를 것)

Gemini 실행 시 **3단계 모두 완료해야 함**. 하나라도 빠뜨리면 안 됨!

| 순서 | 명령어 | 목적 |
|:---:|--------|------|
| **1** | `gemini -p "질문"` | 질문 실행 |
| **2** | `gemini --list-sessions` | 세션 번호 확인 |
| **3** | 사용자에게 resume 명령어 안내 | 터미널에서 이어가기 |

### 최종 응답 템플릿 (복사해서 사용)

```
**Gemini 응답:**
[응답 내용]

**세션 번호:** N

**터미널에서 이 대화를 이어가려면:**
cd /Users/joon && gemini -r N
```

---

## 실행 예시

사용자: "Gemini한테 Python 설명해달라고 해"

```bash
# Step 1: 질문 실행
gemini -p "Python에 대해 설명해줘"

# Step 2: 세션 번호 확인 (반드시!)
gemini --list-sessions
# → 9. Python에 대해... (Just now) [abc123...]
```

```
# Step 3: 사용자에게 안내 (반드시!)
**Gemini 응답:**
Python은 ...

**세션 번호:** 9

**터미널에서 이 대화를 이어가려면:**
cd /Users/joon && gemini -r 9
```

---

## Claude Code 내에서 이전 세션 이어가기

```bash
gemini -r <번호> -p "후속 질문"
gemini -r latest -p "후속 질문"  # 가장 최근 세션
```

---

## 기타 명령어

| 용도 | 명령어 |
|------|--------|
| 세션 삭제 | `gemini --delete-session <번호>` |
| 웹 검색 질문 | `gemini -p "2025년 최신 트렌드"` |

## 참고

- 세션은 프로젝트(작업 디렉토리) 기준으로 저장됨
- 터미널에서 같은 세션 접근하려면 같은 디렉토리에서 실행해야 함
- 세션 파일 위치: `~/.gemini/tmp/<project-hash>/chats/`
