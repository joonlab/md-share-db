---
name: pdf-resizer
description: Intelligently resize and optimize scanned PDF documents to specific dimensions while preserving content quality. This skill should be used when processing scanned PDFs (textbooks, worksheets, exam papers) that need standardized sizing with automatic content detection, margin optimization, and file compression. Supports both single-file and batch processing workflows.
---

# PDF Resizer

## Overview

This skill provides intelligent PDF resizing capabilities using advanced content detection algorithms. It automatically crops scanned PDFs to remove borders and noise, resizes content to target dimensions while maintaining aspect ratio, applies natural margins for readability, and compresses output files for optimal file size.

The skill uses a Dual-Masking Strategy that separately detects text and horizontal lines to ensure no content is lost during the cropping process, making it particularly effective for educational materials like exam papers and worksheets.

## When to Use This Skill

Use this skill when:
- Resizing scanned PDF documents (exams, worksheets, textbooks) to standardized dimensions
- Processing multiple PDF files with consistent sizing requirements
- Optimizing PDF file sizes while maintaining visual quality
- Debugging content detection issues with visualization tools
- Converting irregularly-sized scans to uniform page sizes

Common user requests include:
- "Resize this PDF to [dimensions]"
- "Process all PDFs in this folder with the same settings"
- "Show me what content areas are being detected"
- "Optimize these exam papers for distribution"

## Quick Start

### Default Configuration

The skill operates with these default settings:
- **Target size**: 773.76 x 1119.6 points (standard exam paper size)
- **DPI**: 300 (high quality for text/formulas)
- **Natural margin**: 5% of canvas size (automatic scaling)
- **Compression**: Ghostscript /ebook preset (~70% size reduction)

These settings can be modified in the script configuration section.

### Basic Workflow

For single PDF:
1. Run `resize_pdf.py` on the input PDF
2. Optionally compress with Ghostscript or use the built-in compression

For batch processing:
1. Configure input/output directories in `batch_process.py`
2. Run batch processing script
3. Monitor progress as files are processed sequentially

## Single File Processing

### Standard Resize

To resize a single PDF file:

```bash
python3 scripts/resize_pdf.py <input.pdf>
```

This creates an output file named `<input>_final_HHMMSS.pdf` with:
- Content automatically detected and cropped
- Natural margins (5% of canvas size) applied
- High-quality resampling at 300 DPI

### Debug Mode

To visualize detected content areas:

```bash
python3 scripts/resize_pdf.py <input.pdf> --debug
```

Debug mode generates visualization images in `debug_output/` showing:
- Text mask (area-based filtering)
- Line mask (horizontal line detection)
- Combined mask (final content detection)
- Bounding box placement

### Configuration Options

Modify these variables in `resize_pdf.py` to adjust behavior:

```python
TARGET_WIDTH_PT = 773.76          # Target PDF width (points)
TARGET_HEIGHT_PT = 1119.6         # Target PDF height (points)
DPI = 300                         # Processing resolution
NATURAL_MARGIN_PERCENT = 0.05     # Margin as % of canvas (5%)
MIN_COMPONENT_AREA = 50           # Text mask threshold (pixels²)
HORIZONTAL_LINE_KERNEL_WIDTH = 50 # Line detection sensitivity
BBOX_PADDING = 15                 # Content padding (pixels)
```

## Batch Processing

### Setup Batch Job

To process multiple PDFs:

1. Edit `batch_process.py` to configure paths:

```python
INPUT_DIR = "/path/to/input/pdfs"
OUTPUT_DIR = "/path/to/output"
```

2. Run the batch processor:

```bash
python3 scripts/batch_process.py
```

The script will:
- Process each PDF sequentially
- Apply resize and compression automatically
- Save final files as `<name>_final.pdf`
- Display progress with file counts and sizes

### Monitoring Progress

Create a simple monitoring script to track batch processing:

```python
import os
import time

OUTPUT_DIR = "/path/to/output"
TOTAL_FILES = 34  # Adjust to expected count

while True:
    count = len([f for f in os.listdir(OUTPUT_DIR) if f.endswith('.pdf')])
    print(f"Progress: {count}/{TOTAL_FILES} files")
    if count >= TOTAL_FILES:
        break
    time.sleep(15)
```

## Content Detection Algorithm

### Dual-Masking Strategy

The skill uses a sophisticated two-phase content detection approach:

**Phase 1: Text Mask**
- Apply Otsu thresholding to convert to binary
- Remove noise with morphological opening
- Analyze connected components
- Filter out components smaller than `MIN_COMPONENT_AREA` (default: 50px²)
- Preserve all significant text and formulas

**Phase 2: Line Mask**
- Use horizontal kernel (50x1 pixels)
- Apply morphological opening to detect long horizontal lines
- Preserve table borders and header lines that might be removed by text mask

**Phase 3: Combination**
- Combine both masks with bitwise OR
- Calculate bounding box from combined mask
- Apply padding for safety margin
- Result: Perfect detection of both text and structural elements

This approach solves the common problem where traditional cropping algorithms either lose thin lines or include too much noise.

### Edge Cases

The algorithm handles:
- **Scan artifacts**: 2% edge masking removes border shadows
- **Small noise**: Area-based filtering removes isolated dots
- **Thin lines**: Line mask specifically preserves header/footer lines
- **Empty pages**: Falls back to full image if no content detected

## Compression

### Automatic Compression

The batch processor automatically compresses PDFs using Ghostscript:

```bash
gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 \
   -dPDFSETTINGS=/ebook -dNOPAUSE -dQUIET -dBATCH \
   -sOutputFile=output.pdf input.pdf
```

Expected results:
- **Size reduction**: ~70% (13 MB → 3.8 MB typical)
- **Quality**: Maintains readability for text and formulas
- **Setting**: `/ebook` preset optimized for on-screen viewing

### Manual Compression

To compress an existing PDF:

```bash
python3 scripts/compress_pdf.py <input.pdf>
```

Adjust quality settings in the script:

```python
DPI = 300           # Resolution (higher = better quality)
JPEG_QUALITY = 92   # JPEG quality (85-95 recommended)
OPTIMIZE = True     # PIL optimization
```

## Visualization and Debugging

### Content Box Visualization

To debug content detection issues:

```bash
python3 scripts/visualize_content_boxes.py <input.pdf>
```

This creates a PDF with:
- Red bounding boxes around detected content
- Coordinate and size information overlaid
- Page numbers for multi-page documents

Use this when:
- Content is being cropped incorrectly
- Too much whitespace is included
- Margins appear uneven
- Debugging algorithm parameters

### Adjusting Detection Parameters

If content detection is not optimal:

1. Run visualization to identify the issue
2. Adjust relevant parameters in `resize_pdf.py`:
   - Increase `MIN_COMPONENT_AREA` if too much noise
   - Decrease `MIN_COMPONENT_AREA` if missing small text
   - Adjust `HORIZONTAL_LINE_KERNEL_WIDTH` for line detection
   - Modify `BBOX_PADDING` for tighter/looser cropping
3. Re-run with `--debug` flag to verify improvements

## Common Workflows

### Workflow 1: Single Educational Document

User request: "Resize this exam PDF to standard size"

1. Run resize script: `python3 scripts/resize_pdf.py exam.pdf`
2. Check output file quality
3. If needed, compress: `gs -sDEVICE=pdfwrite -dPDFSETTINGS=/ebook ...`

### Workflow 2: Batch Processing Course Materials

User request: "Process all 34 exam papers in this folder"

1. Configure `batch_process.py` with input/output paths
2. Run: `python3 scripts/batch_process.py`
3. Monitor progress (script shows real-time status)
4. Review output folder when complete

### Workflow 3: Debug Content Detection

User request: "Show me what areas are being detected"

1. Run visualization: `python3 scripts/visualize_content_boxes.py input.pdf`
2. Review red boxes in output PDF
3. Adjust parameters if needed
4. Re-run main resize script

### Workflow 4: Custom Dimensions

User request: "Resize to A4 size instead"

1. Edit `resize_pdf.py`:
   ```python
   TARGET_WIDTH_PT = 595    # A4 width
   TARGET_HEIGHT_PT = 842   # A4 height
   ```
2. Run resize script normally
3. Output will match A4 dimensions

## Technical Details

### Dependencies

Required Python packages:
- `PIL` (Pillow) - Image processing and PDF generation
- `pdf2image` - PDF to image conversion
- `cv2` (OpenCV) - Content detection algorithms
- `numpy` - Numerical operations

System requirements:
- Ghostscript - PDF compression (optional but recommended)
- Poppler - Required by pdf2image for PDF rendering

### File Naming Convention

Output files follow this pattern:
- Single file: `<basename>_final_HHMMSS.pdf`
- Batch processing: `<basename>_final.pdf`
- Debug output: `debug_*_YYYYMMDD_HHMMSS_*.jpg`

### Performance

Typical processing times (18-page document):
- Resize: ~30 seconds per file
- Compression: ~5-10 seconds per file
- Total: ~40 seconds per document

Batch processing 34 files: ~20-30 minutes

## Resources

### scripts/

**resize_pdf.py** - Main PDF resizing script with Dual-Masking content detection
- Execute directly on single PDF files
- Supports `--debug` flag for visualization
- Configurable via constants at top of file

**batch_process.py** - Batch processing orchestrator
- Processes multiple PDFs automatically
- Handles both resize and compression
- Progress reporting with file counts

**compress_pdf.py** - Standalone compression utility
- Reduces file size while maintaining quality
- Configurable JPEG quality and DPI
- Useful for post-processing existing PDFs

**visualize_content_boxes.py** - Debug visualization tool
- Shows detected content areas with red boxes
- Displays coordinates and dimensions
- Essential for troubleshooting detection issues

### Configuration

All scripts use consistent configuration variables that can be modified:
- Target dimensions (points)
- DPI resolution
- Margin percentages
- Detection thresholds
- Quality settings

Refer to the Quick Start section for common configuration patterns.
