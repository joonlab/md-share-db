#!/usr/bin/env python3
"""
PDF Content Resizer - Pixel-Perfect Tight Crop & Centering
Non-Zero Pixel Counting 방식을 사용한 정밀 크롭 및 균일한 센터링
"""

import cv2
import numpy as np
from PIL import Image
from pdf2image import convert_from_path
import os
from datetime import datetime
import sys
import subprocess
import shutil

# ============================================================
# 설정 변수 (Configuration)
# ============================================================
DEBUG_MODE = False  # True로 설정하면 감지된 영역을 시각화
TARGET_WIDTH_PT = 773.76  # 타겟 PDF 너비 (포인트)
TARGET_HEIGHT_PT = 1119.6  # 타겟 PDF 높이 (포인트)
DPI = 300  # 처리 해상도
NATURAL_MARGIN_PERCENT = 0.05  # 자연스러운 여백 비율 (5% - 캔버스 크기의 비율)
EDGE_MASK_PERCENT = 0.02  # 가장자리 마스킹 비율 (2% - 스캔 그림자 제거용)
MIN_CONTENT_WIDTH = 200  # 최소 콘텐츠 너비 (픽셀)
MIN_CONTENT_HEIGHT = 200  # 최소 콘텐츠 높이 (픽셀)
DESPECKLE_KERNEL_SIZE = 3  # 노이즈 제거용 커널 크기 (3x3 or 5x5)
MIN_COMPONENT_AREA = 50  # Text Mask용 최소 면적 (픽셀) - 작은 점/먼지 제거
HORIZONTAL_LINE_KERNEL_WIDTH = 50  # 가로선 감지용 커널 너비 (픽셀)
BBOX_PADDING = 15  # BBox 주변 안전 여백 (픽셀)

# 디버그 출력 디렉토리
DEBUG_OUTPUT_DIR = "debug_output"


def get_tight_content_bbox(image):
    """
    Dual-Masking Strategy로 콘텐츠 영역을 정밀하게 감지합니다.

    이 함수는 다음 단계를 수행합니다:
    1. Grayscale & Thresholding
    2. Despeckle (초기 노이즈 제거)
    3. Remove Page Borders (가장자리 마스킹)
    4. Text Mask 생성 (Area-based Filtering으로 작은 점 제거)
    5. Line Mask 생성 (가로선 전용 감지 및 보호)
    6. Dual-Masking (Text + Line 마스크 결합)
    7. BBox Calculation with Padding

    Args:
        image: PIL Image 객체 또는 numpy array

    Returns:
        tuple: (x, y, w, h) 콘텐츠 영역의 타이트한 경계 박스
    """
    # PIL Image를 numpy array로 변환
    if isinstance(image, Image.Image):
        img_array = np.array(image)
    else:
        img_array = image

    # RGB를 그레이스케일로 변환
    if len(img_array.shape) == 3:
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    else:
        gray = img_array

    height, width = gray.shape

    # Step 1: Adaptive Thresholding (글자를 흰색으로, 배경을 검은색으로)
    # THRESH_BINARY_INV를 사용하여 텍스트가 흰색(255)이 되도록 반전
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Step 2: Despeckle - Morphological Opening으로 작은 노이즈 제거
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,
                                      (DESPECKLE_KERNEL_SIZE, DESPECKLE_KERNEL_SIZE))
    despecked = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)

    # Step 3: Remove Page Borders - 가장자리를 강제로 검정색(0)으로 마스킹
    # 스캔 시 생기는 검은 줄/그림자 제거
    mask_h = int(height * EDGE_MASK_PERCENT)
    mask_w = int(width * EDGE_MASK_PERCENT)

    masked = despecked.copy()
    # 상하좌우 가장자리를 0으로 설정
    masked[:mask_h, :] = 0  # 위쪽
    masked[-mask_h:, :] = 0  # 아래쪽
    masked[:, :mask_w] = 0  # 왼쪽
    masked[:, -mask_w:] = 0  # 오른쪽

    # Step 4: Dual-Masking Strategy (핵심 개선!)
    # Mask 1: Text Mask (텍스트 보호) + Mask 2: Line Mask (가로선 보호)

    # 4-1. Text Mask 생성 - Area-based Filtering으로 작은 노이즈만 제거
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
        masked, connectivity=8
    )

    text_mask = np.zeros_like(masked)
    removed_components = 0

    # 각 컴포넌트를 분석하여 면적이 충분한 것만 유지
    for i in range(1, num_labels):  # 0은 배경이므로 제외
        area = stats[i, cv2.CC_STAT_AREA]
        if area >= MIN_COMPONENT_AREA:
            # 유의미한 텍스트로 판단 - 유지
            text_mask[labels == i] = 255
        else:
            # 작은 노이즈로 판단 - 제거
            removed_components += 1

    if DEBUG_MODE:
        print(f"  [DEBUG] Text Mask: {removed_components}개의 작은 컴포넌트 제거됨")

    # 4-2. Line Mask 생성 - 가로로 긴 직선 전용 감지 (VIP 보호)
    # 가로로 긴 커널을 사용하여 오직 긴 직선만 추출
    horizontal_kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT,
        (HORIZONTAL_LINE_KERNEL_WIDTH, 1)  # 가로 50px, 세로 1px
    )

    # Morphological Opening: 가로로 긴 것만 살아남음
    line_mask = cv2.morphologyEx(masked, cv2.MORPH_OPEN, horizontal_kernel)

    if DEBUG_MODE:
        line_pixels = cv2.countNonZero(line_mask)
        print(f"  [DEBUG] Line Mask: {line_pixels}개의 픽셀 (가로선) 감지됨")

    # 디버그용: 마스크 저장
    text_mask_debug = text_mask.copy() if DEBUG_MODE else None
    line_mask_debug = line_mask.copy() if DEBUG_MODE else None

    # 4-3. Dual-Masking: 두 마스크 결합 (OR 연산)
    # 텍스트 + 긴 가로선이 모두 보호됨
    combined_mask = cv2.bitwise_or(text_mask, line_mask)

    if DEBUG_MODE:
        combined_pixels = cv2.countNonZero(combined_mask)
        print(f"  [DEBUG] Combined Mask: {combined_pixels}개의 픽셀 (총 콘텐츠)")

    # Step 5: BBox Calculation from Combined Mask
    # 결합된 마스크에서 BBox 계산
    final_points = cv2.findNonZero(combined_mask)

    if final_points is None or len(final_points) == 0:
        print("경고: Combined Mask에서 콘텐츠를 찾을 수 없습니다. 전체 이미지를 사용합니다.")
        return (0, 0, width, height)

    # BBox 계산
    bbox_x, bbox_y, bbox_w, bbox_h = cv2.boundingRect(final_points)

    if DEBUG_MODE:
        print(f"  [DEBUG] Raw BBox: ({bbox_x}, {bbox_y}) {bbox_w}x{bbox_h}")

    # Step 6: Apply Safety Padding
    # 안전 여백 추가
    x = max(0, bbox_x - BBOX_PADDING)
    y = max(0, bbox_y - BBOX_PADDING)
    w = min(width - x, bbox_w + (BBOX_PADDING * 2))
    h = min(height - y, bbox_h + (BBOX_PADDING * 2))

    if DEBUG_MODE:
        print(f"  [DEBUG] Final BBox (with padding={BBOX_PADDING}px): ({x}, {y}) {w}x{h}")

    # 최소 크기 검증
    if w < MIN_CONTENT_WIDTH or h < MIN_CONTENT_HEIGHT:
        print(f"경고: 감지된 콘텐츠가 너무 작습니다 (w={w}, h={h}). 전체 이미지를 사용합니다.")
        return (0, 0, width, height)

    # 디버그 모드: 시각화
    if DEBUG_MODE:
        # 디버그 출력 디렉토리 생성
        os.makedirs(DEBUG_OUTPUT_DIR, exist_ok=True)

        font = cv2.FONT_HERSHEY_SIMPLEX

        # 원본 이미지에 최종 박스 그리기
        debug_original = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
        cv2.rectangle(debug_original, (x, y), (x + w, y + h), (255, 0, 0), 8)
        cv2.putText(debug_original, f"Final: ({x},{y}) {w}x{h}",
                   (30, 60), font, 1.2, (255, 0, 0), 3)

        # Text Mask (텍스트만)
        debug_text = cv2.cvtColor(text_mask_debug, cv2.COLOR_GRAY2RGB)
        cv2.putText(debug_text, "1. Text Mask", (30, 60), font, 1.2, (255, 255, 255), 3)

        # Line Mask (가로선만)
        debug_line = cv2.cvtColor(line_mask_debug, cv2.COLOR_GRAY2RGB)
        cv2.putText(debug_line, "2. Line Mask (VIP)", (30, 60), font, 1.2, (0, 255, 0), 3)

        # Combined Mask (텍스트 + 가로선)
        debug_combined = cv2.cvtColor(combined_mask, cv2.COLOR_GRAY2RGB)
        cv2.rectangle(debug_combined, (bbox_x, bbox_y), (bbox_x + bbox_w, bbox_y + bbox_h),
                     (0, 255, 255), 6)  # 노란색 = Raw BBox
        cv2.putText(debug_combined, "3. Combined (Text+Line)", (30, 60), font, 1.2, (255, 255, 255), 3)

        # Final Result - 원본에 Raw BBox와 Final BBox 모두 표시
        debug_final = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
        # Raw BBox (노란색, 얇게)
        cv2.rectangle(debug_final, (bbox_x, bbox_y), (bbox_x + bbox_w, bbox_y + bbox_h),
                     (0, 255, 255), 4)
        # Final BBox (빨간색, 두껍게)
        cv2.rectangle(debug_final, (x, y), (x + w, y + h), (255, 0, 0), 8)
        cv2.putText(debug_final, f"4. Final (pad={BBOX_PADDING}px)",
                   (30, 60), font, 1.2, (255, 0, 0), 3)
        cv2.putText(debug_final, "Yellow=Raw, Red=Final",
                   (30, 120), font, 1.0, (255, 255, 255), 2)

        # 합친 이미지 (2x2 grid)
        row1 = np.hstack([debug_original, debug_text])
        row2 = np.hstack([debug_line, debug_combined])
        row3 = np.hstack([debug_final, np.zeros_like(debug_final)])  # 빈 칸
        combined_viz = np.vstack([row1, row2, row3])

        # 3x2 대신 2x3으로 재구성
        row1 = np.hstack([debug_original, debug_text, debug_line])
        row2 = np.hstack([debug_combined, debug_final, np.zeros_like(debug_final)])
        combined_viz = np.vstack([row1, row2])

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        debug_path = os.path.join(DEBUG_OUTPUT_DIR, f"debug_dual_mask_{timestamp}.jpg")
        cv2.imwrite(debug_path, combined_viz)
        print(f"  [DEBUG] Dual-Masking 시각화 저장: {debug_path}")

    return (x, y, w, h)


def process_page(image, target_width_px, target_height_px, page_num=0):
    """
    페이지 이미지를 처리하여 타겟 캔버스에 정밀하게 리사이징 및 센터링합니다.

    Args:
        image: PIL Image 객체
        target_width_px: 타겟 너비 (픽셀)
        target_height_px: 타겟 높이 (픽셀)
        page_num: 페이지 번호 (디버그용)

    Returns:
        PIL.Image: 처리된 이미지
    """
    # Step 1: Tight Content Box 감지
    x, y, w, h = get_tight_content_bbox(image)

    # Step 2: 콘텐츠 영역 추출 (Crop)
    img_array = np.array(image)
    content = img_array[y:y+h, x:x+w]
    content_img = Image.fromarray(content)

    # Step 3: 안전 영역(Safety Zone) 계산
    # 캔버스 크기 기준 비율로 자연스러운 여백 계산
    margin_w = int(target_width_px * NATURAL_MARGIN_PERCENT)
    margin_h = int(target_height_px * NATURAL_MARGIN_PERCENT)
    safe_width = target_width_px - (2 * margin_w)
    safe_height = target_height_px - (2 * margin_h)

    # Step 4: Scale Factor 계산 (종횡비 유지)
    scale_w = safe_width / w
    scale_h = safe_height / h
    scale_factor = min(scale_w, scale_h)  # 더 작은 비율 선택

    # Step 5: 리사이징
    new_width = int(w * scale_factor)
    new_height = int(h * scale_factor)

    # 고품질 리샘플링 (LANCZOS)
    resized_content = content_img.resize((new_width, new_height), Image.Resampling.LANCZOS)

    # Step 6: 하얀 캔버스 생성
    canvas = Image.new('RGB', (target_width_px, target_height_px), (255, 255, 255))

    # Step 7: Visual Centering - 물리적 정중앙에 정확히 배치
    x_offset = (target_width_px - new_width) // 2
    y_offset = (target_height_px - new_height) // 2

    # Step 8: 캔버스에 붙이기
    canvas.paste(resized_content, (x_offset, y_offset))

    # 디버그 모드: 최종 배치 영역 표시
    if DEBUG_MODE:
        os.makedirs(DEBUG_OUTPUT_DIR, exist_ok=True)

        # 캔버스에 빨간색 박스 그리기 (최종 배치 영역)
        canvas_array = np.array(canvas)
        debug_canvas = canvas_array.copy()

        # 빨간색 박스: 최종 배치 영역
        cv2.rectangle(debug_canvas,
                     (x_offset, y_offset),
                     (x_offset + new_width, y_offset + new_height),
                     (255, 0, 0), 8)

        # 안전 영역도 표시 (녹색 점선)
        margin_w = int(target_width_px * NATURAL_MARGIN_PERCENT)
        margin_h = int(target_height_px * NATURAL_MARGIN_PERCENT)
        cv2.rectangle(debug_canvas,
                     (margin_w, margin_h),
                     (target_width_px - margin_w, target_height_px - margin_h),
                     (0, 255, 0), 5)

        # 텍스트 정보 추가
        font = cv2.FONT_HERSHEY_SIMPLEX
        info_text = [
            f"Scale: {scale_factor:.3f}",
            f"Original: {w}x{h}",
            f"Resized: {new_width}x{new_height}",
            f"Position: ({x_offset}, {y_offset})"
        ]

        y_text = 50
        for text in info_text:
            cv2.putText(debug_canvas, text, (30, y_text), font, 1.2, (0, 0, 255), 3)
            y_text += 50

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        debug_path = os.path.join(DEBUG_OUTPUT_DIR, f"debug_final_page_{page_num:03d}_{timestamp}.jpg")
        cv2.imwrite(debug_path, cv2.cvtColor(debug_canvas, cv2.COLOR_RGB2BGR))
        print(f"  [DEBUG] 최종 배치 시각화 저장: {debug_path}")

    return canvas


def compress_with_ghostscript(input_pdf, output_pdf):
    """
    Ghostscript를 사용하여 PDF를 압축합니다.

    Args:
        input_pdf: 입력 PDF 경로
        output_pdf: 출력 PDF 경로

    Returns:
        bool: 성공 여부
    """
    # Ghostscript가 설치되어 있는지 확인
    if not shutil.which('gs'):
        print("경고: Ghostscript가 설치되어 있지 않습니다. 압축을 건너뜁니다.")
        return False

    print("\nGhostscript 압축 중...")

    try:
        cmd = [
            'gs',
            '-sDEVICE=pdfwrite',
            '-dCompatibilityLevel=1.4',
            '-dPDFSETTINGS=/ebook',
            '-dNOPAUSE',
            '-dQUIET',
            '-dBATCH',
            f'-sOutputFile={output_pdf}',
            input_pdf
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            print(f"✓ 압축 완료: {output_pdf}")
            return True
        else:
            print(f"✗ 압축 실패: {result.stderr}")
            return False

    except Exception as e:
        print(f"✗ 압축 중 오류 발생: {e}")
        return False


def resize_pdf(input_path, output_path):
    """
    PDF 파일을 Pixel-Perfect 방식으로 리사이징합니다.

    Args:
        input_path: 입력 PDF 경로
        output_path: 출력 PDF 경로

    Returns:
        bool: 성공 여부
    """
    print(f"\n{'='*60}")
    print(f"PDF 리사이징 시작")
    print(f"{'='*60}")
    print(f"입력 파일: {input_path}")
    print(f"출력 파일: {output_path}")
    print(f"설정: DPI={DPI}, 타겟={TARGET_WIDTH_PT}x{TARGET_HEIGHT_PT}pt")
    print(f"      자연여백={NATURAL_MARGIN_PERCENT*100}%, 가장자리마스킹={EDGE_MASK_PERCENT*100}%")
    print(f"{'='*60}\n")

    # PDF를 고해상도 이미지로 변환
    try:
        print("PDF → 이미지 변환 중...")
        pages = convert_from_path(input_path, dpi=DPI)
        print(f"✓ 총 {len(pages)} 페이지 감지됨\n")
    except Exception as e:
        print(f"✗ 오류: PDF 변환 실패 - {e}")
        return False

    # 타겟 크기를 픽셀로 변환
    target_width_px = int(TARGET_WIDTH_PT * DPI / 72)
    target_height_px = int(TARGET_HEIGHT_PT * DPI / 72)

    margin_w = int(target_width_px * NATURAL_MARGIN_PERCENT)
    margin_h = int(target_height_px * NATURAL_MARGIN_PERCENT)
    print(f"타겟 캔버스 크기: {target_width_px} x {target_height_px} px")
    print(f"안전 영역: {target_width_px - 2*margin_w} x {target_height_px - 2*margin_h} px (여백: {margin_w}x{margin_h}px)\n")

    # 각 페이지 처리
    processed_pages = []
    for i, page in enumerate(pages, 1):
        print(f"[{i}/{len(pages)}] 페이지 처리 중...")
        try:
            processed = process_page(page, target_width_px, target_height_px, page_num=i)
            processed_pages.append(processed)
            print(f"[{i}/{len(pages)}] ✓ 완료\n")
        except Exception as e:
            print(f"[{i}/{len(pages)}] ✗ 경고: 처리 중 오류 발생 - {e}")
            print(f"[{i}/{len(pages)}] 빈 페이지로 대체합니다.\n")
            # 빈 페이지로 대체
            blank = Image.new('RGB', (target_width_px, target_height_px), (255, 255, 255))
            processed_pages.append(blank)

    # PDF로 저장
    if processed_pages:
        try:
            print("최종 PDF 생성 중...")
            # 첫 페이지를 기준으로 나머지 페이지들을 추가
            processed_pages[0].save(
                output_path,
                "PDF",
                resolution=DPI,
                save_all=True,
                append_images=processed_pages[1:] if len(processed_pages) > 1 else []
            )
            print(f"✓ 저장 완료: {output_path}\n")
            return True
        except Exception as e:
            print(f"✗ 오류: PDF 저장 실패 - {e}")
            return False
    else:
        print("✗ 오류: 처리된 페이지가 없습니다.")
        return False


def main():
    """메인 함수"""
    if len(sys.argv) < 2:
        print("사용법: python resize_pdf.py <입력_PDF_파일> [--debug]")
        print("  --debug: 디버그 모드 활성화 (감지 영역 시각화)")
        sys.exit(1)

    # 디버그 모드 체크
    global DEBUG_MODE
    if "--debug" in sys.argv:
        DEBUG_MODE = True
        print("\n[DEBUG MODE ENABLED] 감지 영역이 시각화됩니다.\n")
        sys.argv.remove("--debug")

    input_path = sys.argv[1]

    # 파일 존재 확인
    if not os.path.exists(input_path):
        print(f"오류: 파일을 찾을 수 없습니다 - {input_path}")
        sys.exit(1)

    # 출력 파일명 생성
    base_name = os.path.splitext(input_path)[0]
    timestamp = datetime.now().strftime("%H%M%S")
    output_path_temp = f"{base_name}_final_{timestamp}_temp.pdf"
    output_path_final = f"{base_name}_final_{timestamp}.pdf"

    # PDF 리사이징 실행
    success = resize_pdf(input_path, output_path_temp)

    if success:
        # 리사이즈 후 자동으로 Ghostscript 압축 진행
        compress_success = compress_with_ghostscript(output_path_temp, output_path_final)

        if compress_success:
            # 압축이 성공하면 임시 파일 삭제
            try:
                os.remove(output_path_temp)
                print(f"✓ 임시 파일 삭제: {output_path_temp}")
            except Exception as e:
                print(f"경고: 임시 파일 삭제 실패 - {e}")

            # 파일 크기 비교
            input_size = os.path.getsize(input_path) / 1024 / 1024
            output_size = os.path.getsize(output_path_final) / 1024 / 1024

            print(f"\n{'='*60}")
            print(f"작업 완료")
            print(f"{'='*60}")
            print(f"입력: {input_path} ({input_size:.2f} MB)")
            print(f"출력: {output_path_final} ({output_size:.2f} MB)")
            print(f"압축률: {((input_size - output_size) / input_size * 100):.1f}% 감소" if output_size < input_size else f"크기 증가: {((output_size - input_size) / input_size * 100):.1f}%")
            if DEBUG_MODE:
                print(f"디버그 이미지: {DEBUG_OUTPUT_DIR}/ 디렉토리")
            print(f"{'='*60}\n")
        else:
            # 압축 실패 시 임시 파일을 최종 파일로 사용
            print(f"\n경고: 압축에 실패했습니다. 압축되지 않은 파일을 사용합니다.")
            try:
                os.rename(output_path_temp, output_path_final)
                print(f"✓ 파일 이름 변경: {output_path_final}")
            except Exception as e:
                print(f"경고: 파일 이름 변경 실패 - {e}")
                output_path_final = output_path_temp

            # 파일 크기 비교
            input_size = os.path.getsize(input_path) / 1024 / 1024
            output_size = os.path.getsize(output_path_final) / 1024 / 1024

            print(f"\n{'='*60}")
            print(f"작업 완료 (압축 없음)")
            print(f"{'='*60}")
            print(f"입력: {input_path} ({input_size:.2f} MB)")
            print(f"출력: {output_path_final} ({output_size:.2f} MB)")
            if DEBUG_MODE:
                print(f"디버그 이미지: {DEBUG_OUTPUT_DIR}/ 디렉토리")
            print(f"{'='*60}\n")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
