#!/usr/bin/env python3
"""
PDF Compression Tool
품질을 유지하면서 PDF 용량을 최적화
"""

from PIL import Image
from pdf2image import convert_from_path
import os
import sys
from datetime import datetime

# 설정
DPI = 300  # 해상도 유지
JPEG_QUALITY = 92  # JPEG 품질 (85-95 권장, 높을수록 고품질)
OPTIMIZE = True  # PIL 최적화 활성화


def compress_pdf(input_path, output_path):
    """
    PDF를 품질 유지하면서 압축합니다.

    Args:
        input_path: 입력 PDF 경로
        output_path: 출력 PDF 경로
    """
    print(f"\n{'='*60}")
    print(f"PDF 압축 시작")
    print(f"{'='*60}")
    print(f"입력 파일: {input_path}")
    print(f"출력 파일: {output_path}")
    print(f"설정: DPI={DPI}, JPEG품질={JPEG_QUALITY}")
    print(f"{'='*60}\n")

    # 원본 파일 크기
    input_size = os.path.getsize(input_path) / 1024 / 1024
    print(f"원본 크기: {input_size:.2f} MB\n")

    # PDF를 이미지로 변환
    try:
        print("PDF → 이미지 변환 중...")
        pages = convert_from_path(input_path, dpi=DPI)
        print(f"✓ 총 {len(pages)} 페이지 변환됨\n")
    except Exception as e:
        print(f"✗ 오류: PDF 변환 실패 - {e}")
        return False

    # 각 페이지를 JPEG로 최적화
    print("이미지 압축 중...")
    compressed_pages = []

    for i, page in enumerate(pages, 1):
        print(f"  [{i}/{len(pages)}] 페이지 압축 중...", end='')

        # RGB 모드로 변환 (JPEG는 RGB만 지원)
        if page.mode != 'RGB':
            page = page.convert('RGB')

        compressed_pages.append(page)
        print(" ✓")

    # PDF로 저장 (JPEG 압축 적용)
    try:
        print("\n압축된 PDF 생성 중...")

        # 첫 페이지를 기준으로 저장
        compressed_pages[0].save(
            output_path,
            "PDF",
            resolution=DPI,
            save_all=True,
            append_images=compressed_pages[1:] if len(compressed_pages) > 1 else [],
            quality=JPEG_QUALITY,
            optimize=OPTIMIZE
        )

        print(f"✓ 저장 완료: {output_path}\n")

        # 결과 비교
        output_size = os.path.getsize(output_path) / 1024 / 1024
        reduction = ((input_size - output_size) / input_size) * 100

        print(f"{'='*60}")
        print(f"압축 완료")
        print(f"{'='*60}")
        print(f"원본 크기: {input_size:.2f} MB")
        print(f"압축 후:   {output_size:.2f} MB")
        print(f"감소율:    {reduction:.1f}% 감소")
        print(f"{'='*60}\n")

        return True

    except Exception as e:
        print(f"✗ 오류: PDF 저장 실패 - {e}")
        return False


def main():
    """메인 함수"""
    if len(sys.argv) < 2:
        print("사용법: python compress_pdf.py <입력_PDF_파일>")
        sys.exit(1)

    input_path = sys.argv[1]

    # 파일 존재 확인
    if not os.path.exists(input_path):
        print(f"오류: 파일을 찾을 수 없습니다 - {input_path}")
        sys.exit(1)

    # 출력 파일명 생성
    base_name = os.path.splitext(input_path)[0]

    # "_final_" 뒤의 타임스탬프 유지
    if "_final_" in base_name:
        # 기존 타임스탬프 유지
        output_path = f"{base_name}_compressed.pdf"
    else:
        # 새로운 타임스탬프 추가
        timestamp = datetime.now().strftime("%H%M%S")
        output_path = f"{base_name}_compressed_{timestamp}.pdf"

    # 압축 실행
    success = compress_pdf(input_path, output_path)

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
