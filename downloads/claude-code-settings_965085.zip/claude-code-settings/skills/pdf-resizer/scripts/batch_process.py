#!/usr/bin/env python3
"""
Batch PDF Processing Script
여러 PDF 파일을 일괄 리사이징 및 압축 처리
"""

import os
import sys
import subprocess
from datetime import datetime
from pathlib import Path

# 설정
INPUT_DIR = "/Users/joon/Downloads/drive-download-20251122T105657Z-1-001"
OUTPUT_DIR = "/Users/joon/Desktop/정현_resize_project_20251122/Final_of_final"
RESIZE_SCRIPT = "/Users/joon/Desktop/정현_resize_project_20251122/resize_pdf.py"
CURRENT_PDF = "/Users/joon/Desktop/정현_resize_project_20251122/강대모의고사K 1회 해설.pdf"

def process_single_pdf(input_path, output_dir):
    """
    단일 PDF 파일을 처리합니다.

    Args:
        input_path: 입력 PDF 경로
        output_dir: 출력 디렉토리

    Returns:
        tuple: (성공 여부, 최종 파일 경로)
    """
    filename = os.path.basename(input_path)
    base_name = os.path.splitext(filename)[0]

    print(f"\n{'='*70}")
    print(f"처리 중: {filename}")
    print(f"{'='*70}")

    try:
        # Step 1: resize_pdf.py 실행
        print("Step 1/2: PDF 리사이징 중...")

        # 임시 출력 파일 (타임스탬프 포함)
        timestamp = datetime.now().strftime("%H%M%S")
        temp_output = f"/tmp/{base_name}_final_{timestamp}.pdf"

        # resize_pdf.py를 직접 import하여 사용
        import resize_pdf
        success = resize_pdf.resize_pdf(input_path, temp_output)

        if not success:
            print(f"✗ 리사이징 실패: {filename}")
            return (False, None)

        # Step 2: Ghostscript로 압축
        print("\nStep 2/2: PDF 압축 중...")
        final_output = os.path.join(output_dir, f"{base_name}_final.pdf")

        gs_cmd = [
            "gs",
            "-sDEVICE=pdfwrite",
            "-dCompatibilityLevel=1.4",
            "-dPDFSETTINGS=/ebook",
            "-dNOPAUSE",
            "-dQUIET",
            "-dBATCH",
            f"-sOutputFile={final_output}",
            temp_output
        ]

        result = subprocess.run(gs_cmd, capture_output=True, text=True)

        if result.returncode != 0:
            print(f"✗ 압축 실패: {filename}")
            print(f"오류: {result.stderr}")
            # 압축 실패 시 원본 리사이즈된 파일을 복사
            import shutil
            shutil.copy(temp_output, final_output)

        # 임시 파일 삭제
        if os.path.exists(temp_output):
            os.remove(temp_output)

        # 파일 크기 확인
        input_size = os.path.getsize(input_path) / 1024 / 1024
        output_size = os.path.getsize(final_output) / 1024 / 1024

        print(f"✓ 완료: {filename}")
        print(f"  원본: {input_size:.2f} MB → 최종: {output_size:.2f} MB")

        return (True, final_output)

    except Exception as e:
        print(f"✗ 오류 발생: {filename}")
        print(f"  {e}")
        return (False, None)


def main():
    """메인 함수"""
    print("\n" + "="*70)
    print("PDF 일괄 처리 시작")
    print("="*70)
    print(f"입력 디렉토리: {INPUT_DIR}")
    print(f"출력 디렉토리: {OUTPUT_DIR}")
    print("="*70)

    # 출력 디렉토리 생성
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Step 1: 현재 작업 중인 1회 파일 먼저 처리
    print("\n[현재 파일] 강대모의고사K 1회 해설.pdf 처리 중...")
    current_optimized = "/Users/joon/Desktop/정현_resize_project_20251122/강대모의고사K 1회 해설_final_232109_optimized.pdf"

    if os.path.exists(current_optimized):
        import shutil
        dest = os.path.join(OUTPUT_DIR, "강대모의고사K 1회 해설_final.pdf")
        shutil.copy(current_optimized, dest)
        size = os.path.getsize(dest) / 1024 / 1024
        print(f"✓ 완료: 강대모의고사K 1회 해설_final.pdf ({size:.2f} MB)")

    # Step 2: Downloads 폴더의 모든 PDF 파일 처리
    pdf_files = sorted([f for f in os.listdir(INPUT_DIR) if f.endswith('.pdf')])

    print(f"\n[일괄 처리] {len(pdf_files)}개 파일 발견")

    success_count = 0
    fail_count = 0

    for i, filename in enumerate(pdf_files, 1):
        input_path = os.path.join(INPUT_DIR, filename)

        print(f"\n진행: [{i}/{len(pdf_files)}]")
        success, output_path = process_single_pdf(input_path, OUTPUT_DIR)

        if success:
            success_count += 1
        else:
            fail_count += 1

    # 최종 요약
    print("\n" + "="*70)
    print("일괄 처리 완료")
    print("="*70)
    print(f"총 파일 수: {len(pdf_files) + 1}")  # +1 for 1회
    print(f"성공: {success_count + 1}")
    print(f"실패: {fail_count}")
    print(f"출력 디렉토리: {OUTPUT_DIR}")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
