#!/usr/bin/env python3
"""
PDF Content Box Visualizer
원본 PDF에 감지된 콘텐츠 영역을 빨간색 박스로 표시
"""

import cv2
import numpy as np
from PIL import Image
from pdf2image import convert_from_path
import os
from datetime import datetime
import sys

# resize_pdf.py와 동일한 설정 사용
DPI = 300
EDGE_MASK_PERCENT = 0.02
MIN_CONTENT_WIDTH = 200
MIN_CONTENT_HEIGHT = 200
DESPECKLE_KERNEL_SIZE = 3
MIN_COMPONENT_AREA = 50  # Text Mask용 최소 면적 (픽셀)
HORIZONTAL_LINE_KERNEL_WIDTH = 50  # 가로선 감지용 커널 너비
BBOX_PADDING = 15  # BBox 주변 안전 여백 (픽셀)


def get_tight_content_bbox(image):
    """
    resize_pdf.py와 동일한 Dual-Masking 알고리즘으로 콘텐츠 영역을 감지합니다.
    """
    # PIL Image를 numpy array로 변환
    if isinstance(image, Image.Image):
        img_array = np.array(image)
    else:
        img_array = image

    # RGB를 그레이스케일로 변환
    if len(img_array.shape) == 3:
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    else:
        gray = img_array

    height, width = gray.shape

    # Step 1: Adaptive Thresholding
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Step 2: Despeckle
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,
                                      (DESPECKLE_KERNEL_SIZE, DESPECKLE_KERNEL_SIZE))
    despecked = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)

    # Step 3: Remove Page Borders
    mask_h = int(height * EDGE_MASK_PERCENT)
    mask_w = int(width * EDGE_MASK_PERCENT)

    masked = despecked.copy()
    masked[:mask_h, :] = 0
    masked[-mask_h:, :] = 0
    masked[:, :mask_w] = 0
    masked[:, -mask_w:] = 0

    # Step 4: Dual-Masking Strategy
    # 4-1. Text Mask
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
        masked, connectivity=8
    )

    text_mask = np.zeros_like(masked)
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area >= MIN_COMPONENT_AREA:
            text_mask[labels == i] = 255

    # 4-2. Line Mask
    horizontal_kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT,
        (HORIZONTAL_LINE_KERNEL_WIDTH, 1)
    )
    line_mask = cv2.morphologyEx(masked, cv2.MORPH_OPEN, horizontal_kernel)

    # 4-3. Combine
    combined_mask = cv2.bitwise_or(text_mask, line_mask)

    # Step 5: BBox Calculation
    final_points = cv2.findNonZero(combined_mask)

    if final_points is None or len(final_points) == 0:
        print("  경고: Combined Mask에서 콘텐츠를 찾을 수 없습니다. 전체 이미지를 사용합니다.")
        return (0, 0, width, height)

    bbox_x, bbox_y, bbox_w, bbox_h = cv2.boundingRect(final_points)

    # Step 6: Apply Padding
    x = max(0, bbox_x - BBOX_PADDING)
    y = max(0, bbox_y - BBOX_PADDING)
    w = min(width - x, bbox_w + (BBOX_PADDING * 2))
    h = min(height - y, bbox_h + (BBOX_PADDING * 2))

    # 최소 크기 검증
    if w < MIN_CONTENT_WIDTH or h < MIN_CONTENT_HEIGHT:
        print(f"  경고: 감지된 콘텐츠가 너무 작습니다 (w={w}, h={h}).")
        return (0, 0, width, height)

    return (x, y, w, h)


def visualize_content_boxes(input_path, output_path):
    """
    원본 PDF의 각 페이지에 감지된 콘텐츠 영역을 빨간색 박스로 표시합니다.
    """
    print(f"\n{'='*60}")
    print(f"콘텐츠 영역 시각화")
    print(f"{'='*60}")
    print(f"입력 파일: {input_path}")
    print(f"출력 파일: {output_path}")
    print(f"DPI: {DPI}")
    print(f"{'='*60}\n")

    # PDF를 고해상도 이미지로 변환
    try:
        print("PDF → 이미지 변환 중...")
        pages = convert_from_path(input_path, dpi=DPI)
        print(f"✓ 총 {len(pages)} 페이지 감지됨\n")
    except Exception as e:
        print(f"✗ 오류: PDF 변환 실패 - {e}")
        return False

    # 각 페이지 처리
    annotated_pages = []
    for i, page in enumerate(pages, 1):
        print(f"[{i}/{len(pages)}] 페이지 처리 중...")

        try:
            # 콘텐츠 영역 감지
            x, y, w, h = get_tight_content_bbox(page)

            # 원본 이미지를 numpy array로 변환
            img_array = np.array(page)

            # RGB로 변환 (필요시)
            if len(img_array.shape) == 2:
                img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)

            # 빨간색 박스 그리기
            # 두께를 두껍게 하여 눈에 잘 보이도록
            box_thickness = 15
            cv2.rectangle(img_array, (x, y), (x + w, y + h), (255, 0, 0), box_thickness)

            # 정보 텍스트 추가
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 2.5
            font_thickness = 6

            # 배경이 있는 텍스트 (가독성 향상)
            text = f"Content Box: ({x}, {y}) {w}x{h}"
            text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]

            # 텍스트 배경 (흰색 반투명 박스)
            text_x = x
            text_y = max(y - 30, text_size[1] + 20)

            # 배경 박스
            bg_x1 = text_x - 10
            bg_y1 = text_y - text_size[1] - 10
            bg_x2 = text_x + text_size[0] + 10
            bg_y2 = text_y + 10

            # 흰색 배경
            cv2.rectangle(img_array, (bg_x1, bg_y1), (bg_x2, bg_y2), (255, 255, 255), -1)
            # 검은색 테두리
            cv2.rectangle(img_array, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 0, 0), 3)

            # 텍스트 (빨간색)
            cv2.putText(img_array, text, (text_x, text_y),
                       font, font_scale, (255, 0, 0), font_thickness)

            # 페이지 번호도 추가
            page_text = f"Page {i}/{len(pages)}"
            cv2.putText(img_array, page_text, (50, 100),
                       font, 2.0, (0, 0, 255), 5)

            # PIL Image로 변환
            annotated = Image.fromarray(img_array)
            annotated_pages.append(annotated)

            print(f"  ✓ 박스 위치: ({x}, {y}), 크기: {w}x{h}")
            print(f"[{i}/{len(pages)}] ✓ 완료\n")

        except Exception as e:
            print(f"[{i}/{len(pages)}] ✗ 오류: {e}")
            # 오류 발생 시 원본 페이지 사용
            annotated_pages.append(page)

    # PDF로 저장
    if annotated_pages:
        try:
            print("최종 PDF 생성 중...")
            annotated_pages[0].save(
                output_path,
                "PDF",
                resolution=DPI,
                save_all=True,
                append_images=annotated_pages[1:] if len(annotated_pages) > 1 else []
            )
            print(f"✓ 저장 완료: {output_path}\n")
            return True
        except Exception as e:
            print(f"✗ 오류: PDF 저장 실패 - {e}")
            return False
    else:
        print("✗ 오류: 처리된 페이지가 없습니다.")
        return False


def main():
    """메인 함수"""
    if len(sys.argv) < 2:
        print("사용법: python visualize_content_boxes.py <입력_PDF_파일>")
        sys.exit(1)

    input_path = sys.argv[1]

    # 파일 존재 확인
    if not os.path.exists(input_path):
        print(f"오류: 파일을 찾을 수 없습니다 - {input_path}")
        sys.exit(1)

    # 출력 파일명 생성
    base_name = os.path.splitext(input_path)[0]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = f"{base_name}_with_boxes_{timestamp}.pdf"

    # 시각화 실행
    success = visualize_content_boxes(input_path, output_path)

    if success:
        # 파일 크기 비교
        input_size = os.path.getsize(input_path) / 1024 / 1024
        output_size = os.path.getsize(output_path) / 1024 / 1024

        print(f"\n{'='*60}")
        print(f"작업 완료")
        print(f"{'='*60}")
        print(f"입력: {input_path} ({input_size:.2f} MB)")
        print(f"출력: {output_path} ({output_size:.2f} MB)")
        print(f"{'='*60}\n")
        print("빨간색 박스가 표시된 PDF 파일을 확인해보세요!")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
