---
name: whisper-subtitle
description: Generate TXT or SRT subtitle/transcript files from audio or video files using mlx-whisper. This skill should be used when the user requests subtitle extraction, subtitle generation, transcript creation, or transcription from audio/video files. Supports batch processing (sequential). Triggers include phrases like "자막 추출해줘", "자막 생성해줘", "자막 파일 만들어줘", "generate subtitles", "extract subtitles", "create SRT", "transcribe this video/audio", or "트랜스크립트 만들어줘".
---

# Whisper Subtitle Generator

Generate TXT or SRT subtitle files from audio or video files using mlx-whisper with the whisper-medium-mlx model. Supports batch processing (sequential due to MLX GPU constraints).

## Quick Start

```bash
# Single file (default: TXT format, output to ~/Downloads)
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "<input_file>"

# Multiple files (batch processing - sequential)
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "<file1>" "<file2>" "<file3>"
```

## Default Settings

| Setting | Default Value |
|---------|---------------|
| Output directory | `/Users/joon/Downloads` |
| Output format | `txt` |
| Output filename | `{original_filename}_transcript.txt` or `.srt` |
| Model | `mlx-community/whisper-medium-mlx` |

## Important Note

**MLX GPU Constraint**: mlx-whisper uses Apple MLX (Metal GPU) which doesn't support parallel access from multiple threads. Batch processing is performed **sequentially** (one file at a time) to avoid GPU conflicts and crashes.

## Workflow

### 1. Identify Input File(s)

Supported formats:
- Audio: mp3, wav, m4a, flac, ogg, aac
- Video: mp4, mkv, mov, avi, webm

### 2. Determine Output Settings

- **Format**: Ask user if they want TXT (default) or SRT
- **Output directory**: Use user-specified path, or default `/Users/joon/Downloads`
- **Custom filename**: If user specifies, use `-n` option (single file only)

### 3. Run Subtitle Generation

#### Single File

```bash
# Basic (TXT to ~/Downloads)
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/video.mp4"

# SRT format
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/video.mp4" -f srt

# Custom output directory
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/video.mp4" -o "/custom/path"

# Custom filename
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/video.mp4" -n "my_custom_name"

# Specify language
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/video.mp4" -l en
```

#### Multiple Files (Batch Processing)

```bash
# Process multiple files (sequentially)
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/file1.mp4" "/path/file2.mp4" "/path/file3.mp4"

# Batch with SRT format
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/file1.mp4" "/path/file2.mp4" -f srt

# Batch with custom output directory
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/file1.mp4" "/path/file2.mp4" -o "/output/dir"
```

### 4. Report Results

After generation, report:
- Output file path(s)
- Processing time
- Success/failure status for each file (batch mode)

## Script Options

| Option | Description | Default |
|--------|-------------|---------|
| `-o, --output` | Output directory | `/Users/joon/Downloads` |
| `-f, --format` | Output format: `txt` or `srt` | `txt` |
| `-n, --name` | Custom filename (single file only) | `{filename}_transcript` |
| `-m, --model` | Whisper model | `mlx-community/whisper-medium-mlx` |
| `-l, --language` | Language code (en, ko, ja, etc.) | Auto-detect |

## Output Filename Convention

- Default: `{original_filename}_transcript.txt` or `{original_filename}_transcript.srt`
- Example: `video.mp4` → `video_transcript.txt`
- Custom: Use `-n` option to override (single file only)

## Available Models

| Model | Speed | Quality | Use Case |
|-------|-------|---------|----------|
| `mlx-community/whisper-small-mlx` | Fast | Good | Quick drafts |
| `mlx-community/whisper-medium-mlx` | Medium | Better | **Default, balanced** |
| `mlx-community/whisper-large-v3-mlx` | Slow | Best | High accuracy needed |
| `mlx-community/whisper-large-v3-turbo` | Fast | Good | Speed + quality |

## Example Requests

### Single File Examples

**User:** "이 영상 자막 추출해줘: /Users/joon/Desktop/video.mp4"
**Action:**
```bash
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/Users/joon/Desktop/video.mp4"
```

**User:** "SRT 자막 파일 만들어줘. 파일: /path/to/audio.mp3, 저장 위치: /Users/joon/Desktop"
**Action:**
```bash
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/audio.mp3" -f srt -o "/Users/joon/Desktop"
```

**User:** "Generate transcript named 'meeting_notes' for this video"
**Action:**
```bash
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/to/video.mp4" -n "meeting_notes"
```

### Batch Processing Examples

**User:** "이 폴더의 mp3 파일들 전부 자막 추출해줘"
**Action:** Identify all mp3 files and run batch:
```bash
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/file1.mp3" "/path/file2.mp3" "/path/file3.mp3"
```

**User:** "다음 5개 영상 SRT 자막 만들어줘: [file list]"
**Action:**
```bash
python3 ~/.claude/skills/whisper-subtitle/scripts/generate_subtitle.py "/path/v1.mp4" "/path/v2.mp4" "/path/v3.mp4" "/path/v4.mp4" "/path/v5.mp4" -f srt
```

## Resources

### scripts/

- `generate_subtitle.py` - Main subtitle generation script using mlx-whisper (sequential batch processing)
