#!/usr/bin/env python3
"""
Whisper Subtitle Generator
Generate TXT or SRT subtitle files from audio/video files using mlx-whisper.
Supports batch processing (sequential - mlx-whisper doesn't support parallel GPU access).
"""

import argparse
import sys
import time
from pathlib import Path
from typing import Optional

try:
    import mlx_whisper
except ImportError:
    print("Error: mlx-whisper is not installed. Install with: pip install mlx-whisper")
    sys.exit(1)


def format_timestamp(seconds: float) -> str:
    """Convert seconds to SRT timestamp format (HH:MM:SS,mmm)"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def generate_srt(segments: list) -> str:
    """Generate SRT content from whisper segments"""
    srt_lines = []
    for i, segment in enumerate(segments, 1):
        start = format_timestamp(segment["start"])
        end = format_timestamp(segment["end"])
        text = segment["text"].strip()
        srt_lines.append(f"{i}\n{start} --> {end}\n{text}\n")
    return "\n".join(srt_lines)


def transcribe_single_file(
    input_file: str,
    output_dir: str,
    output_format: str = "txt",
    model: str = "mlx-community/whisper-medium-mlx",
    language: Optional[str] = None,
    custom_name: Optional[str] = None
) -> dict:
    """
    Transcribe a single audio/video file.

    Returns:
        dict with keys: success, input, output, elapsed, error
    """
    result_info = {
        "success": False,
        "input": input_file,
        "output": None,
        "elapsed": 0,
        "error": None
    }

    try:
        input_path = Path(input_file)
        if not input_path.exists():
            result_info["error"] = f"File not found: {input_file}"
            return result_info

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Determine output filename
        if custom_name:
            base_name = custom_name
        else:
            base_name = f"{input_path.stem}_transcript"

        # Transcription options
        transcribe_opts = {
            "path_or_hf_repo": model,
            "word_timestamps": True,
        }
        if language:
            transcribe_opts["language"] = language

        print(f"[Processing] {input_path.name}...")
        start_time = time.time()

        transcription = mlx_whisper.transcribe(str(input_path), **transcribe_opts)

        elapsed = time.time() - start_time
        result_info["elapsed"] = elapsed

        # Save based on format
        if output_format == "srt":
            output_file = output_path / f"{base_name}.srt"
            content = generate_srt(transcription["segments"])
        else:  # txt (default)
            output_file = output_path / f"{base_name}.txt"
            content = transcription["text"]

        output_file.write_text(content, encoding="utf-8")

        result_info["success"] = True
        result_info["output"] = str(output_file)
        print(f"[Done] {input_path.name} -> {output_file.name} ({elapsed:.1f}s)")

    except Exception as e:
        result_info["error"] = str(e)
        print(f"[Error] {input_file}: {e}")

    return result_info


def transcribe_batch(
    input_files: list,
    output_dir: str,
    output_format: str = "txt",
    model: str = "mlx-community/whisper-medium-mlx",
    language: Optional[str] = None
) -> list:
    """
    Transcribe multiple files sequentially.

    Note: mlx-whisper uses Apple MLX (Metal GPU) which doesn't support
    parallel access from multiple threads. Files are processed one by one.

    Args:
        input_files: List of file paths
        output_dir: Output directory
        output_format: 'txt' or 'srt'
        model: Whisper model to use
        language: Language code (optional)

    Returns:
        List of result dicts
    """
    results = []

    print(f"\n{'='*60}")
    print(f"Batch Processing: {len(input_files)} file(s)")
    print(f"Output format: {output_format.upper()}")
    print(f"Output directory: {output_dir}")
    print(f"Processing: Sequential (MLX GPU constraint)")
    print(f"{'='*60}\n")

    total_start = time.time()

    for i, f in enumerate(input_files, 1):
        print(f"[{i}/{len(input_files)}] ", end="")
        result = transcribe_single_file(f, output_dir, output_format, model, language)
        results.append(result)

    total_elapsed = time.time() - total_start

    # Summary
    successful = sum(1 for r in results if r["success"])
    failed = len(results) - successful

    print(f"\n{'='*60}")
    print(f"Batch Complete!")
    print(f"Total time: {total_elapsed:.1f}s")
    print(f"Successful: {successful}/{len(results)}")
    if failed > 0:
        print(f"Failed: {failed}")
    print(f"{'='*60}\n")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Generate subtitles (TXT/SRT) from audio/video files using Whisper"
    )
    parser.add_argument(
        "input_files",
        nargs="+",
        help="Path(s) to audio or video file(s)"
    )
    parser.add_argument(
        "-o", "--output",
        help="Output directory (default: /Users/joon/Downloads)",
        default="/Users/joon/Downloads"
    )
    parser.add_argument(
        "-f", "--format",
        choices=["txt", "srt"],
        default="txt",
        help="Output format: txt (default) or srt"
    )
    parser.add_argument(
        "-n", "--name",
        help="Custom output filename (without extension). Only works with single file.",
        default=None
    )
    parser.add_argument(
        "-m", "--model",
        help="Whisper model (default: mlx-community/whisper-medium-mlx)",
        default="mlx-community/whisper-medium-mlx"
    )
    parser.add_argument(
        "-l", "--language",
        help="Language code (e.g., en, ko, ja). Auto-detect if not specified",
        default=None
    )
    args = parser.parse_args()

    # Single file with custom name
    if len(args.input_files) == 1:
        result = transcribe_single_file(
            args.input_files[0],
            args.output,
            args.format,
            args.model,
            args.language,
            args.name
        )
        if result["success"]:
            print(f"\nOutput: {result['output']}")
        else:
            print(f"\nError: {result['error']}")
            sys.exit(1)
    else:
        # Batch processing (custom name ignored)
        if args.name:
            print("Warning: --name option ignored for batch processing")

        results = transcribe_batch(
            args.input_files,
            args.output,
            args.format,
            args.model,
            args.language
        )

        # Print summary of outputs
        print("Output files:")
        for r in results:
            if r["success"]:
                print(f"  - {r['output']}")
            else:
                print(f"  - [FAILED] {r['input']}: {r['error']}")


if __name__ == "__main__":
    main()
