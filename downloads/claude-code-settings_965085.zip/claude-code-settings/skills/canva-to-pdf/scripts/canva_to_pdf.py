#!/usr/bin/env python3
"""
Canva HTML/URL 슬라이드를 고해상도 PDF로 변환하는 스크립트

사용법:
    python canva_to_pdf.py <input> <output_pdf> [--pages N]

인자:
    input       : Canva HTML 파일 경로 또는 Canva 공유 URL
    output_pdf  : 출력 PDF 파일 경로
    --pages N   : 총 페이지 수 (기본값: 자동 감지)

예시:
    python canva_to_pdf.py ./presentation.html ./output.pdf
    python canva_to_pdf.py ./presentation.html ./output.pdf --pages 50
    python canva_to_pdf.py "https://www.canva.com/design/xxx/view" ./output.pdf --pages 30
"""

import asyncio
import argparse
import os
import sys
import tempfile
import re
from pathlib import Path

try:
    from playwright.async_api import async_playwright
    from PIL import Image
except ImportError as e:
    print(f"필수 패키지가 설치되지 않았습니다: {e}")
    print("다음 명령어로 설치해주세요:")
    print("  pip install playwright pillow")
    print("  playwright install chromium")
    sys.exit(1)


async def hide_canva_ui(page):
    """Canva 뷰어의 UI 요소들을 숨김"""
    await page.evaluate('''() => {
        // 헤더/툴바 숨기기
        const headers = document.querySelectorAll('header, [class*="header"], [class*="Header"], [class*="toolbar"], [class*="Toolbar"]');
        headers.forEach(el => el.style.display = 'none');

        // 푸터/네비게이션 숨기기
        const footers = document.querySelectorAll('footer, [class*="footer"], [class*="Footer"], [class*="controls"], [class*="Controls"], [class*="navigation"], [class*="Navigation"]');
        footers.forEach(el => el.style.display = 'none');

        // 위치 기반으로 상단/하단 UI 숨기기
        const allElements = document.querySelectorAll('*');
        allElements.forEach(el => {
            const rect = el.getBoundingClientRect();
            // 상단 바 영역 (y < 50, 높이 < 60, 너비 > 500)
            if (rect.top < 50 && rect.height < 60 && rect.width > 500) {
                el.style.display = 'none';
            }
            // 하단 바 영역 (y > 1030, 높이 < 60, 너비 > 100)
            if (rect.top > 1030 && rect.height < 60 && rect.width > 100) {
                el.style.display = 'none';
            }
        });
    }''')


async def wait_for_images_loaded(page, timeout_ms=10000):
    """
    페이지의 모든 이미지가 실제로 로드될 때까지 대기
    naturalWidth/naturalHeight를 확인하여 실제 로딩 완료 여부 판단
    """
    result = await page.evaluate(f'''() => {{
        return new Promise((resolve) => {{
            const checkImages = () => {{
                const images = document.querySelectorAll('img');
                if (images.length === 0) {{
                    return {{ loaded: 0, total: 0, allLoaded: true }};
                }}

                let loaded = 0;
                let total = images.length;

                images.forEach(img => {{
                    // naturalWidth > 0 이면 실제로 이미지가 로드된 것
                    if (img.complete && img.naturalWidth > 0) {{
                        loaded++;
                    }}
                }});

                return {{ loaded, total, allLoaded: loaded >= total }};
            }};

            // 초기 체크
            let result = checkImages();
            if (result.allLoaded) {{
                resolve(result);
                return;
            }}

            // 폴링으로 이미지 로딩 대기
            let elapsed = 0;
            const interval = 200;
            const maxWait = {timeout_ms};

            const poll = setInterval(() => {{
                elapsed += interval;
                result = checkImages();

                if (result.allLoaded || elapsed >= maxWait) {{
                    clearInterval(poll);
                    resolve(result);
                }}
            }}, interval);
        }});
    }}''')
    return result


async def get_visible_image_count(page):
    """현재 화면에 보이는 로드된 이미지 개수 확인"""
    return await page.evaluate('''() => {
        const images = document.querySelectorAll('img');
        let count = 0;
        images.forEach(img => {
            const rect = img.getBoundingClientRect();
            // 화면에 보이고 실제로 로드된 이미지
            if (rect.width > 50 && rect.height > 50 &&
                img.complete && img.naturalWidth > 0) {
                count++;
            }
        });
        return count;
    }''')


async def detect_page_count(page):
    """Canva 프레젠테이션의 총 페이지 수 자동 감지"""
    # 방법 1: 페이지 인디케이터에서 추출 (예: "1 / 159")
    page_info = await page.evaluate('''() => {
        const indicators = document.querySelectorAll('*');
        for (const el of indicators) {
            const text = el.textContent || '';
            const match = text.match(/\\d+\\s*\\/\\s*(\\d+)/);
            if (match) {
                return parseInt(match[1]);
            }
        }
        return null;
    }''')

    if page_info:
        return page_info

    # 방법 2: HTML 내 thumbnail URL 개수로 추정
    content = await page.content()
    thumbnails = re.findall(r'thumbnail/(\d{4})\.png', content)
    if thumbnails:
        return max(int(t) for t in thumbnails)

    return None


async def capture_single_slide(page, output_path, slide_num, max_retries=3):
    """
    단일 슬라이드 캡처 (재시도 로직 포함)

    Returns:
        bool: 캡처 성공 여부
    """
    for attempt in range(max_retries):
        # 이미지 로딩 대기 (최대 10초)
        load_result = await wait_for_images_loaded(page, timeout_ms=10000)

        # 추가 안정화 대기
        await asyncio.sleep(0.5)

        # UI 숨기기
        await hide_canva_ui(page)

        # 현재 보이는 이미지 개수 확인
        visible_images = await get_visible_image_count(page)

        # 스크린샷 캡처
        await page.screenshot(path=output_path, full_page=False)

        # 캡처된 이미지 크기 확인 (너무 작으면 실패로 간주)
        try:
            img = Image.open(output_path)
            width, height = img.size
            img.close()

            # 정상적인 4K 해상도인지 확인
            if width >= 3840 and height >= 2160:
                if attempt > 0:
                    print(f"(재시도 {attempt+1}회 성공)", end=" ")
                return True
        except Exception:
            pass

        if attempt < max_retries - 1:
            print(f"(재시도 중...)", end=" ", flush=True)
            await asyncio.sleep(2)  # 재시도 전 대기

    return False


async def capture_slides(input_path, output_dir, total_pages=None, progress_callback=None):
    """
    Canva 슬라이드를 캡처하여 이미지로 저장

    Args:
        input_path: HTML 파일 경로 또는 Canva URL
        output_dir: 이미지 저장 디렉토리
        total_pages: 총 페이지 수 (None이면 자동 감지)
        progress_callback: 진행 상황 콜백 함수 (current, total)

    Returns:
        캡처된 이미지 파일 경로 리스트
    """
    os.makedirs(output_dir, exist_ok=True)
    captured_images = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            device_scale_factor=2  # 4K 해상도 (3840x2160)
        )
        page = await context.new_page()

        # 입력이 URL인지 파일 경로인지 확인
        if input_path.startswith('http://') or input_path.startswith('https://'):
            url = input_path
        else:
            # 로컬 파일
            file_path = os.path.abspath(input_path)
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"파일을 찾을 수 없습니다: {file_path}")
            url = f"file://{file_path}"

        print(f"로딩 중: {url}")

        # URL의 경우 domcontentloaded, 로컬 파일은 networkidle
        if input_path.startswith('http://') or input_path.startswith('https://'):
            await page.goto(url, wait_until='domcontentloaded', timeout=60000)
        else:
            await page.goto(url, wait_until='networkidle', timeout=120000)

        # 초기 로딩 대기 (충분히 길게)
        print("초기 로딩 대기 중...")
        await asyncio.sleep(5)
        await wait_for_images_loaded(page, timeout_ms=10000)

        # 페이지 수 감지
        if total_pages is None:
            print("페이지 수 자동 감지 중...")
            total_pages = await detect_page_count(page)
            if total_pages:
                print(f"감지된 페이지 수: {total_pages}")
            else:
                print("페이지 수를 감지할 수 없습니다. --pages 옵션을 사용해주세요.")
                await browser.close()
                return []

        # 초기 UI 숨기기
        print("UI 요소 숨기는 중...")
        await hide_canva_ui(page)
        await asyncio.sleep(0.5)

        # 슬라이드 캡처
        for i in range(1, total_pages + 1):
            if progress_callback:
                progress_callback(i, total_pages)
            else:
                print(f"캡처 중: {i}/{total_pages}...", end=" ", flush=True)

            try:
                output_path = os.path.join(output_dir, f"slide_{i:03d}.png")

                # 슬라이드 캡처 (재시도 로직 포함)
                success = await capture_single_slide(page, output_path, i)

                if success:
                    captured_images.append(output_path)
                    if progress_callback is None:
                        print("OK")
                else:
                    if progress_callback is None:
                        print("WARN: 이미지 로딩 불완전")
                    captured_images.append(output_path)  # 그래도 저장

                # 다음 슬라이드로 이동
                if i < total_pages:
                    await page.keyboard.press('ArrowRight')

                    # 슬라이드 전환 후 충분한 대기 시간
                    # 후반부 슬라이드일수록 더 긴 대기 시간
                    base_wait = 1.0
                    if i > 50:
                        base_wait = 1.5
                    if i > 100:
                        base_wait = 2.0

                    await asyncio.sleep(base_wait)

                    # 이미지 로딩 대기
                    await wait_for_images_loaded(page, timeout_ms=8000)

            except Exception as e:
                print(f"ERROR: {e}")

        await browser.close()

    return captured_images


def create_pdf_from_images(image_paths, output_pdf, resolution=300.0):
    """
    이미지 파일들을 PDF로 병합

    Args:
        image_paths: 이미지 파일 경로 리스트
        output_pdf: 출력 PDF 파일 경로
        resolution: PDF 해상도 (DPI)

    Returns:
        생성된 PDF 파일 경로
    """
    if not image_paths:
        print("변환할 이미지가 없습니다!")
        return None

    print(f"\n{len(image_paths)}개의 이미지를 PDF로 변환 중...")

    images = []
    for img_path in sorted(image_paths):
        img = Image.open(img_path)
        if img.mode == 'RGBA':
            img = img.convert('RGB')
        images.append(img)

    # PDF 저장
    images[0].save(
        output_pdf,
        save_all=True,
        append_images=images[1:],
        resolution=resolution
    )

    file_size = os.path.getsize(output_pdf) / (1024 * 1024)
    print(f"PDF 생성 완료: {output_pdf} ({file_size:.1f} MB)")

    return output_pdf


async def convert_canva_to_pdf(input_path, output_pdf, total_pages=None, keep_images=False):
    """
    Canva 슬라이드를 PDF로 변환하는 메인 함수

    Args:
        input_path: Canva HTML 파일 경로 또는 URL
        output_pdf: 출력 PDF 파일 경로
        total_pages: 총 페이지 수 (None이면 자동 감지)
        keep_images: True면 임시 이미지 파일 보존

    Returns:
        생성된 PDF 파일 경로
    """
    print("=" * 60)
    print("Canva to PDF Converter")
    print("=" * 60)

    # 임시 디렉토리 생성
    if keep_images:
        output_dir = os.path.splitext(output_pdf)[0] + "_slides"
        os.makedirs(output_dir, exist_ok=True)
    else:
        temp_dir = tempfile.mkdtemp(prefix="canva_slides_")
        output_dir = temp_dir

    try:
        # 슬라이드 캡처
        image_paths = await capture_slides(input_path, output_dir, total_pages)

        if not image_paths:
            print("캡처된 슬라이드가 없습니다.")
            return None

        # PDF 생성
        pdf_path = create_pdf_from_images(image_paths, output_pdf)

        print("\n" + "=" * 60)
        print("완료!")
        print(f"PDF: {pdf_path}")
        print("=" * 60)

        return pdf_path

    finally:
        # 임시 파일 정리
        if not keep_images and 'temp_dir' in locals():
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)


def main():
    parser = argparse.ArgumentParser(
        description='Canva 슬라이드를 고해상도 PDF로 변환',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
예시:
    %(prog)s ./presentation.html ./output.pdf
    %(prog)s ./presentation.html ./output.pdf --pages 50
    %(prog)s "https://www.canva.com/design/xxx/view" ./output.pdf --pages 30
    %(prog)s ./presentation.html ./output.pdf --keep-images
        '''
    )
    parser.add_argument('input', help='Canva HTML 파일 경로 또는 공유 URL')
    parser.add_argument('output', help='출력 PDF 파일 경로')
    parser.add_argument('--pages', type=int, default=None,
                        help='총 페이지 수 (기본값: 자동 감지)')
    parser.add_argument('--keep-images', action='store_true',
                        help='캡처된 이미지 파일 보존')

    args = parser.parse_args()

    # 비동기 실행
    asyncio.run(convert_canva_to_pdf(
        args.input,
        args.output,
        args.pages,
        args.keep_images
    ))


if __name__ == "__main__":
    main()
