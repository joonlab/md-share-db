---
name: canva-to-pdf
description: Convert Canva presentation slides (HTML files or shared URLs) to high-resolution PDF documents. This skill should be used when the user provides a Canva HTML file or Canva share URL and requests to export, convert, or save it as a PDF. Common triggers include "Canva를 PDF로 변환해줘", "이 Canva 슬라이드를 PDF로 만들어줘", "convert this Canva to PDF", or similar requests involving Canva presentations.
---

# Canva to PDF Converter

Convert Canva presentation slides to high-resolution (4K) PDF documents with clean output (no Canva UI elements).

## Overview

This skill captures each slide from a Canva presentation using browser automation (Playwright), removes Canva's UI elements via JavaScript injection, and combines the captured images into a single PDF document.

**Supported inputs:**
- Local Canva HTML files (exported/saved from Canva)
- Canva share URLs (https://www.canva.com/design/xxx/view)

**Output:**
- High-resolution PDF (3840x2160 per page, 4K quality)
- Clean slides without Canva UI (logo, navigation buttons, share button, etc.)

## Why Browser Capture (Not URL Extraction)

Initial attempts to extract image URLs directly from HTML failed because:

1. **Thumbnail-only URLs**: Canva HTML contains only low-resolution thumbnail URLs (596x335) in `document-export.canva.com/.../thumbnail/` paths
2. **No high-resolution alternatives**: The HTML does not include high-resolution image URLs
3. **Dynamic rendering**: Canva renders slides dynamically in the browser, so browser capture is the only way to get full-quality output

The browser capture approach with `device_scale_factor=2` produces 4K resolution (3840x2160) images.

## Prerequisites

Before running the conversion script, ensure the following packages are installed:

```bash
pip install playwright pillow
playwright install chromium
```

## Usage

### Basic Conversion

To convert a Canva HTML file to PDF:

```bash
python scripts/canva_to_pdf.py <input> <output.pdf> [--pages N]
```

**Arguments:**
- `input`: Canva HTML file path or Canva share URL
- `output.pdf`: Output PDF file path
- `--pages N`: Total number of pages (required for URLs, optional for HTML files)
- `--keep-images`: Keep captured slide images after PDF creation

### Examples

**Convert local HTML file:**
```bash
python scripts/canva_to_pdf.py ./presentation.html ./output.pdf
```

**Convert with known page count (recommended):**
```bash
python scripts/canva_to_pdf.py ./presentation.html ./output.pdf --pages 50
```

**Convert from Canva URL:**
```bash
python scripts/canva_to_pdf.py "https://www.canva.com/design/xxx/view" ./output.pdf --pages 30
```

**Keep slide images for inspection:**
```bash
python scripts/canva_to_pdf.py ./presentation.html ./output.pdf --keep-images
```

## Workflow

When the user requests a Canva to PDF conversion:

1. **Identify the input**: Determine if the user provided an HTML file path or a Canva URL
2. **Ask for page count**: Always ask the user for the total number of pages - auto-detection is unreliable
3. **Run the conversion script**: Execute `scripts/canva_to_pdf.py` with appropriate arguments
4. **Verify output**: Check a few slides from the output to ensure quality
5. **Report results**: Inform the user of the output PDF location and file size

## Technical Details

### UI Removal

The script removes Canva UI elements using two techniques:

1. **CSS selector-based hiding**: Hides elements matching `header`, `footer`, `[class*="toolbar"]`, `[class*="navigation"]`, etc.

2. **Position-based hiding**: Hides elements in the top 50px (header area) and bottom 50px (navigation area) of the viewport

UI hiding is applied after each slide transition because Canva may re-render UI elements.

### Robust Image Loading

The script uses a robust image loading strategy to ensure all images are captured:

1. **naturalWidth check**: Verifies images are actually loaded by checking `img.naturalWidth > 0` (not just `img.complete`)
2. **Polling mechanism**: Checks image loading status every 200ms with 10-second timeout
3. **Retry logic**: Each slide capture has up to 3 retry attempts if loading appears incomplete
4. **Adaptive wait times**: Later slides get longer wait times to account for accumulated memory/network load:
   - Slides 1-50: 1.0 second base wait
   - Slides 51-100: 1.5 seconds base wait
   - Slides 101+: 2.0 seconds base wait

## Known Limitations and Issues

### 1. Missing Images in Some Slides (External URL Expiration)
**Symptom**: Slides show text and layout but images appear as gray placeholders
**Cause**: Canva HTML references external image URLs hosted on Canva's CDN. These URLs have expiration times and may become inaccessible hours or days after the HTML was exported.
**Important**: This is NOT a script bug. The same HTML file may work perfectly when first exported but show missing images days later.
**Solution**:
- Convert the HTML to PDF as soon as possible after exporting from Canva
- If images are critical, re-export the HTML from Canva to get fresh image URLs
- Keep successful captures (`--keep-images`) as backup

### 2. Page Count Auto-Detection May Fail
**Symptom**: Script asks for `--pages` option
**Cause**: Page count detection relies on finding "X / Y" text pattern or counting thumbnail URLs in HTML
**Solution**: Always provide `--pages N` option with the known page count

### 3. Processing Time for Large Presentations
**Symptom**: 100+ page presentations take 10+ minutes
**Cause**: Robust image loading with adaptive wait times increases per-slide processing time
**Expected time**:
- 50 pages: ~3-4 minutes
- 100 pages: ~8-10 minutes
- 159 pages: ~15-20 minutes

### 4. URL Conversion May Timeout
**Symptom**: Script hangs or times out when using Canva URL
**Cause**: `networkidle` wait can hang on dynamic Canva pages
**Solution**: The script uses `domcontentloaded` for URLs with extended sleep time

## Output Location

By default, save the PDF to `/Users/joon/Downloads/` unless the user specifies otherwise.

## Troubleshooting

**Playwright not installed:**
```bash
pip install playwright
playwright install chromium
```

**Permission denied errors:**
```bash
chmod +x scripts/canva_to_pdf.py
```

**Images missing in later slides but present in earlier slides:**
- This was a known issue with insufficient wait times
- The current script uses adaptive wait times that increase for later slides
- If still occurring, the external image URLs may have expired (see Known Limitations #1)

**All images missing:**
- The Canva HTML export's external image URLs have likely expired
- Re-export the HTML from Canva to get fresh URLs
