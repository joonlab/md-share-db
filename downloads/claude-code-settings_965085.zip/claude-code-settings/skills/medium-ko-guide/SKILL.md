---
name: medium-ko-guide
description: >
  Medium 아티클 HTML을 한국어 마크다운 가이드로 변환하는 3단계 파이프라인.
  사용자가 Medium URL 또는 HTML을 제공하면 자동으로 변환 수행.
user-invocable: true
context: fork
allowed-tools:
  - WebFetch
  - Read
  - Write
  - Task
  - Bash
---

# Medium Korean Guide Converter

Medium 아티클을 한국어 마크다운으로 변환하는 skill입니다.

---

## 실행 방법

사용자가 다음 중 하나를 제공하면 변환을 시작합니다:
1. Medium URL
2. 저장된 HTML 파일 경로
3. 복사한 HTML 내용

---

## 3단계 파이프라인

### Step 1: HTML 추출 (html-extractor agent)

```
Input: Raw HTML
Output: Structured JSON
Agent: html-extractor (model: haiku)
```

Task 도구로 `html-extractor` 에이전트를 호출:
- HTML에서 본문 콘텐츠 구조 추출
- 이미지 URL 및 캡션 보존
- 코드 블록, 리스트, 인용문 구조화

### Step 2: 한국어 번역 (ko-translator agent)

```
Input: Structured JSON (English)
Output: Translated JSON (Korean)
Agent: ko-translator (model: sonnet)
```

Task 도구로 `ko-translator` 에이전트를 호출:
- 자연스러운 한국어로 번역
- 기술 용어 첫 등장 시 병기
- 코드, URL, 이미지는 원본 유지

### Step 3: 마크다운 생성 (md-formatter agent)

```
Input: Translated JSON
Output: Final Markdown file
Agent: md-formatter (model: haiku)
```

Task 도구로 `md-formatter` 에이전트를 호출:
- YAML frontmatter 생성
- 깔끔한 마크다운 포맷팅
- 이미지 임베딩 (`![caption](url)`)

---

## JSON 스키마 정의

### 1단계 출력 (html-extractor → ko-translator)

```json
{
  "metadata": {
    "title": "원본 영어 제목",
    "author": "저자명",
    "date": "발행일 (원본 형식)",
    "read_time": "읽기 시간"
  },
  "sections": [
    {
      "type": "heading",
      "level": 1,
      "content": "헤딩 텍스트"
    },
    {
      "type": "paragraph",
      "content": "단락 텍스트"
    },
    {
      "type": "image",
      "url": "https://miro.medium.com/...",
      "caption": "이미지 캡션 (있는 경우)",
      "alt": "대체 텍스트 (있는 경우)"
    },
    {
      "type": "code",
      "language": "python",
      "content": "코드 내용"
    },
    {
      "type": "blockquote",
      "content": "인용문 내용"
    },
    {
      "type": "list",
      "ordered": false,
      "items": ["항목1", "항목2"]
    }
  ]
}
```

### 2단계 출력 (ko-translator → md-formatter)

```json
{
  "metadata": {
    "title": "원본 영어 제목",
    "title_ko": "한국어 번역 제목",
    "author": "저자명",
    "date": "YYYY-MM-DD",
    "source": "원본 Medium URL (있는 경우)"
  },
  "sections": [
    // 동일 구조, content가 한국어로 번역됨
    // image type은 url, caption, alt 모두 보존
  ],
  "glossary": [
    {"en": "latency", "ko": "지연 시간"},
    {"en": "throughput", "ko": "처리량"}
  ]
}
```

---

## 이미지 처리 규칙

### HTML 추출 시 (html-extractor)

**추출 대상:**
| HTML 패턴 | 추출 방법 |
|----------|----------|
| `<figure><img src="..."></figure>` | url: src 속성 |
| `<figcaption>텍스트</figcaption>` | caption: 텍스트 |
| `<img alt="...">` | alt: alt 속성 |
| `<picture><source>...<img>` | 최고 해상도 src 선택 |
| `data-src`, `srcset` 속성 | 원본 URL 추출 |

**Medium 이미지 URL 패턴:**
```
https://miro.medium.com/v2/resize:fit:1400/format:webp/1*xxxxx.png
https://miro.medium.com/max/1400/1*xxxxx.jpeg
```

**필수 보존:**
- 원본 CDN URL 그대로 유지 (리사이즈 파라미터 포함)
- caption이 없어도 빈 문자열로 필드 유지
- alt 텍스트가 있으면 반드시 포함

### 마크다운 변환 시 (md-formatter)

**기본 형식:**
```markdown
![이미지 캡션](https://miro.medium.com/v2/resize:fit:1400/...)
```

**캡션 우선순위:**
1. caption 필드가 있으면 사용
2. caption 없고 alt 있으면 alt 사용
3. 둘 다 없으면 빈 alt: `![](url)`

**이미지 배치:**
- 이미지 전후로 빈 줄 추가
- 연속 이미지는 각각 별도 줄에 배치
- 이미지 캡션이 길면 그대로 사용 (줄바꿈 없이)

---

## HTML 파싱 규칙

### 추출 대상

| HTML 요소 | 추출 방법 |
|----------|----------|
| `<h1>` ~ `<h4>` | type: "heading", level: 1~4 |
| `<p>` | type: "paragraph" |
| `<figure>` + `<img>` | type: "image", url: src 속성 |
| `<figcaption>` | image의 caption 필드 |
| `<pre>` + `<code>` | type: "code", language 감지 |
| `<code>` (inline) | 텍스트 내 `` ` `` 으로 감싸기 |
| `<blockquote>` | type: "blockquote" |
| `<ul>` / `<ol>` | type: "list", ordered: false/true |
| `<a href="...">` | 텍스트 내 링크 URL 보존 |
| `<strong>`, `<b>` | 텍스트 내 **볼드** 마킹 |
| `<em>`, `<i>` | 텍스트 내 *이탤릭* 마킹 |

### 제거 대상

- `<nav>`, `<header>`, `<footer>` - 네비게이션 영역
- `<script>`, `<style>`, `<noscript>` - 실행/스타일 코드
- 작성자 프로필 섹션 (아바타, 팔로우 버튼)
- 박수/댓글/공유 버튼 영역
- 추천 글, 관련 글 섹션
- 광고 및 프로모션 영역
- Medium 브랜딩 요소

### Medium 특수 클래스 처리

- `data-selectable-paragraph` → 본문 단락
- `pw-post-title` → 제목
- `pw-subtitle-paragraph` → 부제목
- `paragraph-image` → 이미지 블록

---

## 번역 규칙

### 문체 가이드

- **기본 문체**: 해요체 또는 합니다체 (일관성 유지)
- **기술 문서 톤**: 간결하고 명확하게
- **원문 논리 유지**: 문단 구조와 흐름 보존

### 용어 병기 규칙

**병기 대상 (첫 등장 시만):**

| 원문 | 번역 + 병기 |
|------|------------|
| latency | 지연 시간(latency) |
| throughput | 처리량(throughput) |
| context window | 컨텍스트 윈도우(context window) |
| token | 토큰(token) |
| prompt | 프롬프트(prompt) |
| fine-tuning | 파인튜닝(fine-tuning) |
| embedding | 임베딩(embedding) |
| vector | 벡터(vector) |

**병기 제외:**

- 정착된 외래어: 서버, 데이터베이스, 알고리즘, 프로그래밍
- 고유명사/브랜드: Python, JavaScript, React, Claude, GPT, NotebookLM
- 약어: API, SDK, CLI, JSON, YAML, HTML, CSS
- 코드 내 식별자: 함수명, 변수명, 클래스명

### 번역하지 않는 항목

- 코드 블록 내용 (주석만 선택적 번역)
- URL, 파일 경로
- 이미지 URL 및 캡션 내 고유명사
- 브랜드명, 제품명, 서비스명

---

## 마크다운 포맷팅 규칙

### YAML Frontmatter 구조

```yaml
---
title: "원본 영어 제목"
title_ko: "한국어 번역 제목"
author: 저자명
source: 원본 Medium URL
date: YYYY-MM-DD
tags:
  - 태그1
  - 태그2
---
```

### 헤딩 계층화

- H1: 문서 제목 (1개만)
- H2: 주요 섹션
- H3: 하위 섹션
- H4: 세부 항목
- 레벨 스킵 금지 (H2 → H4 불가)

### 요소별 변환

| JSON type | 마크다운 변환 |
|-----------|--------------|
| heading level 1 | `# 제목` |
| heading level 2 | `## 제목` |
| heading level 3 | `### 제목` |
| heading level 4 | `#### 제목` |
| paragraph | 일반 텍스트 (빈 줄로 구분) |
| image | `![캡션](URL)` |
| code | ` ```언어\n코드\n``` ` |
| blockquote | `> 인용 내용` |
| list (unordered) | `- 항목` |
| list (ordered) | `1. 항목` |

### 가독성 향상

- 섹션 간 구분선 (`---`) 적절히 사용
- 긴 섹션 후 빈 줄 추가
- 표는 가독성 있게 정렬
- 강조는 과도하지 않게 (문서당 10개 이내)

---

## 파이프라인 실행 예시

```
사용자: "이 Medium 글 한국어로 변환해줘: https://medium.com/..."

1. WebFetch로 HTML 가져오기
2. Task(html-extractor)로 JSON 추출
3. Task(ko-translator)로 한국어 번역
4. Task(md-formatter)로 마크다운 생성
5. Write로 ~/Downloads/에 .md 파일 저장
```

---

## 에러 처리

| 상황 | 처리 방법 |
|------|----------|
| HTML 파싱 실패 | 에러 메시지 JSON 반환 |
| 번역 불가 텍스트 | 원문 유지 |
| 언어 감지 실패 | 코드 블록 언어 태그 생략 |
| 이미지 URL 누락 | `[이미지]` 플레이스홀더 |
| 메타데이터 누락 | 빈 문자열 또는 "Unknown" |
