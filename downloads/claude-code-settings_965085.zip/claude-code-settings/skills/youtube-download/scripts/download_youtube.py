"""YouTube 영상 다운로드 스크립트"""
import os
import sys
import json
import yt_dlp


def download_video(url, output_dir="/Users/joon/Downloads"):
    """
    YouTube 영상을 다운로드하고 메타데이터를 반환합니다.

    Args:
        url (str): YouTube 영상 URL
        output_dir (str): 다운로드할 디렉토리

    Returns:
        dict: {
            'video_path': str,
            'title': str,
            'description': str,
            'duration': int,
            'video_id': str,
            'uploader': str,
            'upload_date': str,
            'view_count': int,
            'like_count': int,
            'channel': str,
            'thumbnail': str
        }
    """
    os.makedirs(output_dir, exist_ok=True)

    # 영상 다운로드 옵션
    video_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': os.path.join(output_dir, '%(title)s.%(ext)s'),
        'merge_output_format': 'mp4',
        'quiet': False,
        'no_warnings': False,
    }

    print(f"영상 다운로드 시작: {url}")
    with yt_dlp.YoutubeDL(video_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        video_path = ydl.prepare_filename(info)

        metadata = {
            'video_path': video_path,
            'title': info.get('title', 'Unknown'),
            'description': info.get('description', ''),
            'duration': info.get('duration', 0),
            'video_id': info.get('id', ''),
            'uploader': info.get('uploader', ''),
            'upload_date': info.get('upload_date', ''),
            'view_count': info.get('view_count', 0),
            'like_count': info.get('like_count', 0),
            'channel': info.get('channel', ''),
            'thumbnail': info.get('thumbnail', '')
        }

    print(f"✓ 영상 다운로드 완료: {metadata['title']}")
    print(f"✓ 저장 위치: {video_path}")

    return metadata


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python download_youtube.py <youtube_url> [output_dir]")
        sys.exit(1)

    url = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "/Users/joon/Downloads"

    result = download_video(url, output_dir)

    # JSON 형식으로 결과 출력
    print("\n" + "="*60)
    print("METADATA_JSON_START")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print("METADATA_JSON_END")
    print("="*60)
