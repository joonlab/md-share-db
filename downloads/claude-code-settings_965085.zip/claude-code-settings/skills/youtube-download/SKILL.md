---
name: youtube-download
description: Download YouTube videos with metadata extraction. Use this skill when users request to download YouTube videos, save videos locally, or need video metadata (title, description, duration, views, etc.). Supports any YouTube URL format.
---

# YouTube Video Downloader

## Overview

This skill enables Claude to download YouTube videos in the highest available quality and extract comprehensive metadata including title, description, duration, view count, uploader information, and more.

## When to Use This Skill

Use this skill when users request:
- "Download this YouTube video: [URL]"
- "Save this video locally"
- "Get me this YouTube video"
- "Download [video title] from YouTube"
- "I need to download a video from YouTube"

## Workflow

### Step 1: Download Video

Run the download script to fetch the YouTube video and metadata:

```bash
python scripts/download_youtube.py "<youtube_url>" [output_dir]
```

**Arguments:**
- `youtube_url` (required): Full YouTube URL (e.g., `https://www.youtube.com/watch?v=VIDEO_ID`)
- `output_dir` (optional): Directory to save the video. Defaults to `/Users/joon/Downloads`

**Output:** JSON containing:
- `video_path`: Downloaded video file path (MP4 format)
- `title`: Video title
- `description`: Video description
- `duration`: Video duration in seconds
- `video_id`: YouTube video ID
- `uploader`: Channel/uploader name
- `upload_date`: Upload date (YYYYMMDD format)
- `view_count`: Number of views
- `like_count`: Number of likes
- `channel`: Channel name
- `thumbnail`: Thumbnail URL

**Example:**
```bash
python scripts/download_youtube.py "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
```

**Download Quality:**
The script automatically downloads the best available quality by selecting:
1. Best video (MP4) + best audio (M4A) and merges them
2. Falls back to best single-file MP4 if merging is not available

### Step 2: Inform User

After successful download, provide the user with:
1. Confirmation that the video was downloaded
2. Video title and basic metadata (duration, views, etc.)
3. File path where the video was saved
4. File size (if relevant)

**Example response:**
```
✓ Video downloaded successfully!

Title: [Video Title]
Duration: [X minutes Y seconds]
Views: [view count]
Saved to: /Users/joon/Downloads/[filename].mp4
```

## Complete Example

```bash
# Download a YouTube video (saves to /Users/joon/Downloads by default)
python scripts/download_youtube.py "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

# The script will output:
# - Progress during download
# - Final metadata in JSON format
```

## Error Handling

Common issues and solutions:

1. **Invalid URL**: Verify the YouTube URL format is correct
2. **Video unavailable**: Some videos may be private, deleted, or region-restricted
3. **Network errors**: Check internet connection
4. **Disk space**: Ensure sufficient storage for the video file
5. **yt-dlp not installed**: Run `pip install yt-dlp` to install the required package

## Prerequisites

The following must be installed:
- Python 3.7+
- yt-dlp package

Install dependencies:
```bash
pip install -r requirements.txt
```

Or manually:
```bash
pip install yt-dlp
```

## Features

- **Best Quality**: Automatically selects and merges the highest quality video and audio streams
- **MP4 Format**: Ensures compatibility with all major video players
- **Rich Metadata**: Extracts comprehensive video information
- **Progress Display**: Shows download progress in real-time
- **Error Handling**: Graceful handling of common download issues

## Limitations

- Requires internet connection for downloading
- Download speed depends on network bandwidth
- Some videos may be restricted due to copyright or regional limitations
- Very long videos (>2 hours) may take significant time to download
