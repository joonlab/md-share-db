#!/usr/bin/env python3
"""
Rename a Claude session.
Usage: python3 rename-session.py <session_id> <new_name>
       python3 rename-session.py <session_id> --remove
       python3 rename-session.py <session_id> --stdin  (read name from stdin)
"""

import json
import sys
from pathlib import Path

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 rename-session.py <session_id> <new_name>")
        print("       python3 rename-session.py <session_id> --remove")
        print("       python3 rename-session.py <session_id> --stdin")
        sys.exit(1)

    session_id = sys.argv[1]

    # Handle stdin input
    if sys.argv[2] == '--stdin':
        new_name = sys.stdin.read().strip()
    else:
        new_name = sys.argv[2]

    names_file = Path.home() / '.claude' / 'session-names.json'

    # Load existing names
    if names_file.exists():
        with open(names_file, 'r', encoding='utf-8') as f:
            names = json.load(f)
    else:
        names = {}

    # Update or remove name
    if new_name == '--remove':
        if session_id in names:
            del names[session_id]
            print(f"Removed custom name for session: {session_id}")
        else:
            print(f"No custom name found for session: {session_id}")
    else:
        names[session_id] = new_name
        print(f"Renamed session {session_id} to: {new_name}")

    # Save
    with open(names_file, 'w', encoding='utf-8') as f:
        json.dump(names, f, indent=2, ensure_ascii=False)

    print("Done! Run 'python3 update-index.py' to update the index.")

if __name__ == '__main__':
    main()
