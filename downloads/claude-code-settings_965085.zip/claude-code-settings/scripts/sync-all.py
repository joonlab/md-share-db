#!/usr/bin/env python3
"""
Claude System Sync - 통합 동기화 스크립트
디렉토리 시스템 + 히스토리 인덱스를 한 번에 업데이트

Usage:
    python3 ~/.claude/sync-all.py              # 전체 동기화
    python3 ~/.claude/sync-all.py --dir-only   # 디렉토리만
    python3 ~/.claude/sync-all.py --hist-only  # 히스토리만
    python3 ~/.claude/sync-all.py --serve      # 동기화 후 서버 시작
    python3 ~/.claude/sync-all.py --json       # JSON 출력 (Claude 파싱용)
    python3 ~/.claude/sync-all.py --fix-orphans # 고아 세션 자동 마이그레이션
"""

import os
import json
import argparse
import subprocess
import unicodedata
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, Set, List, Any, Optional, Tuple

HOME = Path.home()
CLAUDE_DIR = HOME / ".claude"
STATE_FILE = HOME / "joon-directory-system.json"

# ============================================================
# PART 1: Directory System Sync
# ============================================================

SCAN_TARGETS = {
    "Desktop": 2,
    "Documents": 1,
    "Downloads": 1,
    "PKM": 2,
    "00. Inbox": 2,
}

IGNORE_PATTERNS = {
    "node_modules", ".git", ".DS_Store", "__pycache__", 
    ".Trash", "Library", "miniconda3", "venv", ".nvm", 
    ".npm", ".cache", ".venv", "env"
}


def should_ignore(name: str) -> bool:
    if name.startswith('.'):
        return True
    return name in IGNORE_PATTERNS


def scan_directory(path: Path, max_depth: int, current_depth: int = 0) -> Dict[str, Any]:
    result = {}
    if not path.exists() or not path.is_dir():
        return result
    try:
        for item in sorted(path.iterdir()):
            if should_ignore(item.name):
                continue
            if item.is_dir():
                if current_depth < max_depth:
                    children = scan_directory(item, max_depth, current_depth + 1)
                    result[item.name] = {"children": children} if children else {}
                else:
                    result[item.name] = {}
    except PermissionError:
        pass
    return result


def extract_existing_paths(directories: Dict) -> Set[str]:
    paths = set()
    for name, value in directories.items():
        paths.add(name)
        if isinstance(value, dict):
            children = value.get("children", {})
            if isinstance(children, dict):
                for child_name in children:
                    paths.add(f"{name}/{child_name}")
    return paths


def load_dir_state() -> Dict:
    if STATE_FILE.exists():
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"directories": {}, "history": [], "alerts": []}


def save_dir_state(state: Dict):
    with open(STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def scan_all_dirs() -> Dict[str, Dict]:
    result = {}
    for folder, depth in SCAN_TARGETS.items():
        path = HOME / folder
        if path.exists():
            children = scan_directory(path, depth)
            result[folder] = {"children": children}
    return result


def compare_dir_structures(old_dirs: Dict, new_scan: Dict) -> Dict[str, List[str]]:
    old_paths = extract_existing_paths(old_dirs)
    new_paths = set()
    
    for folder, data in new_scan.items():
        new_paths.add(folder)
        if "children" in data:
            for child in data["children"]:
                new_paths.add(f"{folder}/{child}")
                child_data = data["children"].get(child, {})
                if isinstance(child_data, dict) and "children" in child_data:
                    for grandchild in child_data["children"]:
                        new_paths.add(f"{folder}/{child}/{grandchild}")
    
    return {
        "added": sorted(list(new_paths - old_paths)),
        "removed": sorted(list(old_paths - new_paths))
    }


def sync_directories() -> Dict:
    state = load_dir_state()
    old_dirs = state.get("directories", {})
    new_scan = scan_all_dirs()
    changes = compare_dir_structures(old_dirs, new_scan)
    
    # Update state
    for folder, data in new_scan.items():
        if folder in old_dirs:
            old_purpose = old_dirs[folder].get("purpose", "")
            old_note = old_dirs[folder].get("note", "")
            new_scan[folder]["purpose"] = old_purpose
            if old_note:
                new_scan[folder]["note"] = old_note
    
    state["directories"] = new_scan
    state["lastUpdated"] = datetime.now().isoformat()
    
    if changes["added"] or changes["removed"]:
        history_entry = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "added_count": len(changes["added"]),
            "removed_count": len(changes["removed"]),
        }
        if changes["added"]:
            history_entry["added_sample"] = changes["added"][:5]
        if changes["removed"]:
            history_entry["removed_sample"] = changes["removed"][:5]
        state.setdefault("history", []).append(history_entry)
        state["history"] = state["history"][-50:]
    
    save_dir_state(state)
    
    return {
        "added_count": len(changes["added"]),
        "removed_count": len(changes["removed"]),
        "added_sample": changes["added"][:5],
        "removed_sample": changes["removed"][:5]
    }


# ============================================================
# PART 2: Orphan Session Detection & Migration
# ============================================================

def encode_path(path: str) -> str:
    """Encode path the same way Claude Code does."""
    # Claude Code uses NFD normalization on macOS
    normalized = unicodedata.normalize('NFD', path)
    return ''.join(c if c.isalnum() else '-' for c in normalized)


def find_similar_folders(original_path: str, search_base: Path = None) -> List[Tuple[Path, float]]:
    """Find folders with similar names, prioritizing similar path structure."""
    matches = []

    original = Path(original_path)
    target_name = original.name
    target_lower = target_name.lower()

    # Path components for similarity matching
    original_parts = original.parts

    # Folders to skip during search
    skip_folders = {
        'node_modules', '.git', 'venv', '.venv', 'env', '__pycache__',
        'site-packages', '.cache', '.npm', 'Library', '.Trash'
    }

    def should_skip(path: Path) -> bool:
        return any(part in skip_folders for part in path.parts)

    def calc_similarity(candidate: Path) -> float:
        """Calculate path similarity score (0-1)."""
        if should_skip(candidate):
            return 0

        score = 0.0
        candidate_parts = candidate.parts

        # Exact name match bonus
        if candidate.name == target_name:
            score += 0.3
        elif candidate.name.lower() == target_lower:
            score += 0.2

        # PRIORITY: Same parent directory structure
        # e.g., Desktop/test -> Desktop/tests/test (same base = Desktop)
        original_parent = original.parent
        candidate_parent = candidate.parent

        # Check if they share the same base directory (e.g., Desktop)
        if len(original_parts) >= 4 and len(candidate_parts) >= 4:
            # Compare base: /Users/joon/Desktop vs /Users/joon/Desktop
            original_base = original_parts[:4]  # /, Users, joon, Desktop
            candidate_base = candidate_parts[:4]
            if original_base == candidate_base:
                score += 0.5  # Strong bonus for same base directory

        # Path structure similarity (shared path components)
        common = set(original_parts) & set(candidate_parts)
        if len(original_parts) > 0:
            score += 0.2 * (len(common) / len(original_parts))

        # Depth similarity bonus (prefer similar depth)
        depth_diff = abs(len(candidate_parts) - len(original_parts))
        if depth_diff <= 2:
            score += 0.1 * (1 - depth_diff / 3)

        return score

    # Search in common locations with depth limit
    search_paths = [
        HOME / "Desktop",
        HOME / "Documents",
        HOME / "Downloads",
    ]

    for base in search_paths:
        if not base.exists():
            continue
        try:
            # Use os.walk with depth limit instead of rglob
            for root, dirs, files in os.walk(base):
                # Skip unwanted directories
                dirs[:] = [d for d in dirs if d not in skip_folders and not d.startswith('.')]

                root_path = Path(root)
                # Limit depth to 5
                if len(root_path.parts) - len(base.parts) > 5:
                    continue

                for d in dirs:
                    dir_path = root_path / d
                    if d.lower() == target_lower:
                        similarity = calc_similarity(dir_path)
                        if similarity > 0.3:  # Minimum threshold
                            matches.append((dir_path, similarity))
        except PermissionError:
            continue

    # Sort by similarity score descending
    matches.sort(key=lambda x: x[1], reverse=True)
    return matches[:5]


def find_orphan_sessions() -> List[Dict]:
    """Find sessions whose original cwd no longer exists."""
    projects_dir = CLAUDE_DIR / 'projects'
    orphans = []

    if not projects_dir.exists():
        return orphans

    for project_folder in projects_dir.iterdir():
        if not project_folder.is_dir() or project_folder.name.startswith('.'):
            continue

        cwd = None
        session_count = 0

        for jsonl_file in project_folder.glob("*.jsonl"):
            session_count += 1
            if cwd is None:
                cwd = extract_cwd_from_file(jsonl_file)

        if cwd and not Path(cwd).exists():
            # Find similar folders using full original path
            similar = find_similar_folders(cwd)

            orphans.append({
                "original_cwd": cwd,
                "project_folder": project_folder,
                "session_count": session_count,
                "similar_paths": [str(p) for p, _ in similar]
            })

    return orphans


def migrate_session(project_folder: Path, old_cwd: str, new_cwd: str) -> bool:
    """Migrate a session to a new path by updating cwd in files and moving folder."""
    try:
        new_encoded = encode_path(new_cwd)
        new_project_folder = CLAUDE_DIR / 'projects' / new_encoded

        # Update cwd in all jsonl files
        for jsonl_file in project_folder.glob("*.jsonl"):
            lines = []
            with open(jsonl_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if '"cwd":' in line and old_cwd in line:
                        line = line.replace(f'"cwd":"{old_cwd}"', f'"cwd":"{new_cwd}"')
                    lines.append(line)

            with open(jsonl_file, 'w', encoding='utf-8') as f:
                f.writelines(lines)

        # Move folder if name changed
        if new_project_folder != project_folder:
            if new_project_folder.exists():
                # Merge: move files into existing folder
                for f in project_folder.glob("*"):
                    dest = new_project_folder / f.name
                    if not dest.exists():
                        shutil.move(str(f), str(dest))
                # Remove old folder if empty
                try:
                    project_folder.rmdir()
                except:
                    pass
            else:
                shutil.move(str(project_folder), str(new_project_folder))

        return True
    except Exception as e:
        print(f"   ❌ 마이그레이션 실패: {e}")
        return False


# ============================================================
# PART 3: History Index Sync (simplified from update-index.py)
# ============================================================

def extract_cwd_from_file(jsonl_file: Path) -> str:
    try:
        with open(jsonl_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    if 'cwd' in data and data['cwd']:
                        return data['cwd']
                except:
                    continue
    except:
        pass
    return None


def sync_history_index() -> Dict:
    projects_dir = CLAUDE_DIR / 'projects'
    history_file = CLAUDE_DIR / 'history.jsonl'
    names_file = CLAUDE_DIR / 'session-names.json'
    
    if not projects_dir.exists():
        return {"error": "Projects directory not found"}
    
    session_names = {}
    if names_file.exists():
        try:
            with open(names_file, 'r', encoding='utf-8') as f:
                session_names = json.load(f)
        except:
            pass
    
    sessions = []
    history_entries = []
    
    # Scan sessions
    for project_folder in projects_dir.iterdir():
        if project_folder.is_dir() and not project_folder.name.startswith('.'):
            folder_name = project_folder.name
            folder_cwd = None
            
            for jsonl_file in project_folder.glob('*.jsonl'):
                cwd = extract_cwd_from_file(jsonl_file)
                if cwd:
                    folder_cwd = cwd
                    break
            
            if folder_cwd:
                project_name = unicodedata.normalize('NFC', folder_cwd).lstrip('/')
            else:
                if folder_name.startswith('-Users-joon-'):
                    rest = folder_name[len('-Users-joon-'):]
                    project_name = f"Users/joon/{rest}"
                else:
                    clean_folder = folder_name[1:] if folder_name.startswith('-') else folder_name
                    project_name = clean_folder.replace('-', '/')
            
            for jsonl_file in project_folder.glob('*.jsonl'):
                if jsonl_file.name.startswith('agent-'):
                    continue
                
                session_id = jsonl_file.stem
                file_size = jsonl_file.stat().st_size
                modified_time = jsonl_file.stat().st_mtime
                
                try:
                    with open(jsonl_file, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                    
                    first_user_msg = None
                    first_timestamp = None
                    last_timestamp = None
                    message_count = 0
                    all_user_texts = []
                    
                    for line in lines:
                        try:
                            data = json.loads(line.strip())
                            if data.get('type') == 'user' and data.get('message', {}).get('role') == 'user':
                                message_count += 1
                                content = data.get('message', {}).get('content', '')
                                
                                text_content = ''
                                if isinstance(content, str):
                                    text_content = content
                                elif isinstance(content, list):
                                    for c in content:
                                        if isinstance(c, dict) and c.get('type') == 'text':
                                            text_content = c.get('text', '')
                                            break
                                
                                if text_content and not text_content.startswith('Caveat:') and not text_content.startswith('<command-'):
                                    if not first_user_msg:
                                        first_user_msg = text_content[:200]
                                    all_user_texts.append(text_content[:500])
                            
                            if data.get('timestamp'):
                                ts = data.get('timestamp')
                                if not first_timestamp:
                                    first_timestamp = ts
                                last_timestamp = ts
                        except:
                            continue
                    
                    searchable_content = ' '.join(all_user_texts)[:5000]
                    
                    if message_count > 0:
                        session_data = {
                            'sessionId': session_id,
                            'project': project_name,
                            'projectFolder': folder_name,
                            'fileName': jsonl_file.name,
                            'fileSize': file_size,
                            'modifiedTime': modified_time,
                            'firstTimestamp': first_timestamp,
                            'lastTimestamp': last_timestamp,
                            'messageCount': message_count,
                            'preview': first_user_msg or 'No preview available',
                            'searchableContent': searchable_content,
                            'type': 'session'
                        }
                        if session_id in session_names:
                            session_data['customName'] = session_names[session_id]
                        sessions.append(session_data)
                except Exception as e:
                    pass
    
    # Load history.jsonl
    if history_file.exists():
        try:
            with open(history_file, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        history_entries.append(entry)
                    except:
                        continue
        except:
            pass
    
    # Find orphaned entries
    session_projects = set()
    for s in sessions:
        proj = s['project'].lower().replace('/', '-').replace('_', '-').replace(' ', '-')
        while '--' in proj:
            proj = proj.replace('--', '-')
        session_projects.add(proj.strip('-'))
    
    skip_commands = {'/status', '/login', '/logout', '/model', '/mcp', '/plugin',
                    '/context', '/compact', '/tasks', '/usage', '/help', '/clear',
                    '/resume', '/mco', '/cost', '/config', '/doctor', '/bug',
                    '/smart-handoff', '/init', '/version', '/memory'}
    
    unmatched_entries = []
    for entry in history_entries:
        project = entry.get('project', '').lstrip('/')
        timestamp = entry.get('timestamp', 0)
        display = entry.get('display', '')
        
        if display.startswith('/') and not display.startswith('/Users'):
            cmd = display.split()[0] if display else ''
            if cmd in skip_commands:
                continue
        
        norm_project = project.lower().replace('/', '-').replace('_', '-').replace(' ', '-')
        while '--' in norm_project:
            norm_project = norm_project.replace('--', '-')
        norm_project = norm_project.strip('-')
        
        matched = norm_project in session_projects
        if not matched:
            for sp in session_projects:
                if norm_project in sp or sp in norm_project:
                    matched = True
                    break
        
        if not matched:
            try:
                ts_iso = datetime.fromtimestamp(timestamp / 1000).isoformat()
            except:
                ts_iso = None
            
            unmatched_entries.append({
                'historyId': f"history-{timestamp}",
                'project': project if project else 'Unknown',
                'timestamp': timestamp,
                'timestampISO': ts_iso,
                'display': display,
                'preview': display[:200] if display else 'No preview',
                'pastedContents': entry.get('pastedContents', {}),
                'type': 'history'
            })
    
    # Combine and sort
    all_items = sessions + unmatched_entries
    
    def get_sort_key(item):
        if item['type'] == 'session':
            if item.get('lastTimestamp'):
                try:
                    dt = datetime.fromisoformat(item['lastTimestamp'].replace('Z', '+00:00'))
                    return dt.timestamp() * 1000
                except:
                    pass
            return item.get('modifiedTime', 0) * 1000
        else:
            return item.get('timestamp', 0)
    
    all_items.sort(key=get_sort_key, reverse=True)
    
    # Save index
    index_path = CLAUDE_DIR / 'sessions-index.json'
    with open(index_path, 'w', encoding='utf-8') as f:
        json.dump({
            'generatedAt': datetime.now().isoformat(),
            'totalSessions': len(sessions),
            'totalHistoryEntries': len(history_entries),
            'unmatchedHistoryEntries': len(unmatched_entries),
            'items': all_items
        }, f, ensure_ascii=False, indent=2)
    
    projects = set(s['project'] for s in sessions)
    
    return {
        "sessions": len(sessions),
        "orphaned": len(unmatched_entries),
        "projects": len(projects)
    }


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="Claude System Sync")
    parser.add_argument("--dir-only", action="store_true", help="디렉토리만 동기화")
    parser.add_argument("--hist-only", action="store_true", help="히스토리만 동기화")
    parser.add_argument("--serve", action="store_true", help="동기화 후 서버 시작")
    parser.add_argument("--port", type=int, default=8080, help="서버 포트 (기본: 8080)")
    parser.add_argument("--json", action="store_true", help="JSON 출력")
    parser.add_argument("--fix-orphans", action="store_true", help="고아 세션 자동 마이그레이션")
    args = parser.parse_args()

    result = {
        "timestamp": datetime.now().isoformat(),
        "directory": None,
        "history": None,
        "orphans": None
    }

    # Find orphan sessions first
    orphans = find_orphan_sessions()

    # Handle orphan migration
    if args.fix_orphans and orphans:
        print(f"🔧 고아 세션 마이그레이션 ({len(orphans)}개)")
        print("=" * 50)
        migrated = 0
        for orphan in orphans:
            old_cwd = orphan["original_cwd"]
            similar = orphan["similar_paths"]

            print(f"\n📁 {old_cwd}")
            print(f"   세션: {orphan['session_count']}개")

            if similar:
                # Auto-migrate to first match
                new_cwd = similar[0]
                print(f"   → {new_cwd}")
                if migrate_session(orphan["project_folder"], old_cwd, new_cwd):
                    print(f"   ✅ 마이그레이션 완료")
                    migrated += 1
            else:
                print(f"   ⚠️ 유사 경로 없음 - 수동 처리 필요")

        print(f"\n마이그레이션: {migrated}/{len(orphans)}개 완료")
        print("=" * 50)

        # Refresh orphans after migration
        orphans = find_orphan_sessions()

    result["orphans"] = {
        "count": len(orphans),
        "items": [
            {
                "original": o["original_cwd"],
                "sessions": o["session_count"],
                "suggestions": o["similar_paths"][:2]
            }
            for o in orphans
        ]
    }

    # Directory sync
    if not args.hist_only:
        result["directory"] = sync_directories()

    # History sync
    if not args.dir_only:
        result["history"] = sync_history_index()

    # Output
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"📊 Claude System Sync - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        print("=" * 50)

        if result["directory"]:
            d = result["directory"]
            if d["added_count"] == 0 and d["removed_count"] == 0:
                print("📁 디렉토리: 변경 없음")
            else:
                print(f"📁 디렉토리: +{d['added_count']} / -{d['removed_count']}")
                if d["added_sample"]:
                    for p in d["added_sample"][:3]:
                        print(f"   🆕 {p}")
                if d["removed_sample"]:
                    for p in d["removed_sample"][:3]:
                        print(f"   ❌ {p}")

        if result["history"]:
            h = result["history"]
            print(f"📜 히스토리: {h['sessions']}개 세션, {h['projects']}개 프로젝트")

        # Show orphans warning
        if result["orphans"] and result["orphans"]["count"] > 0:
            o = result["orphans"]
            print(f"⚠️ 고아 세션: {o['count']}개 (이동된 폴더)")
            for item in o["items"][:3]:
                print(f"   • {item['original']}")
                if item["suggestions"]:
                    print(f"     → 제안: {item['suggestions'][0]}")
            if o["count"] > 3:
                print(f"   ... 외 {o['count'] - 3}개")
            print(f"   💡 --fix-orphans 로 자동 수정")

        print("=" * 50)
        print("✅ 동기화 완료")

        if args.serve:
            print(f"\n🌐 서버 시작: http://localhost:{args.port}/history-viewer.html")
            print("   Ctrl+C로 종료")
            os.chdir(CLAUDE_DIR)
            subprocess.run(["python3", "-m", "http.server", str(args.port)])


if __name__ == "__main__":
    main()
