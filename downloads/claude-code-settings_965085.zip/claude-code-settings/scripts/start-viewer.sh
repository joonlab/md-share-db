#!/bin/bash

# Claude System Viewer - Server Start Script
# Usage: ./start-viewer.sh [port]

PORT=${1:-8080}

# 통합 동기화 후 서버 시작
python3 ~/.claude/sync-all.py --serve --port $PORT
