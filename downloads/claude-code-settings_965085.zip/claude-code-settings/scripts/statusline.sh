#!/bin/bash
# Claude Code Status Line - Colorful Version

input=$(cat)

# ============================================
# 🔔 Context 알림 설정
# 아래 숫자들을 변경하면 알림 트리거 퍼센트가 바뀝니다
# ============================================
ALERT_THRESHOLD_1=80   # 첫 번째 알림 (⚠️ 주의)
ALERT_THRESHOLD_2=90   # 두 번째 알림 (🚨 긴급)
# ============================================

# ANSI Colors
RESET='\033[0m'
BOLD='\033[1m'

# Bright colors
BRIGHT_GREEN='\033[92m'
BRIGHT_YELLOW='\033[93m'
BRIGHT_MAGENTA='\033[95m'
BRIGHT_CYAN='\033[96m'
RED='\033[31m'
WHITE='\033[37m'

# Extract values from JSON
MODEL=$(echo "$input" | jq -r '.model.display_name // "Unknown"')
PROJECT_DIR=$(echo "$input" | jq -r '.workspace.project_dir // "."')
PROJECT_NAME=$(basename "$PROJECT_DIR")
COST=$(echo "$input" | jq -r '.cost.total_cost_usd // 0')
DURATION_MS=$(echo "$input" | jq -r '.cost.total_duration_ms // 0')
LINES_ADDED=$(echo "$input" | jq -r '.cost.total_lines_added // 0')

# Context usage
# cache_read_input_tokens seems to represent the actual context being used
CONTEXT_SIZE=$(echo "$input" | jq -r '.context_window.context_window_size // 200000')
CACHE_READ=$(echo "$input" | jq -r '.context_window.current_usage.cache_read_input_tokens // 0')
CACHE_CREATE=$(echo "$input" | jq -r '.context_window.current_usage.cache_creation_input_tokens // 0')
INPUT_TOKENS=$(echo "$input" | jq -r '.context_window.current_usage.input_tokens // 0')

# Total context = cache_read (existing context) + cache_create (new cacheable) + input (new non-cacheable)
CURRENT=$((CACHE_READ + CACHE_CREATE + INPUT_TOKENS))
# Add autocompact buffer (22.5% = 45k of 200k) as baseline
AUTOCOMPACT_BUFFER=$((CONTEXT_SIZE * 225 / 1000))
PERCENT=$(((CURRENT + AUTOCOMPACT_BUFFER) * 100 / CONTEXT_SIZE))

# ============================================
# 🔔 Context 알림 체크
# ============================================
# 세션 식별용
TRANSCRIPT_PATH=$(echo "$input" | jq -r '.transcript_path // ""')
SESSION_ID=$(echo "$input" | jq -r '.session_id // ""')

if [ -n "$TRANSCRIPT_PATH" ]; then
    SESSION_HASH=$(echo "$TRANSCRIPT_PATH" | md5 | cut -c1-8)
    ALERT_FILE_1="/tmp/claude-context-alert-${SESSION_HASH}-${ALERT_THRESHOLD_1}"
    ALERT_FILE_2="/tmp/claude-context-alert-${SESSION_HASH}-${ALERT_THRESHOLD_2}"

    # 대화명 결정 (우선순위: customName > preview > 프로젝트명)
    SESSION_TITLE=""
    if [ -n "$SESSION_ID" ]; then
        # 1. customName 확인
        if [ -f ~/.claude/session-names.json ]; then
            SESSION_TITLE=$(jq -r --arg id "$SESSION_ID" '.[$id] // ""' ~/.claude/session-names.json 2>/dev/null)
        fi
        # 2. customName 없으면 preview 사용
        if [ -z "$SESSION_TITLE" ] && [ -f ~/.claude/session-previews.json ]; then
            SESSION_TITLE=$(jq -r --arg id "$SESSION_ID" '.[$id] // ""' ~/.claude/session-previews.json 2>/dev/null)
        fi
    fi
    # 3. 둘 다 없으면 프로젝트명
    [ -z "$SESSION_TITLE" ] && SESSION_TITLE="$PROJECT_NAME"

    # 첫 번째 임계값 (80%) 알림
    if [ "$PERCENT" -ge "$ALERT_THRESHOLD_1" ] && [ ! -f "$ALERT_FILE_1" ]; then
        touch "$ALERT_FILE_1"
        osascript -e "display notification \"Context ${PERCENT}% | /smart-handoff 준비\" with title \"⚠️ ${SESSION_TITLE}\" sound name \"Glass\"" &>/dev/null &
    fi

    # 두 번째 임계값 (90%) 알림
    if [ "$PERCENT" -ge "$ALERT_THRESHOLD_2" ] && [ ! -f "$ALERT_FILE_2" ]; then
        touch "$ALERT_FILE_2"
        osascript -e "display notification \"Context ${PERCENT}%! 지금 /smart-handoff 실행\" with title \"🚨 ${SESSION_TITLE}\" sound name \"Sosumi\"" &>/dev/null &
    fi

    # 임계값 미만으로 내려가면 알림 리셋
    [ "$PERCENT" -lt "$ALERT_THRESHOLD_1" ] && rm -f "$ALERT_FILE_1" 2>/dev/null
    [ "$PERCENT" -lt "$ALERT_THRESHOLD_2" ] && rm -f "$ALERT_FILE_2" 2>/dev/null
fi
# ============================================

# Duration in minutes
DURATION_MINS=$((DURATION_MS / 60000))

# Format cost to 3 decimal places
COST_FMT=$(printf "%.3f" "$COST")

# Create progress bar (10 segments)
BAR_WIDTH=10
FILLED=$((PERCENT * BAR_WIDTH / 100))
EMPTY=$((BAR_WIDTH - FILLED))

PROGRESS_BAR=""
for ((i=0; i<FILLED; i++)); do
    PROGRESS_BAR="${PROGRESS_BAR}█"
done
for ((i=0; i<EMPTY; i++)); do
    PROGRESS_BAR="${PROGRESS_BAR}░"
done

# Choose colors based on usage
if [ "$PERCENT" -lt 50 ]; then
    BAR_COLOR="${BRIGHT_GREEN}"
    PCT_COLOR="${BRIGHT_GREEN}"
elif [ "$PERCENT" -lt 80 ]; then
    BAR_COLOR="${BRIGHT_YELLOW}"
    PCT_COLOR="${BRIGHT_YELLOW}"
else
    BAR_COLOR="${RED}"
    PCT_COLOR="${RED}"
fi

# Output colorful status line
printf "${BOLD}${BRIGHT_MAGENTA}[${MODEL}]${RESET} "
printf "📁 ${BOLD}${BRIGHT_YELLOW}${PROJECT_NAME}${RESET} "
printf "${BAR_COLOR}${PROGRESS_BAR}${RESET} "
printf "${PCT_COLOR}${PERCENT}%%${RESET}"
printf " ${WHITE}|${RESET} "
printf "💰 ${BRIGHT_GREEN}\$${COST_FMT}${RESET} "
printf "⏱ ${BRIGHT_CYAN}${DURATION_MINS}m${RESET} "
printf "📝 ${BRIGHT_GREEN}+${LINES_ADDED}${RESET}"
printf "\n"
