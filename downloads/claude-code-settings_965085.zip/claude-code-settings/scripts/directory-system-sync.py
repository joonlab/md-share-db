#!/usr/bin/env python3
"""
Directory System Sync - 디렉토리 체계 상태 관리
Usage:
    python3 ~/.claude/directory-system-sync.py          # 변경사항 확인 + 업데이트
    python3 ~/.claude/directory-system-sync.py --check  # 변경사항만 확인 (업데이트 X)
    python3 ~/.claude/directory-system-sync.py --json   # JSON 형태로 출력
"""

import os
import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, Set, List, Any

# 설정
HOME = Path.home()
STATE_FILE = HOME / "joon-directory-system.json"

# 스캔 대상 폴더 (depth 1~2)
SCAN_TARGETS = {
    "Desktop": 2,
    "Documents": 1,
    "Downloads": 1,  # Downloads는 1단계만 (파일 너무 많음)
    "PKM": 2,
    "00. Inbox": 2,
}

# 무시 패턴
IGNORE_PATTERNS = {
    "node_modules", ".git", ".DS_Store", "__pycache__", 
    ".Trash", "Library", "miniconda3", "venv", ".nvm", 
    ".npm", ".cache", ".venv", "env"
}


def should_ignore(name: str) -> bool:
    """무시해야 할 폴더/파일인지 확인"""
    if name.startswith('.'):
        return True
    return name in IGNORE_PATTERNS


def scan_directory(path: Path, max_depth: int, current_depth: int = 0) -> Dict[str, Any]:
    """디렉토리 스캔하여 구조 반환"""
    result = {}
    
    if not path.exists() or not path.is_dir():
        return result
    
    try:
        for item in sorted(path.iterdir()):
            if should_ignore(item.name):
                continue
            
            if item.is_dir():
                if current_depth < max_depth:
                    children = scan_directory(item, max_depth, current_depth + 1)
                    result[item.name] = {"children": children} if children else {}
                else:
                    result[item.name] = {}
    except PermissionError:
        pass
    
    return result


def flatten_paths(structure: Dict, prefix: str = "") -> Set[str]:
    """구조를 flat한 경로 집합으로 변환"""
    paths = set()
    for name, value in structure.items():
        current_path = f"{prefix}/{name}" if prefix else name
        paths.add(current_path)
        if isinstance(value, dict) and "children" in value:
            paths.update(flatten_paths(value["children"], current_path))
        elif isinstance(value, dict) and value:
            paths.update(flatten_paths(value, current_path))
    return paths


def extract_existing_paths(directories: Dict) -> Set[str]:
    """기존 JSON에서 경로 추출"""
    paths = set()
    for name, value in directories.items():
        paths.add(name)
        if isinstance(value, dict):
            children = value.get("children", {})
            if isinstance(children, dict):
                for child_name in children:
                    paths.add(f"{name}/{child_name}")
    return paths


def load_state() -> Dict:
    """기존 상태 파일 로드"""
    if STATE_FILE.exists():
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"directories": {}, "history": [], "alerts": []}


def save_state(state: Dict):
    """상태 파일 저장"""
    with open(STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def scan_all() -> Dict[str, Dict]:
    """모든 대상 폴더 스캔"""
    result = {}
    for folder, depth in SCAN_TARGETS.items():
        path = HOME / folder
        if path.exists():
            children = scan_directory(path, depth)
            result[folder] = {
                "children": children
            }
    return result


def compare_structures(old_dirs: Dict, new_scan: Dict) -> Dict[str, List[str]]:
    """구조 비교하여 변경사항 반환"""
    old_paths = extract_existing_paths(old_dirs)
    new_paths = set()
    
    for folder, data in new_scan.items():
        new_paths.add(folder)
        if "children" in data:
            for child in data["children"]:
                new_paths.add(f"{folder}/{child}")
                # 2단계 children도 확인
                child_data = data["children"].get(child, {})
                if isinstance(child_data, dict) and "children" in child_data:
                    for grandchild in child_data["children"]:
                        new_paths.add(f"{folder}/{child}/{grandchild}")
    
    added = new_paths - old_paths
    removed = old_paths - new_paths
    
    return {
        "added": sorted(list(added)),
        "removed": sorted(list(removed))
    }


def generate_report(changes: Dict[str, List[str]], json_output: bool = False) -> str:
    """변경사항 리포트 생성"""
    if json_output:
        return json.dumps(changes, ensure_ascii=False, indent=2)
    
    lines = []
    lines.append(f"📊 Directory System Sync - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("=" * 50)
    
    if not changes["added"] and not changes["removed"]:
        lines.append("✅ 변경사항 없음")
    else:
        if changes["added"]:
            lines.append(f"\n🆕 새로 생긴 폴더 ({len(changes['added'])}개):")
            for path in changes["added"][:20]:  # 최대 20개만 표시
                lines.append(f"   + {path}")
            if len(changes["added"]) > 20:
                lines.append(f"   ... 외 {len(changes['added']) - 20}개")
        
        if changes["removed"]:
            lines.append(f"\n❌ 사라진 폴더 ({len(changes['removed'])}개):")
            for path in changes["removed"][:20]:
                lines.append(f"   - {path}")
            if len(changes["removed"]) > 20:
                lines.append(f"   ... 외 {len(changes['removed']) - 20}개")
    
    return "\n".join(lines)


def update_state(state: Dict, new_scan: Dict, changes: Dict[str, List[str]]) -> Dict:
    """상태 업데이트"""
    # 기존 purpose 보존하면서 구조 업데이트
    old_dirs = state.get("directories", {})
    
    for folder, data in new_scan.items():
        if folder in old_dirs:
            # 기존 purpose 유지
            old_purpose = old_dirs[folder].get("purpose", "")
            old_note = old_dirs[folder].get("note", "")
            new_scan[folder]["purpose"] = old_purpose
            if old_note:
                new_scan[folder]["note"] = old_note
    
    state["directories"] = new_scan
    state["lastUpdated"] = datetime.now().isoformat()
    
    # 변경사항이 있으면 history에 추가
    if changes["added"] or changes["removed"]:
        history_entry = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "added_count": len(changes["added"]),
            "removed_count": len(changes["removed"]),
        }
        if changes["added"]:
            history_entry["added_sample"] = changes["added"][:5]
        if changes["removed"]:
            history_entry["removed_sample"] = changes["removed"][:5]
        
        state.setdefault("history", []).append(history_entry)
        # history는 최근 50개만 유지
        state["history"] = state["history"][-50:]
    
    return state


def main():
    parser = argparse.ArgumentParser(description="Directory System Sync")
    parser.add_argument("--check", action="store_true", help="변경사항만 확인 (업데이트 X)")
    parser.add_argument("--json", action="store_true", help="JSON 형태로 출력")
    args = parser.parse_args()
    
    # 기존 상태 로드
    state = load_state()
    old_dirs = state.get("directories", {})
    
    # 현재 상태 스캔
    new_scan = scan_all()
    
    # 비교
    changes = compare_structures(old_dirs, new_scan)
    
    # 리포트 출력
    report = generate_report(changes, args.json)
    print(report)
    
    # 업데이트 (--check가 아닌 경우)
    if not args.check:
        state = update_state(state, new_scan, changes)
        save_state(state)
        if not args.json:
            print("\n✅ joon-directory-system.json 업데이트 완료")


if __name__ == "__main__":
    main()
