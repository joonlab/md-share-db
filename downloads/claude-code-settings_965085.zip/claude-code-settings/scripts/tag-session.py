#!/usr/bin/env python3
"""
Manage tags for a Claude session.
Usage:
    python3 tag-session.py <session_id> --add <tag>
    python3 tag-session.py <session_id> --add-stdin  (read tag or comma-separated tags from stdin)
    python3 tag-session.py <session_id> --remove <tag>
    python3 tag-session.py <session_id> --list
"""

import json
import sys
from pathlib import Path

def main():
    if len(sys.argv) < 3:
        print("Usage:")
        print("  python3 tag-session.py <session_id> --add <tag>")
        print("  python3 tag-session.py <session_id> --add-stdin  (supports comma-separated tags)")
        print("  python3 tag-session.py <session_id> --remove <tag>")
        print("  python3 tag-session.py <session_id> --list")
        sys.exit(1)

    session_id = sys.argv[1]
    action = sys.argv[2]

    tags_file = Path.home() / '.claude' / 'session-tags.json'

    # Load existing tags
    if tags_file.exists():
        with open(tags_file, 'r', encoding='utf-8') as f:
            all_tags = json.load(f)
    else:
        all_tags = {}

    # Get current session tags
    session_tags = all_tags.get(session_id, [])

    if action == '--add':
        if len(sys.argv) < 4:
            print("Error: Tag name required")
            sys.exit(1)
        tag = sys.argv[3]
        if tag not in session_tags:
            session_tags.append(tag)
            all_tags[session_id] = session_tags
            print(f"Added tag '{tag}' to session: {session_id}")
        else:
            print(f"Tag '{tag}' already exists for session: {session_id}")

    elif action == '--add-stdin':
        raw_input = sys.stdin.read().strip()
        if not raw_input:
            print("Error: Empty input")
            sys.exit(1)

        # Parse comma-separated tags
        tags_to_add = [t.strip() for t in raw_input.split(',') if t.strip()]

        added = []
        skipped = []
        for tag in tags_to_add:
            if tag not in session_tags:
                session_tags.append(tag)
                added.append(tag)
            else:
                skipped.append(tag)

        if added:
            all_tags[session_id] = session_tags
            print(f"Added {len(added)} tag(s): {', '.join(added)}")
        if skipped:
            print(f"Skipped {len(skipped)} existing tag(s): {', '.join(skipped)}")

    elif action == '--remove':
        if len(sys.argv) < 4:
            print("Error: Tag name required")
            sys.exit(1)
        tag = sys.argv[3]
        if tag == 'named':
            print("Error: 'named' tag is automatic and cannot be removed.")
            sys.exit(1)
        if tag in session_tags:
            session_tags.remove(tag)
            if session_tags:
                all_tags[session_id] = session_tags
            else:
                del all_tags[session_id]
            print(f"Removed tag '{tag}' from session: {session_id}")
        else:
            print(f"Tag '{tag}' not found for session: {session_id}")

    elif action == '--list':
        if session_tags:
            print(f"Tags for {session_id}:")
            for tag in session_tags:
                print(f"  - {tag}")
        else:
            print(f"No tags for session: {session_id}")
        return

    else:
        print(f"Unknown action: {action}")
        sys.exit(1)

    # Save
    with open(tags_file, 'w', encoding='utf-8') as f:
        json.dump(all_tags, f, indent=2, ensure_ascii=False)

    print("Done! Refresh the page to see changes.")

if __name__ == '__main__':
    main()
