#!/bin/bash
# Stop Hook: Claude 답변 완료 시 알림 + 소리

# stdin에서 JSON 읽기
INPUT=$(cat)

# 디버그: 입력 JSON 저장
echo "$INPUT" > /tmp/stop-hook-debug.json

# session_id 추출
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // ""')

# 디버그: session_id 로그
echo "SESSION_ID: $SESSION_ID" >> /tmp/stop-hook-debug.log

# 현재 작업 디렉토리 (프로젝트명)
PROJECT_DIR=$(pwd)
PROJECT_NAME=$(basename "$PROJECT_DIR")

# 대화명 결정 (우선순위: customName > preview > 프로젝트명)
SESSION_TITLE=""
if [ -n "$SESSION_ID" ]; then
    # 1. customName 확인
    if [ -f ~/.claude/session-names.json ]; then
        SESSION_TITLE=$(jq -r --arg id "$SESSION_ID" '.[$id] // ""' ~/.claude/session-names.json 2>/dev/null)
    fi
    # 2. customName 없으면 preview 사용
    if [ -z "$SESSION_TITLE" ] && [ -f ~/.claude/session-previews.json ]; then
        SESSION_TITLE=$(jq -r --arg id "$SESSION_ID" '.[$id] // ""' ~/.claude/session-previews.json 2>/dev/null)
    fi
fi
# 3. 둘 다 없으면 프로젝트명
[ -z "$SESSION_TITLE" ] && SESSION_TITLE="$PROJECT_NAME"

# 디버그: 최종 타이틀 로그
echo "SESSION_TITLE: $SESSION_TITLE" >> /tmp/stop-hook-debug.log

# 알림 표시 + 소리
osascript -e "display notification \"${PROJECT_DIR}\" with title \"✅ 답변 완료\" subtitle \"${SESSION_TITLE}\" sound name \"Glass\"" &>/dev/null &

exit 0
