#!/bin/bash
# PreCompact Hook: transcript를 깔끔한 Markdown으로 백업 + 알림 + 클립보드 복사

# 디버그 로그
DEBUG_LOG="/tmp/precompact-debug.log"
echo "=== $(date) ===" >> "$DEBUG_LOG"
echo "PWD: $(pwd)" >> "$DEBUG_LOG"

# stdin에서 JSON 읽기
INPUT=$(cat)
echo "INPUT: $INPUT" >> "$DEBUG_LOG"

# 현재 작업 디렉토리 인코딩 (Claude Code 방식)
PROJECT_DIR=$(pwd)
PROJECT_NAME=$(basename "$PROJECT_DIR")
ENCODED_PATH=$(echo "$PROJECT_DIR" | sed 's/[^a-zA-Z0-9]/-/g')

# 가장 최근 수정된 세션 파일 찾기
TRANSCRIPT=$(ls -t ~/.claude/projects/${ENCODED_PATH}/*.jsonl 2>/dev/null | grep -v "agent-" | head -1)

echo "ENCODED_PATH: $ENCODED_PATH" >> "$DEBUG_LOG"
echo "Looking for: ~/.claude/projects/${ENCODED_PATH}/*.jsonl" >> "$DEBUG_LOG"

if [ -z "$TRANSCRIPT" ]; then
    echo "Transcript not found - exiting" >> "$DEBUG_LOG"
    exit 0
fi
echo "TRANSCRIPT: $TRANSCRIPT" >> "$DEBUG_LOG"

# transcript 파일명에서 session_id 추출
SESSION_ID=$(basename "$TRANSCRIPT" .jsonl)

# 대화명 결정 (우선순위: customName > preview > 프로젝트명)
SESSION_TITLE=""
if [ -n "$SESSION_ID" ]; then
    # 1. customName 확인
    if [ -f ~/.claude/session-names.json ]; then
        SESSION_TITLE=$(jq -r --arg id "$SESSION_ID" '.[$id] // ""' ~/.claude/session-names.json 2>/dev/null)
    fi
    # 2. customName 없으면 preview 사용
    if [ -z "$SESSION_TITLE" ] && [ -f ~/.claude/session-previews.json ]; then
        SESSION_TITLE=$(jq -r --arg id "$SESSION_ID" '.[$id] // ""' ~/.claude/session-previews.json 2>/dev/null)
    fi
fi
# 3. 둘 다 없으면 프로젝트명
[ -z "$SESSION_TITLE" ] && SESSION_TITLE="$PROJECT_NAME"

# 백업 파일 경로
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR=~/.claude/backups
mkdir -p "$BACKUP_DIR"
BACKUP_FILE="${BACKUP_DIR}/session-${TIMESTAMP}.md"

# Python 스크립트로 마크다운 변환
python3 ~/.claude/hooks/convert-transcript.py "$TRANSCRIPT" "$BACKUP_FILE"

# 실행할 명령어
COMMAND="/smart-handoff \"${BACKUP_FILE}\""

# 클립보드에 복사
echo -n "$COMMAND" | pbcopy

# 알림 표시
echo "Sending notification..." >> "$DEBUG_LOG"
osascript -e "display notification \"클립보드에 복사됨 - 붙여넣기(⌘V) 후 실행\" with title \"📦 Auto Compact 예정\" subtitle \"${SESSION_TITLE}\" sound name \"Submarine\"" 2>> "$DEBUG_LOG" &

echo "Done" >> "$DEBUG_LOG"
exit 0
