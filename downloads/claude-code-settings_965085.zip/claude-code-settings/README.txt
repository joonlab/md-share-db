===========================================
   박준의 Claude Code 설정
===========================================

사용법:
  1. 이 폴더의 내용물을 ~/.claude/에 복사
  2. scripts/ 폴더의 내용물은 ~/.claude/ 루트로 이동
  3. Claude Code 재시작

자세한 사용법은 "박준의 Claude Code 설정 따라하기.md" 문서를 참고하세요.

폴더 구조:
  CLAUDE.md          - 글로벌 행동 규칙
  settings.json      - 훅, 상태바, 플러그인 설정
  skills/            - 31개 커스텀 스킬
  commands/          - 슬래시 커맨드
  agents/            - 서브에이전트 정의
  hooks/             - 이벤트 훅 스크립트
  scripts/           - 유틸리티 스크립트 (히스토리 뷰어 등)

주의사항:
  - macOS 전용 기능: osascript 알림, pbcopy 클립보드
  - 플러그인은 /plugin install 명령어로 별도 설치 필요
  - 기존 설정이 있으면 백업 후 병합 권장

