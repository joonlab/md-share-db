#!/bin/bash

# Required parameters:
# @raycast.schemaVersion 1
# @raycast.title 프롬프트 고도화 v2 (Grok)
# @raycast.mode fullOutput
#
# Optional parameters:
# @raycast.icon 🚀
# @raycast.packageName Prompt Enhancement
# @raycast.description 클립보드의 내용을 Grok AI로 고도화된 LLM 프롬프트로 변환합니다 (한국어 지원 개선)

# Set UTF-8 encoding
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# Load environment variables from shell profile
if [ -f "$HOME/.zshrc" ]; then
    source "$HOME/.zshrc" 2>/dev/null || true
fi

set -e

# Check if API key is set
if [ -z "$XAI_API_KEY" ]; then
    echo "❌ Error: XAI_API_KEY environment variable is not set"
    echo ""
    echo "Please set your xAI API key:"
    echo "  export XAI_API_KEY='your-api-key-here'"
    echo ""
    echo "Add this to your ~/.zshrc or ~/.bash_profile to make it permanent"
    exit 1
fi

# Check if jq is installed
if ! command -v jq &> /dev/null; then
    echo "❌ Error: jq is not installed"
    echo ""
    echo "Please install jq using Homebrew:"
    echo "  brew install jq"
    exit 1
fi

echo "📋 Reading clipboard content..."
CLIPBOARD_CONTENT=$(pbpaste)

if [ -z "$CLIPBOARD_CONTENT" ]; then
    echo "❌ Error: Clipboard is empty"
    exit 1
fi

echo "📝 Original content:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "$CLIPBOARD_CONTENT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "🚀 Enhancing prompt with Grok AI..."
echo ""

# Create JSON payload using jq for proper UTF-8 escaping
JSON_PAYLOAD=$(jq -n \
  --arg content "$CLIPBOARD_CONTENT" \
  '{
    "model": "grok-4-1-fast-non-reasoning",
    "messages": [
      {
        "role": "system",
        "content": "You are an expert prompt engineer. Your task is to transform user input into a well-structured, clear, and effective prompt for Large Language Models. Enhance the original intent while making it more specific, actionable, and context-rich. Maintain the original language of the input."
      },
      {
        "role": "user",
        "content": ("Transform the following text into an enhanced, well-structured prompt for an LLM. Make it clear, specific, and optimized for getting the best results:\n\n" + $content)
      }
    ],
    "temperature": 0.7,
    "max_tokens": 2000
  }')

# Call Grok API with UTF-8 charset
RESPONSE=$(curl -s https://api.x.ai/v1/chat/completions \
  -H "Content-Type: application/json; charset=utf-8" \
  -H "Authorization: Bearer $XAI_API_KEY" \
  --data-binary "$JSON_PAYLOAD")

# Check for API errors
if echo "$RESPONSE" | jq -e '.error' > /dev/null 2>&1; then
    echo "❌ API Error:"
    echo "$RESPONSE" | jq -r '.error.message'
    exit 1
fi

# Extract enhanced prompt
ENHANCED_PROMPT=$(echo "$RESPONSE" | jq -r '.choices[0].message.content')

if [ -z "$ENHANCED_PROMPT" ] || [ "$ENHANCED_PROMPT" = "null" ]; then
    echo "❌ Error: Failed to extract enhanced prompt from API response"
    echo "Response:"
    echo "$RESPONSE"
    exit 1
fi

echo "✨ Enhanced prompt:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "$ENHANCED_PROMPT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Copy to clipboard
echo "$ENHANCED_PROMPT" | pbcopy

echo "✅ Enhanced prompt copied to clipboard!"
echo ""
echo "💡 Usage info:"
echo "   • Model: grok-4-1-fast-non-reasoning"
echo "   • UTF-8 encoding: Enabled"
echo "   • Paste the enhanced prompt anywhere with Cmd+V"
